// -------------------------
// ITP - Uni Bremen
// 30.07.2011 
// David Rotermund 
// -------------------------
 
// Note: This files uses the Orange Tree Files and changes a lot... :-) 

#include <stdlib.h>                                                                                                 
#include <iostream>                                                                                                 
#include <stdio.h>   
#include <string.h>
#ifdef __unix__  
#include <unistd.h>
#endif

#include "zestet1_bitimage_tools.h"
//#include "console_tools.h"

// Chip select for main flash memory and CPLD
#define ZESTET1_RATE_40MHz (0<<4)
#define ZESTET1_RATE_20MHz (1<<4)
#define ZESTET1_RATE_10MHz (2<<4)
#define ZESTET1_FLASH_DEVICE_ID     (ZESTET1_RATE_40MHz|0)
#define ZESTET1_USERFLASH_DEVICE_ID (ZESTET1_RATE_20MHz|1)
#define ZESTET1_FPGA_DEVICE_ID      (ZESTET1_RATE_40MHz|1)
#define ZESTET1_CPLD_DEVICE_ID      (ZESTET1_RATE_40MHz|1)
#define ZESTET1_GIGEX_DEVICE_ID     (ZESTET1_RATE_20MHz|2)

#define BLOCK_SIZE (60000)

// Flash commands                                                                                     
#define ZESTET1_NVRAM_READ  0x0b
#define ZESTET1_NVRAM_WREN  0x06
#define ZESTET1_NVRAM_WRDI  0x04
#define ZESTET1_NVRAM_PP    0x02
#define ZESTET1_NVRAM_RDSR  0x05
#define ZESTET1_NVRAM_SE    0xD8
#define ZESTET1_NVRAM_RDID  0x9f

#define ZESTET1_NVRAM_WIP   0x01

#define ZESTET1_NVRAM_PAGE_SIZE 256
#define ZESTET1_NVRAM_SECTOR_SIZE 0x10000
#define ZESTET1_NVRAM_SIZE (2*1024*1024)

int ZestET1_BitImage_Tools::Reverse32BitWord(unsigned char * In, unsigned char * Out)
{
    if (In == NULL)
    {
	std::cout << "ZestET1_BitImage_Tools::Reverse32BitWord - In is NULL\n";
	return -1;
    }

    if (Out == NULL)
    {
	std::cout << "ZestET1_BitImage_Tools::Reverse32BitWord - Out is NULL\n";
	return -1;
    }
    
    Out[0] =  In[3];
    Out[1] =  In[2];
    Out[2] =  In[1];
    Out[3] =  In[0];
                                    
    return 0;
};

int ZestET1_BitImage_Tools::DisassembleLong4Byte(unsigned long In , unsigned char * Out, bool Reversed)
{
    if (Out == NULL)
    {
	std::cout << "ZestET1_BitImage_Tools::DisassembleLong4Byte - Out is NULL\n";
	return -1;
    }

    In = In&(0xFFFFFFFF);
    if (Reversed == false)
    {    
	Out[0] =  (In&0x000000FF);
	Out[1] =  (In&0x0000FF00)>>8;
	Out[2] =  (In&0x00FF0000)>>16;
	Out[3] =  (In&0xFF000000)>>24;
    }
    else
    {
	Out[3] =  (In&0x000000FF);
	Out[2] =  (In&0x0000FF00)>>8;
	Out[1] =  (In&0x00FF0000)>>16;
	Out[0] =  (In&0xFF000000)>>24;
    }
    
    return 0;
};

int ZestET1_BitImage_Tools::SPIReadWrite_Blocking(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading, unsigned char Device, 
	    unsigned char WordLen, unsigned char * WriteData, unsigned char * ReadData, long Length , unsigned char ReleaseCS)
{
    return SPIReadWrite(SocketHandle,FD_Writing, 0, 0 , FD_Reading, 0, 0, Device, WordLen, WriteData, ReadData, Length , ReleaseCS);
};


int ZestET1_BitImage_Tools::SPIReadWrite(SOCKET * SocketHandle,fd_set * FD_Writing, long TimeOutInSec_Write, long TimeOutInUSec_Write , 
	    fd_set * FD_Reading, long TimeOutInSec_Read, long TimeOutInUSec_Read, unsigned char Device, 
	    unsigned char WordLen, unsigned char * WriteData, unsigned char * ReadData, long Length , unsigned char ReleaseCS)
{
    int ReturnValueForSelect = -1;
    struct timeval TimeOut_Write;
    struct timeval TimeOut_Read;
    
    
    // Orange Tree: 
    unsigned char * Buffer = NULL;
    
    long Counter = 0;
    int WriteLength = 0;
    int ReadLength = 0;
    long NumberOfReadByte = 0;

    // Check the pointer for SocketHandle
    if (SocketHandle == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - SocketHandle is NULL\n";   
        return -1;
    }
                                
    // Check the pointer for FD_Writing    
    if (FD_Writing == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - FD_Writing is NULL\n";
        return -1;
    }

    Buffer = new unsigned char [65536];
    if (Buffer == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Buffer is NULL\n";
        return -1;
    }
    
    // Fill the structure for the time out
    if (TimeOutInSec_Write > 0)
    {
        TimeOut_Write.tv_sec = TimeOutInSec_Write;
    }
    else
    {
        TimeOut_Write.tv_sec = 0;
    }
                                                
    if (TimeOutInUSec_Write > 0)
    {
        TimeOut_Write.tv_usec = TimeOutInUSec_Write;
    }
    else
    {
        TimeOut_Write.tv_usec = 0;
    }

    // Check the pointer for FD_Reading    
    if (FD_Reading == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - FD_Reading is NULL\n";
        return -1;
    }

    // Fill the structure for the time out
    if (TimeOutInSec_Read > 0)
    {
	TimeOut_Read.tv_sec = TimeOutInSec_Read;
    }
    else
    {
        TimeOut_Read.tv_sec = 0;
    }
                                            
    if (TimeOutInUSec_Read > 0)
    {
        TimeOut_Read.tv_usec = TimeOutInUSec_Read;
    }
    else
    {
        TimeOut_Read.tv_usec = 0;
    }

                                                                                        
    // Wait until we can write and use a time out if demanded 
    if ((TimeOutInUSec_Write > 0) || (TimeOutInSec_Write > 0))
    {
        ReturnValueForSelect = select(*SocketHandle+1, NULL, FD_Writing, NULL, &TimeOut_Write);
    }
    else
    {
        ReturnValueForSelect = select(*SocketHandle+1, NULL, FD_Writing, NULL, NULL);
    }

    if (ReturnValueForSelect == -1)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Could not use select correctly (write)\n ";
        return -1;
    }

    // Build the package...
    // [->]
    Buffer[0] = 0xEE;
    Buffer[1] = Device;
    Buffer[2] = WordLen;
    Buffer[3] = ReleaseCS; 

    if (WriteData == NULL)
    {
	DisassembleLong4Byte(0, Buffer + 4, true);
    }
    else
    {
	DisassembleLong4Byte(Length/4, Buffer + 4, true);
    }

    if (ReadData == NULL)
    {
	DisassembleLong4Byte(0, Buffer + 8, true);
    }
    else
    {
	DisassembleLong4Byte(Length/4, Buffer + 8, true);
    }

    if (WriteData == NULL)
    {
	memset(Buffer+12,0,Length*4);
    }
    else
    {
	for (Counter = 0; Counter < Length; Counter += 4)
	{
	    if( Reverse32BitWord((unsigned char*)(WriteData+Counter), (unsigned char*)(Buffer+ Counter+12)) == -1)
	    {
		std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Problem with reversed copying.\n";
		return -1;
	    }
	}
    }

    if (WriteData == NULL)
    {
	WriteLength = 12;
    }
    else
    {
	WriteLength = 12 + Length;		
    }

    if (ReadData == NULL)
    {
	ReadLength = 4;
    }
    else
    {
	ReadLength = 4 + Length;    
    }    

    if (send(*SocketHandle,(char*)Buffer,WriteLength,0) == -1)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Could not use send correctly\n ";
        return -1;
    }

 
    // Wait until we can read and use a time out if demanded 
    if ((TimeOutInUSec_Read > 0) || (TimeOutInSec_Read > 0))
    {
        ReturnValueForSelect = select(*SocketHandle+1, FD_Reading, NULL, NULL, &TimeOut_Read);
    }
    else
    {
        ReturnValueForSelect = select(*SocketHandle+1, FD_Reading, NULL, NULL, NULL);
    }
                                             
    if (ReturnValueForSelect == -1)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Could not use select correctly (read)\n ";
        return -1;
    }

    // Read the data from the register 
    NumberOfReadByte = recv(*SocketHandle,(char*)Buffer,ReadLength,0);

    if (NumberOfReadByte == -1)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - recv failed \n ";
        return -1;
    }

    if (NumberOfReadByte != ReadLength)
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Getting the wrong number of bytes, thus recv failed \n ";
        return -1;
    }
  
    // Check if the response is okay
    if ((Buffer[0] != 0xEE) || (Buffer[1] != 0x00))
    {
        std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Reading went wrong.\n ";
        return -1;
    }        

    // Export the received data in the correct order 
    if (ReadData != NULL)
    {

	for (Counter = 0; Counter < Length; Counter +=4)
	{
	    if( Reverse32BitWord(Buffer+Counter+4,ReadData+Counter) == -1)
	    {
		std::cout << "ZestET1_BitImage_Tools::SPIReadWrite - Problem with reversed copying 2..\n";
		return -1;
	    }
	     	
	}
    }

    if (Buffer != NULL)
    {
	delete Buffer;
    }                                                       
    Buffer = NULL;

    return 0;
};                                

int ZestET1_BitImage_Tools::ConfigureFPGA(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading,BitFile * MyBitFile)
{
    unsigned long Command = 0;
    unsigned long Status = 0;
    unsigned long Timeout = 0;
    unsigned long i = 0;

    long BufferSize = 0;
    unsigned char * Buffer = NULL;
    
    unsigned char Buffer_In[4];
    unsigned char Buffer_Out[4];
    
    int WriteLength = 0;
    unsigned char ReleaseCS = 0;
    int Words = 0;
    int StatusOfTransfer = 0;

    float Position = 0;
    
    // Check the pointer for SocketHandle
    if (SocketHandle == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - SocketHandle is NULL\n";   
        return -1;
    }
                                
    // Check the pointer for FD_Writing    
    if (FD_Writing == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - FD_Writing is NULL\n";
        return -1;
    }

    // Check the pointer for FD_Reading    
    if (FD_Reading == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - FD_Reading is NULL\n";
        return -1;
    }

    // Check the pointer for MyBitFile    
    if (MyBitFile == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - MyBitFile is NULL\n";
        return -1;
    }

    // Check the MyBitFile    
    if (MyBitFile->IsImageOkay() == false)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - MyBitFile is not okay\n";
        return -1;
    }

    // Get the Image Data 
    BufferSize =  MyBitFile->GetImageLength();
    
    if (BufferSize < 1)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - MyBitFile has a length < 1\n";
        return -1;
    }

    Buffer = new unsigned char[BufferSize];    

    if (Buffer == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Creating Buffer failed < 1\n";
        return -1;
    }

    if (MyBitFile->GetImage_ZestET1Revered(Buffer) != 0)

    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Copying the image into the buffer failed < 1\n";
        return -1;
    } 
 
    // Orange Tree [->]
    // First, toggle PROG, take mode pins high and wait for INIT to go high
    Command = 0x40000000 | (0xe5<<22);
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 10, Buffer_Out, Buffer_In, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Transfer 1 failed\n";
	return -1;
    }


    Command = 0x40000000 | (0xe4<<22);
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 10, Buffer_Out, Buffer_In, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Transfer 2 failed\n";
	return -1;
    }

    Command = 0x40000000 | (0xe6<<22);
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 10, Buffer_Out, Buffer_In, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Transfer 3 failed\n";
	return -1;
    }

    do
    {
	Command = 0x40000000 | (0xe7<<22);
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 10, Buffer_Out, Buffer_In, 4 , 1) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Transfer 3 failed\n";
	    return -1;
	}
	Timeout++;
		
    }while (((Buffer_In[0]&2)==0) && (Timeout<1000)); // I have no clue what the correct timeout value is...

    if (Timeout>1000)    
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Timeout\n";
	return -1;
    }
    
    // Send data 
    Command = 0x00000000;
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 2, Buffer_Out, NULL, 4 , 0) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Send data 1 failed\n";
	return -1;
    }
  
    
    for (i=0; i< BufferSize; i += BLOCK_SIZE)
    {
	Position = (int) (((float)i) * 100.0 / ((float)BufferSize));
//        Console_Cursor_GotoXY(0,0);
//        Console_Refresh(); 
//	Console_Cursor_GotoXY(0,21);
	std::cout << "Configure... " << Position << "%           \n";        
//	Console_Refresh();

	if ( (BufferSize-i)<BLOCK_SIZE )
	{
    	    Words = (BufferSize-i);
	    ReleaseCS = 1;
	}
	else
	{
	    Words = BLOCK_SIZE;
	    ReleaseCS = 0;
	}
	
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 32, Buffer + i, NULL, Words , ReleaseCS ) != 0)
	{
	    std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Send data 2 failed\n";
	    return -1;
	}
 

    }
    
    // Clear mode pins
    Command = 0x40000000 | (0xe5<<22);
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 10, Buffer_Out, Buffer_In, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Clear mode pins failed\n";
	return -1;
    }

    // Read status                                                                                                                                                                                                                                    
    Command = 0x40000000 | (0xe5<<22);
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_FPGA_DEVICE_ID, 10, Buffer_Out, Buffer_In, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Read status failed\n";
	return -1;
    }

    // Check the status    
    if ((Buffer_In[0]&3)!=3)    
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Status is wrong.\n";
	return -1;
    }

    // Cleaning up
    if (Buffer == NULL)
    {
	delete Buffer;
    }
    Buffer = NULL;
   
    return 0;
};

int ZestET1_BitImage_Tools::ConfigureFPGA(char * Servername, int PortNumber , char * Filename)
{
    fd_set FD_Writing;
    fd_set FD_Reading;
    BitFile MyBitFile;
    SOCKET SocketHandle;
    int Status = -1;

    if (Servername == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Servername is NULL.\n";
	return -1;
    }

    if (Filename == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Filename is NULL.\n";
	return -1;
    }

    if (PortNumber < 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - PortNumber is invalid.\n";
	return -1;
    }

    MyBitFile.OpenFile(Filename);
    
    if (MyBitFile.IsImageOkay() == false)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - BitImage is invalid.\n";
	return -1;
    }

    if (MakeNetworkConnection(&SocketHandle, Servername, PortNumber, &FD_Reading , &FD_Writing) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Creating network connection failed.\n";
	return -1;
    }
    
    if (ZestET1_BitImage_Tools::ConfigureFPGA(&SocketHandle, &FD_Writing, &FD_Reading,&MyBitFile) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Configuration failed.\n";
	return -1;
    }
    
    if (CloseNetworkConnection(&SocketHandle) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::ConfigureFPGA - Closing network connection failed.\n";
	return -1;
    }
    
    return 0;
};

int ZestET1_BitImage_Tools::EraseFlashSector(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading, unsigned long Address)
{
    unsigned long Command = 0;
    unsigned char Buffer_In[4];
    unsigned char Buffer_Out[4];
        
    // Check the pointer for SocketHandle
    if (SocketHandle == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - SocketHandle is NULL\n";   
        return -1;
    }
                                
    // Check the pointer for FD_Writing    
    if (FD_Writing == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - FD_Writing is NULL\n";
        return -1;
    }

    // Check the pointer for FD_Reading    
    if (FD_Reading == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - FD_Reading is NULL\n";
        return -1;
    }

    Command = 0xc0000000;
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 1 failed\n";
	return -1;
    }

    Command = ZESTET1_NVRAM_WREN<<24;
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 8, Buffer_Out, NULL, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 2 failed\n";
	return -1;
    }

    Command = 0xc0000000;
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 3 failed\n";
	return -1;
    }
    
    Command = (ZESTET1_NVRAM_SE<<24) | Address;
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 32, Buffer_Out, NULL, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 4 failed\n";
	return -1;
    }
   
    do
    {
	Command = 0xc0000000;
	DisassembleLong4Byte(Command, Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 5 failed\n";
	    return -1;
	}
    
	Command = ZESTET1_NVRAM_RDSR<<24;
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 16, Buffer_Out, Buffer_In, 4 , 1) != 0)
	{
	    std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 6 failed\n";
	    return -1;
	}
    }while(Buffer_In[0] & ZESTET1_NVRAM_WIP);
    
    Command = 0xc0000000;
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 7 failed\n";
	return -1;
    }
    
    Command = ZESTET1_NVRAM_WRDI<<24;
    DisassembleLong4Byte(Command , Buffer_Out, false);    
    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 8, Buffer_Out, NULL, 4 , 1) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlashSector - Transfer 8 failed\n";
	return -1;
    }

    return 0;
};    

int ZestET1_BitImage_Tools::EraseFlash(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading)
{
    
    unsigned long Addr;
    double Position = 0;
    
    // Check the pointer for SocketHandle
    if (SocketHandle == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - SocketHandle is NULL\n";   
        return -1;
    }
                                
    // Check the pointer for FD_Writing    
    if (FD_Writing == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - FD_Writing is NULL\n";
        return -1;
    }

    // Check the pointer for FD_Reading    
    if (FD_Reading == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - FD_Reading is NULL\n";
        return -1;
    }

     // Erase region of flash for configuration data
     for (Addr=0; Addr<0xa0000; Addr+=ZESTET1_NVRAM_SECTOR_SIZE)
     {
        Position = 100.0 * (double)Addr / (double)0xa0000;
        
//        Console_Cursor_GotoXY(0,0);
//        Console_Refresh(); 
//	Console_Cursor_GotoXY(0,21);
	std::cout << "Erasing... " << Position << "%           \n";        
//	Console_Refresh();
	
	if (EraseFlashSector(SocketHandle,FD_Writing, FD_Reading, Addr) == -1)
	{
            std::cout << "ZestET1_BitImage_Tools::EraseFlash - Erasing failed.\n";
	    return -1;
	}
     }
    
    return 0;
};

int ZestET1_BitImage_Tools::EraseFlash(char * Servername, int PortNumber)
{
    fd_set FD_Writing;
    fd_set FD_Reading;
    BitFile MyBitFile;
    SOCKET SocketHandle;
    int Status = -1;

    if (Servername == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - Servername is NULL.\n";
	return -1;
    }

    if (PortNumber < 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - PortNumber is invalid.\n";
	return -1;
    }

    if (MakeNetworkConnection(&SocketHandle, Servername, PortNumber, &FD_Reading , &FD_Writing) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - Creating network connection failed.\n";
	return -1;
    }
    
    if (ZestET1_BitImage_Tools::EraseFlash(&SocketHandle, &FD_Writing, &FD_Reading) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - Erasing failed.\n";
	return -1;
    }
    
    if (CloseNetworkConnection(&SocketHandle) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::EraseFlash - Closing network connection failed.\n";
	return -1;
    }
    
    return 0;
};


int ZestET1_BitImage_Tools::WriteFlash(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading, void * Buffer, unsigned long Length)
{
    unsigned long Command = 0;
    unsigned char Buffer_In[4];
    unsigned char Buffer_Out[4];
    
    int First = 1;
    unsigned long Addr;
    char *FirstSector = NULL;
    char *FirstSectorPtr = NULL;
    char *LastSector = NULL;
    char *LastSectorPtr = NULL;
    unsigned char *Ptr = NULL;
    unsigned long EndAddr = 0;

    unsigned long Bytes;

    unsigned long Address = 0;
    double CompleteLength = 0;
    double Position = 0.0;
    // Check the pointer for SocketHandle
    if (SocketHandle == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - SocketHandle is NULL\n";   
        return -1;
    }
                                
    // Check the pointer for FD_Writing    
    if (FD_Writing == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - FD_Writing is NULL\n";
        return -1;
    }

    // Check the pointer for FD_Reading    
    if (FD_Reading == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - FD_Reading is NULL\n";
        return -1;
    }

    // Check the pointer for Buffer
    if (Buffer == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Buffer is NULL\n";
        return -1;
    }    

    if (Length == 0)
    {
        return 0;
    }

    
    EndAddr = Address+Length;        
    Addr = Address & ~(ZESTET1_NVRAM_SECTOR_SIZE-1);
    
    // We need some Zeros to fill up the rest of the sector
    LastSector = new char[ZESTET1_NVRAM_SECTOR_SIZE];

    if (LastSector == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - LastSector is NULL.\n";
        return -1;
    }	
    // I prefere 0 at the end of the sector
    memset(LastSector,0,ZESTET1_NVRAM_SECTOR_SIZE);
    LastSectorPtr = LastSector;

    CompleteLength = Length;    
    
    // Write to flash
    while (Length!=0 || (Addr&(ZESTET1_NVRAM_SECTOR_SIZE-1))!=0)
    {

	Position = (double) Addr * 100.0 / CompleteLength;
//        Console_Cursor_GotoXY(0,0);
//        Console_Refresh(); 
//	Console_Cursor_GotoXY(0,21);
	if (Position <= 100)
	{
	    std::cout << "Writing... " << Position << "%                                                    \n";        
	}
	else
	{
	    std::cout << "Writing... " << Position << "% (filling up the last sectors with zeros)           \n";        
	}
//	Console_Refresh();

        // Erase sector
        if (First || (Addr&(ZESTET1_NVRAM_SECTOR_SIZE-1))==0)
        {
    	    if (EraseFlashSector(SocketHandle,FD_Writing, FD_Reading, Addr) == -1)
	    {
    	        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Erasing flash sector failed.\n";
    	        return -1;
	    }
        }
	
	// Set up access to user flash
	Command = 0xc0000000;
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::WriteFlash - Set up access to user flash failed - 1\n";
	    return -1;
	}

	Command = ZESTET1_NVRAM_WREN<<24;
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 8, Buffer_Out, NULL, 4 , 1) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::WriteFlash - Set up access to user flash failed - 2\n";
	    return -1;
	}
		
	// Calculate number of bytes to write
	if (Addr<Address)
	{
	    Bytes = Address-Addr;
	}
	else if (Length!=0)
	{
	    Bytes = Length;
	}
	else
	{
	    Bytes = ZESTET1_NVRAM_SECTOR_SIZE-Addr;
	}

	if (Bytes>ZESTET1_NVRAM_PAGE_SIZE)
	{
	    Bytes = ZESTET1_NVRAM_PAGE_SIZE;
	}
	
	if ((ZESTET1_NVRAM_PAGE_SIZE-(Addr&(ZESTET1_NVRAM_PAGE_SIZE-1)))<Bytes)
	{
	    Bytes = (ZESTET1_NVRAM_PAGE_SIZE-(Addr&(ZESTET1_NVRAM_PAGE_SIZE-1)));
	}
	
	if (Addr<Address && (Address-Addr)<Bytes)
	{
	    Bytes = Address-Addr;
	}

	// Need command and address	    
	Command = 0xc0000000;
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::WriteFlash - Need command and address failed - 1\n";
	    return -1;
	}

	Command = (ZESTET1_NVRAM_PP<<24) | Addr;
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 32, Buffer_Out, NULL, 4 , 0) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::WriteFlash - Need command and address failed - 2\n";
	    return -1;
	}
	
	First = 0;

	// Write data to flash
	if (Addr<Address)	
	{
	    Ptr = (unsigned char *)FirstSectorPtr;
	}
	else if (Length!=0)
	{
	    Ptr = (unsigned char *)Buffer;
	}
	else
	{
	    Ptr = (unsigned char *)LastSectorPtr;
	}

	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , Bytes>3 ? 32 : 8*Bytes , Ptr, NULL, Bytes>3 ? Bytes : 4 , 1) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::WriteFlash - Write data to flash failed\n";
	    return -1;
	}
	
	if (Addr<Address)
	{
	    FirstSectorPtr += Bytes;
	}
	else if (Length!=0)
    	{	
	    Length -= Bytes;
	    Buffer = (char *)Buffer + Bytes;
	}
	else
	{
	    LastSectorPtr += Bytes;
	}
	Addr += Bytes;
	
	// Poll status register
	do
	{
	    Command = 0xc0000000;
	    DisassembleLong4Byte(Command , Buffer_Out, false);    
	    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
	    {
    	        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Poll status register failed - 1\n";
	        return -1;
	    }

	    Command = ZESTET1_NVRAM_RDSR<<24;
	    DisassembleLong4Byte(Command , Buffer_Out, false);    
	    if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 16, Buffer_Out, Buffer_In, 4 , 1) != 0)
	    {
    		std::cout << "ZestET1_BitImage_Tools::WriteFlash - Poll status register failed - 2\n";
	        return -1;
	    }

	}while(Buffer_In[0] & ZESTET1_NVRAM_WIP);
        
        Command = 0xc0000000;
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 2, Buffer_Out, NULL, 4 , 0) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::WriteFlash - Poll status register failed - 3\n";
	    return -1;
	}

	Command = ZESTET1_NVRAM_WRDI<<24;
	DisassembleLong4Byte(Command , Buffer_Out, false);    
	if ( SPIReadWrite_Blocking(SocketHandle,FD_Writing, FD_Reading, ZESTET1_USERFLASH_DEVICE_ID , 8, Buffer_Out, NULL, 4 , 1) != 0)
	{
    	    std::cout << "ZestET1_BitImage_Tools::WriteFlash - Poll status register failed - 4\n";
    	    return -1;
        }
    }
        
    if (FirstSector != NULL)
    {
	delete FirstSector;
    }
    FirstSector = NULL;

    if (LastSector != NULL)
    {
	delete LastSector;
    }
    LastSector = NULL;


    return 0;
};

int ZestET1_BitImage_Tools::WriteFlash(char * Servername, int PortNumber , char * Filename)
{
    fd_set FD_Writing;
    fd_set FD_Reading;
    BitFile MyBitFile;
    SOCKET SocketHandle;
    int Status = -1;
    
    unsigned char * Buffer = NULL;
    unsigned long BufferSize = 0;
    
    if (Servername == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Servername is NULL.\n";
	return -1;
    }

    if (Filename == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Filename is NULL.\n";
	return -1;
    }

    if (PortNumber < 0)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - PortNumber is invalid.\n";
	return -1;
    }

    MyBitFile.OpenFile(Filename);
    
    if (MyBitFile.IsImageOkay() == false)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - BitImage is invalid.\n";
	return -1;
    }

    // Get the Image Data 
    BufferSize =  MyBitFile.GetImageLength();
    
    if (BufferSize < 1)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - MyBitFile has a length < 1\n";
        return -1;
    }

    Buffer = new unsigned char[BufferSize];    

    if (Buffer == NULL)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Creating Buffer failed < 1\n";
        return -1;
    }

    if (MyBitFile.GetImage_ZestET1Revered(Buffer) != 0)

    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Copying the image into the buffer failed < 1\n";
        return -1;
    } 


    if (MakeNetworkConnection(&SocketHandle, Servername, PortNumber, &FD_Reading , &FD_Writing) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Creating network connection failed.\n";
	return -1;
    }
    
    if (ZestET1_BitImage_Tools::WriteFlash(&SocketHandle, &FD_Writing, &FD_Reading,Buffer,BufferSize) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Configuration failed.\n";
	return -1;
    }
    
    if (CloseNetworkConnection(&SocketHandle) != 0)
    {
        std::cout << "ZestET1_BitImage_Tools::WriteFlash - Closing network connection failed.\n";
	return -1;
    }

    if (Buffer != NULL)
    {
	delete Buffer;
    }
    Buffer = NULL;

    
    return 0;
};

/*
int main()
{
    ZestET1_BitImage_Tools MyBT;

    std::cout << "Configure ... \n";
    MyBT.ConfigureFPGA((char *)"192.168.1.100", 20481 , (char*) "Example2.bit");    
    std::cout << "Erase ... \n";
    MyBT.EraseFlash((char *)"192.168.1.100", 20481);    
    std::cout << "Write... \n";
    MyBT.WriteFlash((char *)"192.168.1.100", 20481 , (char*) "Example2.bit");    

    return 0;
};

*/
