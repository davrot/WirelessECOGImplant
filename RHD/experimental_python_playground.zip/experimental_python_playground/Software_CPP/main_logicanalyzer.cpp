#include <stdlib.h>
#include <iostream>
#include <stdio.h>

#include "zestet1_network.h"
#include "zestet1_bitimage_tools.h"
#include "adc_tools.h"
#include <string>
#include <cctype>
#include <ncurses.h>

int main(int argc, char *argv[])
{

  const char BITFile[] = "LogicAnalyzer.bit";

  ZestET1_BitImage_Tools MyBT;

  SOCKET SocketHandle;
  fd_set FD_Reading;
  fd_set FD_Writing;

  unsigned char * Buffer = 0;
  unsigned long BufferMax = 500000;
  struct timeval TimeOut_Read;

  long NumberOfReadByte = -1;
  long Counter_Output = 0;
  long ReturnValueForSelect = 0;

  int WidthOfTheWindow = -1;
  int WidthOfTheWindow_Effective = -1;
  int WidthOfTheWindow_Last = -1;
  int LengthOfTheWindow = -1;
  int LengthOfTheWindow_Last = -1;
  int Counter_X = 0;
  int KeyPressed = 0;
  int KeyPressed_Last = 0;

  unsigned char ClockMode = 3;
  unsigned char DebugMode = 0;

  unsigned char ClockMode_Last = 0;
  unsigned char DebugMode_Last = 0;

  int DebugMessageX = 0;
  int DebugMessageY = 0;

  int WhichValueToUpdate = -1;
  unsigned char ValueToUpdate = 0;
  int IsHeader = 1;

  TimeOut_Read.tv_sec = 0;
  TimeOut_Read.tv_usec = 50000;

  if (argc != 2)
  {
    std::cout << "Configuring the FPGA\n";
    std::cout << "1. IP e.g. 192.168.1.100\n";
    return 0;
  }

  Buffer = new unsigned char [BufferMax];
  if (Buffer == NULL)
  {
    std::cout << "Firmware_ReadData - Buffer is NULL\n";
    return -1;
  }

  MyBT.ConfigureFPGA((char *)argv[1], 20481 , (char *)BITFile);
  usleep(500000);

  if( MakeNetworkConnection(&SocketHandle, (char*) argv[1], 0x5002, &FD_Reading , &FD_Writing) == -1)
  {
    std::cout << "Network connection couldn't be established.\n";
    return 0;
  }

  initscr();
  raw();
  keypad(stdscr, TRUE);
  clear();
  init_pair(1, COLOR_WHITE, COLOR_BLACK);
  init_pair(2, COLOR_BLACK, COLOR_WHITE);
  nodelay(stdscr,true);
  curs_set(0);

  do {

    getmaxyx(stdscr, LengthOfTheWindow, WidthOfTheWindow);
    if ((WidthOfTheWindow != WidthOfTheWindow_Last) || (LengthOfTheWindow != LengthOfTheWindow_Last)){
      WidthOfTheWindow_Last = WidthOfTheWindow;
      LengthOfTheWindow_Last = LengthOfTheWindow;
      WidthOfTheWindow_Effective = (((int)(WidthOfTheWindow / 11)) * 11)-1;
      DebugMessageX = 0;
      DebugMessageY = 0;
      clear();
      refresh();
    }
    mvprintw(0,0,"Change? (m=debug mode; n=clock mode)");
    if (KeyPressed_Last == 'm'){
      mvprintw(1,0,"Debug Mode Number:                                  ");
      move(1,20);
      Buffer[0] = 0;
      Buffer[1] = 0;
      Buffer[2] = 0;
      Buffer[3] = 0;
      curs_set(1);
      nodelay(stdscr,false);
      NumberOfReadByte = getnstr((char*)Buffer,2);
      curs_set(0);
      nodelay(stdscr,true);
      KeyPressed_Last = 0;
      DebugMode = atol((char*)Buffer);
    }
    else if (KeyPressed_Last == 'n'){
      mvprintw(1,0,"Clock Mode Number:                                  ");
      move(1,20);
      Buffer[0] = 0;
      Buffer[1] = 0;
      Buffer[2] = 0;
      Buffer[3] = 0;
      curs_set(1);
      nodelay(stdscr,false);
      NumberOfReadByte = getnstr((char*)Buffer,1);
      curs_set(0);
      nodelay(stdscr,true);
      KeyPressed_Last = 0;
      ClockMode = atol((char*)Buffer);
    }
    else
    {
      WhichValueToUpdate = -1;
      mvprintw(1,0,"                                                   ");
      move(1,0);
    }
    KeyPressed = getch();

    if (KeyPressed != -1){
      KeyPressed_Last = KeyPressed;
    }

    for (Counter_X = WidthOfTheWindow-1; Counter_X >= 0; Counter_X --)
    {
      // Lets draw a line...
      mvprintw(3,Counter_X,"-");

    }
    mvprintw(2,WidthOfTheWindow-13,"(q for quit)");

    // Clamp the max setting for the debug parameters
    if (ClockMode >= 3){
      ClockMode = 3;
    }

    if (DebugMode >= 31){
      DebugMode = 31;
    }

    // Print the selected debug parameters
    if (ClockMode == 3){
      mvprintw(2,0,"Debug Mode: %u     Clock Mode: Internal    ",DebugMode);
    }
    else{
      mvprintw(2,0,"Debug Mode: %u     Clock Mode: %u        ",DebugMode,ClockMode);
    }

    if ((ClockMode_Last != ClockMode) || (DebugMode_Last != DebugMode)){
      ClockMode_Last = ClockMode;
      DebugMode_Last = DebugMode;
      Buffer[0] = 0;
      Buffer[1] = DebugMode + (ClockMode << 5);
      send(SocketHandle,(char *)Buffer,2,0);
    }


    // Check what we get from the network
    ReturnValueForSelect = select(SocketHandle+1, &FD_Reading, NULL, NULL, &TimeOut_Read);

    if (ReturnValueForSelect == -1){
      std::cout << "Firmware_ReadData - Could not use select correctly\n ";
      return -1;
    }

    // Read the data
    NumberOfReadByte = recv(SocketHandle,(char *)Buffer,BufferMax,MSG_DONTWAIT);

    if (NumberOfReadByte > 0){
      for (Counter_Output = 0; Counter_Output < NumberOfReadByte; Counter_Output++){
        // Keep the curser inside a window
        if (DebugMessageX > WidthOfTheWindow_Effective){
          DebugMessageX = 0;
          DebugMessageY ++;
        }
        if (DebugMessageX < 0){
          DebugMessageX = 0;
        }

        if (DebugMessageY >= LengthOfTheWindow){
          DebugMessageY = 0;
        }
        if (DebugMessageY < 5){
          DebugMessageY = 5;
        }



        if (IsHeader == 1){
          mvprintw(DebugMessageY,DebugMessageX,"%02u",(Buffer[Counter_Output]>>3));
          DebugMessageX +=2;
          mvprintw(DebugMessageY,DebugMessageX,",");
          DebugMessageX ++;
          mvprintw(DebugMessageY,DebugMessageX,"%u",(Buffer[Counter_Output] - ((Buffer[Counter_Output]>>3)<< 3) ) >> 1);
          DebugMessageX ++;
          mvprintw(DebugMessageY,DebugMessageX,":");
          DebugMessageX ++;
          mvprintw(DebugMessageY,DebugMessageX,"%u",(Buffer[Counter_Output] - ((Buffer[Counter_Output]>>1)<< 1)) );
          DebugMessageX ++;
          mvprintw(DebugMessageY,DebugMessageX,",");
          DebugMessageX ++;

          IsHeader = 0;
        }
        else
        {
          mvprintw(DebugMessageY,DebugMessageX,"%03u",Buffer[Counter_Output]);
          DebugMessageX += 3;
          mvprintw(DebugMessageY,DebugMessageX," ");
          DebugMessageX ++;

          IsHeader = 1;
        }
      }
    }

  } while(KeyPressed != 'q');

  curs_set(1);
  endwin();

  if (CloseNetworkConnection(&SocketHandle) == -1)
  {
    std::cout << "Network connection couldn't be closed.\n";
    return 0;
  }

  if (Buffer != NULL)
  {
    delete Buffer;
  }
  Buffer = NULL;

  return 0;
};
