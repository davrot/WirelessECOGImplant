// -------------------------
// ITP - Uni Bremen
// 21.07.2011 
// David Rotermund 
// -------------------------

#ifndef include_adc_tools_h                                                                                             
#define include_adc_tools_h  

#ifdef __unix__  
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#endif

#ifdef _WIN32
//#pragma comment(lib, "wsock32.lib")

//#include <stdio.h>
//#include <iostream>
//#include <string.h>
//#include <tchar.h>  
//#include <winsock2.h>
//#include <ws2tcpip.h>
//#include <stdlib.h> 
#include "zestet1_network.h"
#endif

int Firmware_Command (unsigned char * Output, unsigned long LengthOfCommand,  unsigned long CommandID, unsigned long * Values, long NumberOfValues);
int Firmware_SendCommand(SOCKET * SocketHandle, unsigned char * CommandArray, unsigned long LengthOfCommand , fd_set * FD_Writing, long TimeOutInSec_Write, long TimeOutInUSec_Write);
int Firmware_ReadData(SOCKET * SocketHandle, fd_set * FD_Reading, long TimeOutInSec_Read, long TimeOutInUSec_Read, bool AppendIt , unsigned long PacketID, unsigned long long MaxNumberOfSamples=0);
int AnalysePacket(unsigned char * DataArray, unsigned long Length, long * LastMode, long * PacketSize, FILE * OutputStream_Basestation , FILE * OutputStream_ASICData, FILE * OutputStream_Zarlink, FILE * OutputStream_ADCData, FILE * OutputStream_TriggerData, FILE * OutputStream_IResponseData, unsigned long PacketID, int * LastValue, unsigned long long * NumberOfSamples );
                    
#endif








