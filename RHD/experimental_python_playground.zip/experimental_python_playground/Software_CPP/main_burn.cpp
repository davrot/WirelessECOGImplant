#include <stdlib.h>                                                                                                 
#include <iostream>                                                                                                 
#include <stdio.h>                                                                                                  

#include "zestet1_network.h"
#include "zestet1_bitimage_tools.h"
#include "adc_tools.h"

int main(int argc, char *argv[])
{

    ZestET1_BitImage_Tools MyBT;
    if (argc != 3)
    {
        std::cout << "Write the Bit-Image the FPGA\n";
        std::cout << "1. IP e.g. 192.168.1.100\n";
        std::cout << "2. Name of the bit-file\n";
        return 0;
    }
                                                    
    MyBT.WriteFlash((char *)argv[1], 20481 , (char *)argv[2]);	
    std::cout << "-==- Done -==-\n";
           

//----------------------    
    return 0;
};
