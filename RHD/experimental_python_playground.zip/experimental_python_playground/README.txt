This is a very experimental version of the firmware and software. 
The goal was to create a Python interface plus debugging interfaces and a simple logic analyzer (ZestET1 based) for the implant and basestation side. 
This source code represents the actual experimental state of (the unfinished) development. 
The system was tested and functional but the measured bandwidth of the wireless link was below expectations (especally compared tothe measurements with the other firmware).
The reason is expected in the IGLOO RHD firmware which results in not filling the buffers in time. 

The development and debugging was stopped due to funding reasons... 



 
 

