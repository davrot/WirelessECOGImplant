clear
fid = fopen('Network-Dump.999','r');
if fid ~= -1
  Temp = fread(fid,inf,'uint16=>uint16');
end
fclose(fid);

Z = double(['']);

for i = 1:1:length(Temp)-20
  if (Temp(i) == 21930) && (Temp(i+2)==32769)
    Z = [Z i];
  end
end

LengthVector = zeros(length(Z),1);
for i = 1:1:length(Z)
  LengthVector(i) = Temp(Z(i)+1);
end
ULV = unique(LengthVector);
if length(ULV) ~= 1
  error('Problem - A ');
end 

Packets = zeros(length(LengthVector),7);
for i = 1:1:length(Z)
  Packets(i,:) = Temp(Z(i)+3:Z(i)+9);
end

Packets = Packets';
Timestamps_Implant = Packets(1,:);
Timestamps_Base = uint64(Packets(2:5,:));
Timestamps_Base = Timestamps_Base(1,:)*256^6 + Timestamps_Base(2,:)*256^4 + ...
                  Timestamps_Base(3,:)*256^2 + Timestamps_Base(4,:);


Status = Packets(end,:);
Data = Packets(6:end-1,:);

plot(Timestamps_Base)