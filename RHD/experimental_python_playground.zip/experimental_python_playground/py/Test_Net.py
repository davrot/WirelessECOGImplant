import multiprocessing
import time
import numpy
# Own Modules
import submodules.NetworkWorker as NetworkWorker
import submodules.PackageAnalyseWorker as PackageAnalyseWorker
import submodules.RHD_Sequence as RHD_Sequence
import submodules.FileBuffer as FileBuffer

if __name__ == '__main__':

    ## --------------------------------------------------------
    # Network Command IN -> Network Data Out
    PipeIn_NWP, PipeIn_NetworkCommands = multiprocessing.Pipe(False)
    # Network Data exchange
    PipeIn_PAP, PipeOut_NWP = multiprocessing.Pipe(False)
    # Result from the data analysis
    PipeOut_PAP_OtherSide, PipeOut_PAP = multiprocessing.Pipe(False)
    # Control Network process
    PipeControl_NWP, PipeControl_NWP_OtherSide = multiprocessing.Pipe(False)
    # Control Data Analysis Process
    PipeControl_PAP, PipeControl_PAP_OtherSide = multiprocessing.Pipe(False)

    # I want my network stack
    NWP = NetworkWorker.NetworkWorker(name="MainNetworkProcess", PipeIn=PipeIn_NWP, \
        PipeOut=PipeOut_NWP, PipeControl=PipeControl_NWP, host="192.168.1.100")
    NWP.start()
    # I want to start my analysis module
    PAP = PackageAnalyseWorker.PackageAnalyseWorker(name="MainDataAnalysisProcess", \
      PipeIn=PipeIn_PAP, PipeOut=PipeOut_PAP, PipeControl=PipeControl_PAP)
    PAP.start()
    ## --------------------------------------------------------

    Result = []

    # The parameters for the configuration:
    NumberOfChannels = 1 # Can be larger but not smaller than the number of active channels...
    ConfigureTestMode = 1 # '1' On, '0' Off,
    DesiredSampleRateInHz = float(1000)
    ChannelMask = [0,0,0,1]
    ChannelMaskAUX = []
    InstalledRHDBitMASK = 1
    HP_ID = 9 # 1000Hz
    LP_ID = 24 # 0.1Hz
    Filename_ImplantData = "Default_Implant.data"
    Filename_TriggerData = "Default_Trigger.data"
    CountCRC = 0
    CountPackages = 0
    Command_List,Command_Responses,Command_Name = RHD_Sequence.RHD_Sequence(\
      NumberOfChannels,DesiredSampleRateInHz,ConfigureTestMode,ChannelMask,\
      ChannelMaskAUX,InstalledRHDBitMASK,HP_ID,LP_ID)
    ImplantData = FileBuffer.FileBuffer(10240,256,Filename_ImplantData)
    TriggerData = FileBuffer.FileBuffer(10240,15,Filename_TriggerData)

    Step = 0
    StepState = 0
    FinalError = 0
    CountImplantResponses = 0
    CountTriggerResponses = 0
    while True:
            # Check for incomming data
            if PipeOut_PAP_OtherSide.poll() == True:
                Result = PipeOut_PAP_OtherSide.recv()
            #else:
            #    time.sleep(0.1)
            # Is the result the right kind of Object?
            Result_Good = True
            try:
                Temp = Result.Error
            except:
                Result_Good = False

            # Remove the Implant resonses from the network stream:
            if Result_Good == True:
                if Result.PackageType == 0x6542:
                    CountImplantResponses = CountImplantResponses + 1
                    print "Impant-Response number ", CountImplantResponses, " found."
                    Result = []
                    Result_Good = False
                elif Result.PackageType == 0x8001:
                    ImplantData.AddTrials(Result.FoundData)
                    CountPackages = CountPackages + 1
#                    print CountPackages, Result.data
#                    FileID = open("Network-Dump.999",'ab')
#                    FileID.write(Result.data.tobytes())
#                    FileID.close()
                    Result = []
                    Result_Good = False
                elif Result.PackageType == 0x8004:
                    TriggerData.AddTrials(Result.FoundData)
                    CountTriggerResponses = CountTriggerResponses + 1
#                    print CountTriggerResponses, Result.data
                    Result = []
                    Result_Good = False
                elif Result.PackageType == 0x8000:
                    TEMP_WAIT = "DO NOTHING"
                elif Result.PackageType == 0:
                    CountCRC = CountCRC + 1
                    if Result.Error == -3:
                        print "CRC Error (1)",
                    if Result.Error == -4:
                        print "CRC Error (2)",
                    if Result.Error == -5:
                        print "CRC Error (3)",
                    if Result.Error == -6:
                        print "CRC Error (4)",
                    print "Bad:", CountCRC,
                    print "Good: Data ", CountPackages,
                    print "/ Trigger ", CountTriggerResponses

                else:
                    print "Packet found:",
                    #print Result.Error
                    #print Result.Module
                    print Result.PackageType ,
                    print Result.FoundData

            # Emmit the command
            if (StepState == 0):
                if Step < len(Command_Name):
                    print (Step+1), " of ", len(Command_Name), ":", Command_Name[Step],
                    PipeIn_NetworkCommands.send_bytes(Command_List[Step])
                    StepState = 1

            # We good a "Command received by basestation" response
            # Progress to the next command
            if (StepState == 1) and (Result_Good == True):
                if (Result.PackageType == Result.AllowedPackages[0]):
                    # The response contained no error and is from the correct module:
                    if (Result.Error == 0) and (Result.Module == Command_Responses[Step]):
                        # Lets check other expectations:
                        if (Result.Module == 1024):
                            if (Result.FoundData.size == 1) \
                              and (((Result.FoundData.flat[0] & (1<<2))>>2) == 1):
                                print "Connection found!!!"
                                Step = Step + 1
                                StepState = 0
                            else:
                                # Let's check again if there is a connection now...
                                print "Waiting for connection..."
                                Step = Step
                                StepState = 0

                        # If there are no other expectations: (continue with the next step)
                        else:
                            Step = Step + 1
                            StepState = 0
                            print "OK!"
                    else:
                        # We got an error... Bad bad... Panic!!!!
                        # Prepare to die!!!!
                        FinalError = 1
                        print " "
                        print "ERROR!!! In Command:",
                        print Command_Name[Step]
                        print "Expected response from Module:", Command_Responses[Step]
                        print "Module-Number:", Result.Module
                        print "Error-Mode:",
                        print Result.Error
                        print "Package Type",
                        print Result.PackageType
                        print "Found Data:",
                        print Result.FoundData
                    Result = []
                    Result_Good = False

            # Lets close the shop!
            if FinalError == 1:
                PipeControl_NWP_OtherSide.send_bytes("Stop")
                PipeControl_PAP_OtherSide.send_bytes("Stop")
                NWP.join()
                PAP.join()
                ImplantData.CleanToFile()
                break
