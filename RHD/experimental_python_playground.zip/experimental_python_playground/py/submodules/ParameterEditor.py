import Tkinter
import tkFileDialog
import json

class ParameterEditor(Tkinter.Frame):
    def __init__(self, master):
        Tkinter.Frame.__init__(self,master)
        ### IC 1:
        self.V1_01 = Tkinter.IntVar() ; self.V1_02 = Tkinter.IntVar() ; self.V1_03 = Tkinter.IntVar() ; self.V1_04 = Tkinter.IntVar() ; self.V1_05 = Tkinter.IntVar()
        self.V1_06 = Tkinter.IntVar() ; self.V1_07 = Tkinter.IntVar() ; self.V1_08 = Tkinter.IntVar() ; self.V1_09 = Tkinter.IntVar() ; self.V1_10 = Tkinter.IntVar()
        self.V1_11 = Tkinter.IntVar() ; self.V1_12 = Tkinter.IntVar() ; self.V1_13 = Tkinter.IntVar() ; self.V1_14 = Tkinter.IntVar() ; self.V1_15 = Tkinter.IntVar()
        self.V1_16 = Tkinter.IntVar() ; self.V1_17 = Tkinter.IntVar() ; self.V1_18 = Tkinter.IntVar() ; self.V1_19 = Tkinter.IntVar() ; self.V1_20 = Tkinter.IntVar()
        self.V1_21 = Tkinter.IntVar() ; self.V1_22 = Tkinter.IntVar() ; self.V1_23 = Tkinter.IntVar() ; self.V1_24 = Tkinter.IntVar() ; self.V1_25 = Tkinter.IntVar()
        self.V1_26 = Tkinter.IntVar() ; self.V1_27 = Tkinter.IntVar() ; self.V1_28 = Tkinter.IntVar() ; self.V1_29 = Tkinter.IntVar() ; self.V1_30 = Tkinter.IntVar()
        self.V1_31 = Tkinter.IntVar() ; self.V1_32 = Tkinter.IntVar()
        self.V1_A1 = Tkinter.IntVar() ; self.V1_A2 = Tkinter.IntVar() ; self.V1_A3 = Tkinter.IntVar()
        ### IC 2:
        self.V2_01 = Tkinter.IntVar() ; self.V2_02 = Tkinter.IntVar() ; self.V2_03 = Tkinter.IntVar() ; self.V2_04 = Tkinter.IntVar() ; self.V2_05 = Tkinter.IntVar()
        self.V2_06 = Tkinter.IntVar() ; self.V2_07 = Tkinter.IntVar() ; self.V2_08 = Tkinter.IntVar() ; self.V2_09 = Tkinter.IntVar() ; self.V2_10 = Tkinter.IntVar()
        self.V2_11 = Tkinter.IntVar() ; self.V2_12 = Tkinter.IntVar() ; self.V2_13 = Tkinter.IntVar() ; self.V2_14 = Tkinter.IntVar() ; self.V2_15 = Tkinter.IntVar()
        self.V2_16 = Tkinter.IntVar() ; self.V2_17 = Tkinter.IntVar() ; self.V2_18 = Tkinter.IntVar() ; self.V2_19 = Tkinter.IntVar() ; self.V2_20 = Tkinter.IntVar()
        self.V2_21 = Tkinter.IntVar() ; self.V2_22 = Tkinter.IntVar() ; self.V2_23 = Tkinter.IntVar() ; self.V2_24 = Tkinter.IntVar() ; self.V2_25 = Tkinter.IntVar()
        self.V2_26 = Tkinter.IntVar() ; self.V2_27 = Tkinter.IntVar() ; self.V2_28 = Tkinter.IntVar() ; self.V2_29 = Tkinter.IntVar() ; self.V2_30 = Tkinter.IntVar()
        self.V2_31 = Tkinter.IntVar() ; self.V2_32 = Tkinter.IntVar()
        self.V2_A1 = Tkinter.IntVar() ; self.V2_A2 = Tkinter.IntVar() ; self.V2_A3 = Tkinter.IntVar()
        ### IC 3:
        self.V3_01 = Tkinter.IntVar() ; self.V3_02 = Tkinter.IntVar() ; self.V3_03 = Tkinter.IntVar() ; self.V3_04 = Tkinter.IntVar() ; self.V3_05 = Tkinter.IntVar()
        self.V3_06 = Tkinter.IntVar() ; self.V3_07 = Tkinter.IntVar() ; self.V3_08 = Tkinter.IntVar() ; self.V3_09 = Tkinter.IntVar() ; self.V3_10 = Tkinter.IntVar()
        self.V3_11 = Tkinter.IntVar() ; self.V3_12 = Tkinter.IntVar() ; self.V3_13 = Tkinter.IntVar() ; self.V3_14 = Tkinter.IntVar() ; self.V3_15 = Tkinter.IntVar()
        self.V3_16 = Tkinter.IntVar() ; self.V3_17 = Tkinter.IntVar() ; self.V3_18 = Tkinter.IntVar() ; self.V3_19 = Tkinter.IntVar() ; self.V3_20 = Tkinter.IntVar()
        self.V3_21 = Tkinter.IntVar() ; self.V3_22 = Tkinter.IntVar() ; self.V3_23 = Tkinter.IntVar() ; self.V3_24 = Tkinter.IntVar() ; self.V3_25 = Tkinter.IntVar()
        self.V3_26 = Tkinter.IntVar() ; self.V3_27 = Tkinter.IntVar() ; self.V3_28 = Tkinter.IntVar() ; self.V3_29 = Tkinter.IntVar() ; self.V3_30 = Tkinter.IntVar()
        self.V3_31 = Tkinter.IntVar() ; self.V3_32 = Tkinter.IntVar()
        self.V3_A1 = Tkinter.IntVar() ; self.V3_A2 = Tkinter.IntVar() ; self.V3_A3 = Tkinter.IntVar()
        ### IC 4:
        self.V4_01 = Tkinter.IntVar() ; self.V4_02 = Tkinter.IntVar() ; self.V4_03 = Tkinter.IntVar() ; self.V4_04 = Tkinter.IntVar() ; self.V4_05 = Tkinter.IntVar()
        self.V4_06 = Tkinter.IntVar() ; self.V4_07 = Tkinter.IntVar() ; self.V4_08 = Tkinter.IntVar() ; self.V4_09 = Tkinter.IntVar() ; self.V4_10 = Tkinter.IntVar()
        self.V4_11 = Tkinter.IntVar() ; self.V4_12 = Tkinter.IntVar() ; self.V4_13 = Tkinter.IntVar() ; self.V4_14 = Tkinter.IntVar() ; self.V4_15 = Tkinter.IntVar()
        self.V4_16 = Tkinter.IntVar() ; self.V4_17 = Tkinter.IntVar() ; self.V4_18 = Tkinter.IntVar() ; self.V4_19 = Tkinter.IntVar() ; self.V4_20 = Tkinter.IntVar()
        self.V4_21 = Tkinter.IntVar() ; self.V4_22 = Tkinter.IntVar() ; self.V4_23 = Tkinter.IntVar() ; self.V4_24 = Tkinter.IntVar() ; self.V4_25 = Tkinter.IntVar()
        self.V4_26 = Tkinter.IntVar() ; self.V4_27 = Tkinter.IntVar() ; self.V4_28 = Tkinter.IntVar() ; self.V4_29 = Tkinter.IntVar() ; self.V4_30 = Tkinter.IntVar()
        self.V4_31 = Tkinter.IntVar() ; self.V4_32 = Tkinter.IntVar()
        self.V4_A1 = Tkinter.IntVar() ; self.V4_A2 = Tkinter.IntVar() ; self.V4_A3 = Tkinter.IntVar()
        ### IC 5:
        self.V5_01 = Tkinter.IntVar() ; self.V5_02 = Tkinter.IntVar() ; self.V5_03 = Tkinter.IntVar() ; self.V5_04 = Tkinter.IntVar() ; self.V5_05 = Tkinter.IntVar()
        self.V5_06 = Tkinter.IntVar() ; self.V5_07 = Tkinter.IntVar() ; self.V5_08 = Tkinter.IntVar() ; self.V5_09 = Tkinter.IntVar() ; self.V5_10 = Tkinter.IntVar()
        self.V5_11 = Tkinter.IntVar() ; self.V5_12 = Tkinter.IntVar() ; self.V5_13 = Tkinter.IntVar() ; self.V5_14 = Tkinter.IntVar() ; self.V5_15 = Tkinter.IntVar()
        self.V5_16 = Tkinter.IntVar() ; self.V5_17 = Tkinter.IntVar() ; self.V5_18 = Tkinter.IntVar() ; self.V5_19 = Tkinter.IntVar() ; self.V5_20 = Tkinter.IntVar()
        self.V5_21 = Tkinter.IntVar() ; self.V5_22 = Tkinter.IntVar() ; self.V5_23 = Tkinter.IntVar() ; self.V5_24 = Tkinter.IntVar() ; self.V5_25 = Tkinter.IntVar()
        self.V5_26 = Tkinter.IntVar() ; self.V5_27 = Tkinter.IntVar() ; self.V5_28 = Tkinter.IntVar() ; self.V5_29 = Tkinter.IntVar() ; self.V5_30 = Tkinter.IntVar()
        self.V5_31 = Tkinter.IntVar() ; self.V5_32 = Tkinter.IntVar()
        self.V5_A1 = Tkinter.IntVar() ; self.V5_A2 = Tkinter.IntVar() ; self.V5_A3 = Tkinter.IntVar()
        ### IC 6:
        self.V6_01 = Tkinter.IntVar() ; self.V6_02 = Tkinter.IntVar() ; self.V6_03 = Tkinter.IntVar() ; self.V6_04 = Tkinter.IntVar() ; self.V6_05 = Tkinter.IntVar()
        self.V6_06 = Tkinter.IntVar() ; self.V6_07 = Tkinter.IntVar() ; self.V6_08 = Tkinter.IntVar() ; self.V6_09 = Tkinter.IntVar() ; self.V6_10 = Tkinter.IntVar()
        self.V6_11 = Tkinter.IntVar() ; self.V6_12 = Tkinter.IntVar() ; self.V6_13 = Tkinter.IntVar() ; self.V6_14 = Tkinter.IntVar() ; self.V6_15 = Tkinter.IntVar()
        self.V6_16 = Tkinter.IntVar() ; self.V6_17 = Tkinter.IntVar() ; self.V6_18 = Tkinter.IntVar() ; self.V6_19 = Tkinter.IntVar() ; self.V6_20 = Tkinter.IntVar()
        self.V6_21 = Tkinter.IntVar() ; self.V6_22 = Tkinter.IntVar() ; self.V6_23 = Tkinter.IntVar() ; self.V6_24 = Tkinter.IntVar() ; self.V6_25 = Tkinter.IntVar()
        self.V6_26 = Tkinter.IntVar() ; self.V6_27 = Tkinter.IntVar() ; self.V6_28 = Tkinter.IntVar() ; self.V6_29 = Tkinter.IntVar() ; self.V6_30 = Tkinter.IntVar()
        self.V6_31 = Tkinter.IntVar() ; self.V6_32 = Tkinter.IntVar()
        self.V6_A1 = Tkinter.IntVar() ; self.V6_A2 = Tkinter.IntVar() ; self.V6_A3 = Tkinter.IntVar()
        ### IC 7:
        self.V7_01 = Tkinter.IntVar() ; self.V7_02 = Tkinter.IntVar() ; self.V7_03 = Tkinter.IntVar() ; self.V7_04 = Tkinter.IntVar() ; self.V7_05 = Tkinter.IntVar()
        self.V7_06 = Tkinter.IntVar() ; self.V7_07 = Tkinter.IntVar() ; self.V7_08 = Tkinter.IntVar() ; self.V7_09 = Tkinter.IntVar() ; self.V7_10 = Tkinter.IntVar()
        self.V7_11 = Tkinter.IntVar() ; self.V7_12 = Tkinter.IntVar() ; self.V7_13 = Tkinter.IntVar() ; self.V7_14 = Tkinter.IntVar() ; self.V7_15 = Tkinter.IntVar()
        self.V7_16 = Tkinter.IntVar() ; self.V7_17 = Tkinter.IntVar() ; self.V7_18 = Tkinter.IntVar() ; self.V7_19 = Tkinter.IntVar() ; self.V7_20 = Tkinter.IntVar()
        self.V7_21 = Tkinter.IntVar() ; self.V7_22 = Tkinter.IntVar() ; self.V7_23 = Tkinter.IntVar() ; self.V7_24 = Tkinter.IntVar() ; self.V7_25 = Tkinter.IntVar()
        self.V7_26 = Tkinter.IntVar() ; self.V7_27 = Tkinter.IntVar() ; self.V7_28 = Tkinter.IntVar() ; self.V7_29 = Tkinter.IntVar() ; self.V7_30 = Tkinter.IntVar()
        self.V7_31 = Tkinter.IntVar() ; self.V7_32 = Tkinter.IntVar()
        self.V7_A1 = Tkinter.IntVar() ; self.V7_A2 = Tkinter.IntVar() ; self.V7_A3 = Tkinter.IntVar()
        ### IC 8:
        self.V8_01 = Tkinter.IntVar() ; self.V8_02 = Tkinter.IntVar() ; self.V8_03 = Tkinter.IntVar() ; self.V8_04 = Tkinter.IntVar() ; self.V8_05 = Tkinter.IntVar()
        self.V8_06 = Tkinter.IntVar() ; self.V8_07 = Tkinter.IntVar() ; self.V8_08 = Tkinter.IntVar() ; self.V8_09 = Tkinter.IntVar() ; self.V8_10 = Tkinter.IntVar()
        self.V8_11 = Tkinter.IntVar() ; self.V8_12 = Tkinter.IntVar() ; self.V8_13 = Tkinter.IntVar() ; self.V8_14 = Tkinter.IntVar() ; self.V8_15 = Tkinter.IntVar()
        self.V8_16 = Tkinter.IntVar() ; self.V8_17 = Tkinter.IntVar() ; self.V8_18 = Tkinter.IntVar() ; self.V8_19 = Tkinter.IntVar() ; self.V8_20 = Tkinter.IntVar()
        self.V8_21 = Tkinter.IntVar() ; self.V8_22 = Tkinter.IntVar() ; self.V8_23 = Tkinter.IntVar() ; self.V8_24 = Tkinter.IntVar() ; self.V8_25 = Tkinter.IntVar()
        self.V8_26 = Tkinter.IntVar() ; self.V8_27 = Tkinter.IntVar() ; self.V8_28 = Tkinter.IntVar() ; self.V8_29 = Tkinter.IntVar() ; self.V8_30 = Tkinter.IntVar()
        self.V8_31 = Tkinter.IntVar() ; self.V8_32 = Tkinter.IntVar()
        self.V8_A1 = Tkinter.IntVar() ; self.V8_A2 = Tkinter.IntVar() ; self.V8_A3 = Tkinter.IntVar()

        # Info about the RHD/RHA type
        self.V_RHD = Tkinter.IntVar()
        self.RHDModel = 1
        self.V_RHD.set(1)
        self.grid()
        self.createWidgets(master)
        self.ChannelSetup_1 = []
        self.ChannelSetup_2 = []
        self.ChannelSetup_3 = []
        self.ChannelSetup_4 = []
        self.ChannelSetup_5 = []
        self.ChannelSetup_6 = []
        self.ChannelSetup_7 = []
        self.ChannelSetup_8 = []
        self.ChannelSetup_1A = []
        self.ChannelSetup_2A = []
        self.ChannelSetup_3A = []
        self.ChannelSetup_4A = []
        self.ChannelSetup_5A = []
        self.ChannelSetup_6A = []
        self.ChannelSetup_7A = []
        self.ChannelSetup_8A = []

        # define options for opening or saving a file
        self.file_opt = options = {}
        options['defaultextension'] = '.chmsk'
        options['filetypes'] = [('Channel Mask File', '.chmsk')]
        options['initialfile'] = 'default.chmsk'

    def GetChannelSetup(self):
        self.ChannelSetup_1 = [self.V1_01.get(), self.V1_02.get(), self.V1_03.get(), self.V1_04.get(), \
            self.V1_05.get(), self.V1_06.get(), self.V1_07.get(), self.V1_08.get(), \
            self.V1_09.get(), self.V1_10.get(), self.V1_11.get(), self.V1_12.get(), \
            self.V1_13.get(), self.V1_14.get(), self.V1_15.get(), self.V1_16.get(), \
            self.V1_17.get(), self.V1_18.get(), self.V1_19.get(), self.V1_20.get(), \
            self.V1_21.get(), self.V1_22.get(), self.V1_23.get(), self.V1_24.get(), \
            self.V1_25.get(), self.V1_26.get(), self.V1_27.get(), self.V1_28.get(), \
            self.V1_29.get(), self.V1_30.get(), self.V1_31.get(), self.V1_32.get() ]
        self.ChannelSetup_2 = [self.V2_01.get(), self.V2_02.get(), self.V2_03.get(), self.V2_04.get(), \
            self.V2_05.get(), self.V2_06.get(), self.V2_07.get(), self.V2_08.get(), \
            self.V2_09.get(), self.V2_10.get(), self.V2_11.get(), self.V2_12.get(), \
            self.V2_13.get(), self.V2_14.get(), self.V2_15.get(), self.V2_16.get(), \
            self.V2_17.get(), self.V2_18.get(), self.V2_19.get(), self.V2_20.get(), \
            self.V2_21.get(), self.V2_22.get(), self.V2_23.get(), self.V2_24.get(), \
            self.V2_25.get(), self.V2_26.get(), self.V2_27.get(), self.V2_28.get(), \
            self.V2_29.get(), self.V2_30.get(), self.V2_31.get(), self.V2_32.get() ]
        self.ChannelSetup_3 = [self.V3_01.get(), self.V3_02.get(), self.V3_03.get(), self.V3_04.get(), \
            self.V3_05.get(), self.V3_06.get(), self.V3_07.get(), self.V3_08.get(), \
            self.V3_09.get(), self.V3_10.get(), self.V3_11.get(), self.V3_12.get(), \
            self.V3_13.get(), self.V3_14.get(), self.V3_15.get(), self.V3_16.get(), \
            self.V3_17.get(), self.V3_18.get(), self.V3_19.get(), self.V3_20.get(), \
            self.V3_21.get(), self.V3_22.get(), self.V3_23.get(), self.V3_24.get(), \
            self.V3_25.get(), self.V3_26.get(), self.V3_27.get(), self.V3_28.get(), \
            self.V3_29.get(), self.V3_30.get(), self.V3_31.get(), self.V3_32.get() ]
        self.ChannelSetup_4 = [self.V4_01.get(), self.V4_02.get(), self.V4_03.get(), self.V4_04.get(), \
            self.V4_05.get(), self.V4_06.get(), self.V4_07.get(), self.V4_08.get(), \
            self.V4_09.get(), self.V4_10.get(), self.V4_11.get(), self.V4_12.get(), \
            self.V4_13.get(), self.V4_14.get(), self.V4_15.get(), self.V4_16.get(), \
            self.V4_17.get(), self.V4_18.get(), self.V4_19.get(), self.V4_20.get(), \
            self.V4_21.get(), self.V4_22.get(), self.V4_23.get(), self.V4_24.get(), \
            self.V4_25.get(), self.V4_26.get(), self.V4_27.get(), self.V4_28.get(), \
            self.V4_29.get(), self.V4_30.get(), self.V4_31.get(), self.V4_32.get() ]
        self.ChannelSetup_5 = [self.V5_01.get(), self.V5_02.get(), self.V5_03.get(), self.V5_04.get(), \
            self.V5_05.get(), self.V5_06.get(), self.V5_07.get(), self.V5_08.get(), \
            self.V5_09.get(), self.V5_10.get(), self.V5_11.get(), self.V5_12.get(), \
            self.V5_13.get(), self.V5_14.get(), self.V5_15.get(), self.V5_16.get(), \
            self.V5_17.get(), self.V5_18.get(), self.V5_19.get(), self.V5_20.get(), \
            self.V5_21.get(), self.V5_22.get(), self.V5_23.get(), self.V5_24.get(), \
            self.V5_25.get(), self.V5_26.get(), self.V5_27.get(), self.V5_28.get(), \
            self.V5_29.get(), self.V5_30.get(), self.V5_31.get(), self.V5_32.get() ]
        self.ChannelSetup_6 = [self.V6_01.get(), self.V6_02.get(), self.V6_03.get(), self.V6_04.get(), \
            self.V6_05.get(), self.V6_06.get(), self.V6_07.get(), self.V6_08.get(), \
            self.V6_09.get(), self.V6_10.get(), self.V6_11.get(), self.V6_12.get(), \
            self.V6_13.get(), self.V6_14.get(), self.V6_15.get(), self.V6_16.get(), \
            self.V6_17.get(), self.V6_18.get(), self.V6_19.get(), self.V6_20.get(), \
            self.V6_21.get(), self.V6_22.get(), self.V6_23.get(), self.V6_24.get(), \
            self.V6_25.get(), self.V6_26.get(), self.V6_27.get(), self.V6_28.get(), \
            self.V6_29.get(), self.V6_30.get(), self.V6_31.get(), self.V6_32.get() ]
        self.ChannelSetup_7 = [self.V7_01.get(), self.V7_02.get(), self.V7_03.get(), self.V7_04.get(), \
            self.V7_05.get(), self.V7_06.get(), self.V7_07.get(), self.V7_08.get(), \
            self.V7_09.get(), self.V7_10.get(), self.V7_11.get(), self.V7_12.get(), \
            self.V7_13.get(), self.V7_14.get(), self.V7_15.get(), self.V7_16.get(), \
            self.V7_17.get(), self.V7_18.get(), self.V7_19.get(), self.V7_20.get(), \
            self.V7_21.get(), self.V7_22.get(), self.V7_23.get(), self.V7_24.get(), \
            self.V7_25.get(), self.V7_26.get(), self.V7_27.get(), self.V7_28.get(), \
            self.V7_29.get(), self.V7_30.get(), self.V7_31.get(), self.V7_32.get() ]
        self.ChannelSetup_8 = [self.V8_01.get(), self.V8_02.get(), self.V8_03.get(), self.V8_04.get(), \
            self.V8_05.get(), self.V8_06.get(), self.V8_07.get(), self.V8_08.get(), \
            self.V8_09.get(), self.V8_10.get(), self.V8_11.get(), self.V8_12.get(), \
            self.V8_13.get(), self.V8_14.get(), self.V8_15.get(), self.V8_16.get(), \
            self.V8_17.get(), self.V8_18.get(), self.V8_19.get(), self.V8_20.get(), \
            self.V8_21.get(), self.V8_22.get(), self.V8_23.get(), self.V8_24.get(), \
            self.V8_25.get(), self.V8_26.get(), self.V8_27.get(), self.V8_28.get(), \
            self.V8_29.get(), self.V8_30.get(), self.V8_31.get(), self.V8_32.get() ]
        self.ChannelSetup_1A = [self.V1_A1.get(), self.V1_A2.get(), self.V1_A3.get()]
        self.ChannelSetup_2A = [self.V2_A1.get(), self.V2_A2.get(), self.V2_A3.get()]
        self.ChannelSetup_3A = [self.V3_A1.get(), self.V3_A2.get(), self.V3_A3.get()]
        self.ChannelSetup_4A = [self.V4_A1.get(), self.V4_A2.get(), self.V4_A3.get()]
        self.ChannelSetup_5A = [self.V5_A1.get(), self.V5_A2.get(), self.V5_A3.get()]
        self.ChannelSetup_6A = [self.V6_A1.get(), self.V6_A2.get(), self.V6_A3.get()]
        self.ChannelSetup_7A = [self.V7_A1.get(), self.V7_A2.get(), self.V7_A3.get()]
        self.ChannelSetup_8A = [self.V8_A1.get(), self.V8_A2.get(), self.V8_A3.get()]
        # RHD
        self.RHDModel = self.V_RHD.get()

    def RestoreChannelSetup(self):
        # 1
        self.V1_01.set(self.ChannelSetup_1[0]) ; self.V1_02.set(self.ChannelSetup_1[1])
        self.V1_03.set(self.ChannelSetup_1[2]) ; self.V1_04.set(self.ChannelSetup_1[3])
        self.V1_05.set(self.ChannelSetup_1[4]) ; self.V1_06.set(self.ChannelSetup_1[5])
        self.V1_07.set(self.ChannelSetup_1[6]) ; self.V1_08.set(self.ChannelSetup_1[7])
        self.V1_09.set(self.ChannelSetup_1[8]) ; self.V1_10.set(self.ChannelSetup_1[9])
        self.V1_11.set(self.ChannelSetup_1[10]) ; self.V1_12.set(self.ChannelSetup_1[11])
        self.V1_13.set(self.ChannelSetup_1[12]) ; self.V1_14.set(self.ChannelSetup_1[13])
        self.V1_15.set(self.ChannelSetup_1[14]) ; self.V1_16.set(self.ChannelSetup_1[15])
        self.V1_17.set(self.ChannelSetup_1[16]) ; self.V1_18.set(self.ChannelSetup_1[17])
        self.V1_19.set(self.ChannelSetup_1[18]) ; self.V1_20.set(self.ChannelSetup_1[19])
        self.V1_21.set(self.ChannelSetup_1[20]) ; self.V1_22.set(self.ChannelSetup_1[21])
        self.V1_23.set(self.ChannelSetup_1[22]) ; self.V1_24.set(self.ChannelSetup_1[23])
        self.V1_25.set(self.ChannelSetup_1[24]) ; self.V1_26.set(self.ChannelSetup_1[25])
        self.V1_27.set(self.ChannelSetup_1[26]) ; self.V1_28.set(self.ChannelSetup_1[27])
        self.V1_29.set(self.ChannelSetup_1[28]) ; self.V1_30.set(self.ChannelSetup_1[29])
        self.V1_31.set(self.ChannelSetup_1[30]) ; self.V1_32.set(self.ChannelSetup_1[31])
        self.V1_A1.set(self.ChannelSetup_1A[0]) ; self.V1_A2.set(self.ChannelSetup_1A[1])
        self.V1_A3.set(self.ChannelSetup_1A[2])
        # 2
        self.V2_01.set(self.ChannelSetup_2[0]) ; self.V2_02.set(self.ChannelSetup_2[1])
        self.V2_03.set(self.ChannelSetup_2[2]) ; self.V2_04.set(self.ChannelSetup_2[3])
        self.V2_05.set(self.ChannelSetup_2[4]) ; self.V2_06.set(self.ChannelSetup_2[5])
        self.V2_07.set(self.ChannelSetup_2[6]) ; self.V2_08.set(self.ChannelSetup_2[7])
        self.V2_09.set(self.ChannelSetup_2[8]) ; self.V2_10.set(self.ChannelSetup_2[9])
        self.V2_11.set(self.ChannelSetup_2[10]) ; self.V2_12.set(self.ChannelSetup_2[11])
        self.V2_13.set(self.ChannelSetup_2[12]) ; self.V2_14.set(self.ChannelSetup_2[13])
        self.V2_15.set(self.ChannelSetup_2[14]) ; self.V2_16.set(self.ChannelSetup_2[15])
        self.V2_17.set(self.ChannelSetup_2[16]) ; self.V2_18.set(self.ChannelSetup_2[17])
        self.V2_19.set(self.ChannelSetup_2[18]) ; self.V2_20.set(self.ChannelSetup_2[19])
        self.V2_21.set(self.ChannelSetup_2[20]) ; self.V2_22.set(self.ChannelSetup_2[21])
        self.V2_23.set(self.ChannelSetup_2[22]) ; self.V2_24.set(self.ChannelSetup_2[23])
        self.V2_25.set(self.ChannelSetup_2[24]) ; self.V2_26.set(self.ChannelSetup_2[25])
        self.V2_27.set(self.ChannelSetup_2[26]) ; self.V2_28.set(self.ChannelSetup_2[27])
        self.V2_29.set(self.ChannelSetup_2[28]) ; self.V2_30.set(self.ChannelSetup_2[29])
        self.V2_31.set(self.ChannelSetup_2[30]) ; self.V2_32.set(self.ChannelSetup_2[31])
        self.V2_A1.set(self.ChannelSetup_2A[0]) ; self.V2_A2.set(self.ChannelSetup_2A[1])
        self.V2_A3.set(self.ChannelSetup_2A[2])
        # 3
        self.V3_01.set(self.ChannelSetup_3[0]) ; self.V3_02.set(self.ChannelSetup_3[1])
        self.V3_03.set(self.ChannelSetup_3[2]) ; self.V3_04.set(self.ChannelSetup_3[3])
        self.V3_05.set(self.ChannelSetup_3[4]) ; self.V3_06.set(self.ChannelSetup_3[5])
        self.V3_07.set(self.ChannelSetup_3[6]) ; self.V3_08.set(self.ChannelSetup_3[7])
        self.V3_09.set(self.ChannelSetup_3[8]) ; self.V3_10.set(self.ChannelSetup_3[9])
        self.V3_11.set(self.ChannelSetup_3[10]) ; self.V3_12.set(self.ChannelSetup_3[11])
        self.V3_13.set(self.ChannelSetup_3[12]) ; self.V3_14.set(self.ChannelSetup_3[13])
        self.V3_15.set(self.ChannelSetup_3[14]) ; self.V3_16.set(self.ChannelSetup_3[15])
        self.V3_17.set(self.ChannelSetup_3[16]) ; self.V3_18.set(self.ChannelSetup_3[17])
        self.V3_19.set(self.ChannelSetup_3[18]) ; self.V3_20.set(self.ChannelSetup_3[19])
        self.V3_21.set(self.ChannelSetup_3[20]) ; self.V3_22.set(self.ChannelSetup_3[21])
        self.V3_23.set(self.ChannelSetup_3[22]) ; self.V3_24.set(self.ChannelSetup_3[23])
        self.V3_25.set(self.ChannelSetup_3[24]) ; self.V3_26.set(self.ChannelSetup_3[25])
        self.V3_27.set(self.ChannelSetup_3[26]) ; self.V3_28.set(self.ChannelSetup_3[27])
        self.V3_29.set(self.ChannelSetup_3[28]) ; self.V3_30.set(self.ChannelSetup_3[29])
        self.V3_31.set(self.ChannelSetup_3[30]) ; self.V3_32.set(self.ChannelSetup_3[31])
        self.V3_A1.set(self.ChannelSetup_3A[0]) ; self.V3_A2.set(self.ChannelSetup_3A[1])
        self.V3_A3.set(self.ChannelSetup_3A[2])
        # 4
        self.V4_01.set(self.ChannelSetup_4[0]) ; self.V4_02.set(self.ChannelSetup_4[1])
        self.V4_03.set(self.ChannelSetup_4[2]) ; self.V4_04.set(self.ChannelSetup_4[3])
        self.V4_05.set(self.ChannelSetup_4[4]) ; self.V4_06.set(self.ChannelSetup_4[5])
        self.V4_07.set(self.ChannelSetup_4[6]) ; self.V4_08.set(self.ChannelSetup_4[7])
        self.V4_09.set(self.ChannelSetup_4[8]) ; self.V4_10.set(self.ChannelSetup_4[9])
        self.V4_11.set(self.ChannelSetup_4[10]) ; self.V4_12.set(self.ChannelSetup_4[11])
        self.V4_13.set(self.ChannelSetup_4[12]) ; self.V4_14.set(self.ChannelSetup_4[13])
        self.V4_15.set(self.ChannelSetup_4[14]) ; self.V4_16.set(self.ChannelSetup_4[15])
        self.V4_17.set(self.ChannelSetup_4[16]) ; self.V4_18.set(self.ChannelSetup_4[17])
        self.V4_19.set(self.ChannelSetup_4[18]) ; self.V4_20.set(self.ChannelSetup_4[19])
        self.V4_21.set(self.ChannelSetup_4[20]) ; self.V4_22.set(self.ChannelSetup_4[21])
        self.V4_23.set(self.ChannelSetup_4[22]) ; self.V4_24.set(self.ChannelSetup_4[23])
        self.V4_25.set(self.ChannelSetup_4[24]) ; self.V4_26.set(self.ChannelSetup_4[25])
        self.V4_27.set(self.ChannelSetup_4[26]) ; self.V4_28.set(self.ChannelSetup_4[27])
        self.V4_29.set(self.ChannelSetup_4[28]) ; self.V4_30.set(self.ChannelSetup_4[29])
        self.V4_31.set(self.ChannelSetup_4[30]) ; self.V4_32.set(self.ChannelSetup_4[31])
        self.V4_A1.set(self.ChannelSetup_4A[0]) ; self.V4_A2.set(self.ChannelSetup_4A[1])
        self.V4_A3.set(self.ChannelSetup_4A[2])
        # 5
        self.V5_01.set(self.ChannelSetup_5[0]) ; self.V5_02.set(self.ChannelSetup_5[1])
        self.V5_03.set(self.ChannelSetup_5[2]) ; self.V5_04.set(self.ChannelSetup_5[3])
        self.V5_05.set(self.ChannelSetup_5[4]) ; self.V5_06.set(self.ChannelSetup_5[5])
        self.V5_07.set(self.ChannelSetup_5[6]) ; self.V5_08.set(self.ChannelSetup_5[7])
        self.V5_09.set(self.ChannelSetup_5[8]) ; self.V5_10.set(self.ChannelSetup_5[9])
        self.V5_11.set(self.ChannelSetup_5[10]) ; self.V5_12.set(self.ChannelSetup_5[11])
        self.V5_13.set(self.ChannelSetup_5[12]) ; self.V5_14.set(self.ChannelSetup_5[13])
        self.V5_15.set(self.ChannelSetup_5[14]) ; self.V5_16.set(self.ChannelSetup_5[15])
        self.V5_17.set(self.ChannelSetup_5[16]) ; self.V5_18.set(self.ChannelSetup_5[17])
        self.V5_19.set(self.ChannelSetup_5[18]) ; self.V5_20.set(self.ChannelSetup_5[19])
        self.V5_21.set(self.ChannelSetup_5[20]) ; self.V5_22.set(self.ChannelSetup_5[21])
        self.V5_23.set(self.ChannelSetup_5[22]) ; self.V5_24.set(self.ChannelSetup_5[23])
        self.V5_25.set(self.ChannelSetup_5[24]) ; self.V5_26.set(self.ChannelSetup_5[25])
        self.V5_27.set(self.ChannelSetup_5[26]) ; self.V5_28.set(self.ChannelSetup_5[27])
        self.V5_29.set(self.ChannelSetup_5[28]) ; self.V5_30.set(self.ChannelSetup_5[29])
        self.V5_31.set(self.ChannelSetup_5[30]) ; self.V5_32.set(self.ChannelSetup_5[31])
        self.V5_A1.set(self.ChannelSetup_5A[0]) ; self.V5_A2.set(self.ChannelSetup_5A[1])
        self.V5_A3.set(self.ChannelSetup_5A[2])
        # 6
        self.V6_01.set(self.ChannelSetup_6[0]) ; self.V6_02.set(self.ChannelSetup_6[1])
        self.V6_03.set(self.ChannelSetup_6[2]) ; self.V6_04.set(self.ChannelSetup_6[3])
        self.V6_05.set(self.ChannelSetup_6[4]) ; self.V6_06.set(self.ChannelSetup_6[5])
        self.V6_07.set(self.ChannelSetup_6[6]) ; self.V6_08.set(self.ChannelSetup_6[7])
        self.V6_09.set(self.ChannelSetup_6[8]) ; self.V6_10.set(self.ChannelSetup_6[9])
        self.V6_11.set(self.ChannelSetup_6[10]) ; self.V6_12.set(self.ChannelSetup_6[11])
        self.V6_13.set(self.ChannelSetup_6[12]) ; self.V6_14.set(self.ChannelSetup_6[13])
        self.V6_15.set(self.ChannelSetup_6[14]) ; self.V6_16.set(self.ChannelSetup_6[15])
        self.V6_17.set(self.ChannelSetup_6[16]) ; self.V6_18.set(self.ChannelSetup_6[17])
        self.V6_19.set(self.ChannelSetup_6[18]) ; self.V6_20.set(self.ChannelSetup_6[19])
        self.V6_21.set(self.ChannelSetup_6[20]) ; self.V6_22.set(self.ChannelSetup_6[21])
        self.V6_23.set(self.ChannelSetup_6[22]) ; self.V6_24.set(self.ChannelSetup_6[23])
        self.V6_25.set(self.ChannelSetup_6[24]) ; self.V6_26.set(self.ChannelSetup_6[25])
        self.V6_27.set(self.ChannelSetup_6[26]) ; self.V6_28.set(self.ChannelSetup_6[27])
        self.V6_29.set(self.ChannelSetup_6[28]) ; self.V6_30.set(self.ChannelSetup_6[29])
        self.V6_31.set(self.ChannelSetup_6[30]) ; self.V6_32.set(self.ChannelSetup_6[31])
        self.V6_A1.set(self.ChannelSetup_6A[0]) ; self.V6_A2.set(self.ChannelSetup_6A[1])
        self.V6_A3.set(self.ChannelSetup_6A[2])
        # 7
        self.V7_01.set(self.ChannelSetup_7[0]) ; self.V7_02.set(self.ChannelSetup_7[1])
        self.V7_03.set(self.ChannelSetup_7[2]) ; self.V7_04.set(self.ChannelSetup_7[3])
        self.V7_05.set(self.ChannelSetup_7[4]) ; self.V7_06.set(self.ChannelSetup_7[5])
        self.V7_07.set(self.ChannelSetup_7[6]) ; self.V7_08.set(self.ChannelSetup_7[7])
        self.V7_09.set(self.ChannelSetup_7[8]) ; self.V7_10.set(self.ChannelSetup_7[9])
        self.V7_11.set(self.ChannelSetup_7[10]) ; self.V7_12.set(self.ChannelSetup_7[11])
        self.V7_13.set(self.ChannelSetup_7[12]) ; self.V7_14.set(self.ChannelSetup_7[13])
        self.V7_15.set(self.ChannelSetup_7[14]) ; self.V7_16.set(self.ChannelSetup_7[15])
        self.V7_17.set(self.ChannelSetup_7[16]) ; self.V7_18.set(self.ChannelSetup_7[17])
        self.V7_19.set(self.ChannelSetup_7[18]) ; self.V7_20.set(self.ChannelSetup_7[19])
        self.V7_21.set(self.ChannelSetup_7[20]) ; self.V7_22.set(self.ChannelSetup_7[21])
        self.V7_23.set(self.ChannelSetup_7[22]) ; self.V7_24.set(self.ChannelSetup_7[23])
        self.V7_25.set(self.ChannelSetup_7[24]) ; self.V7_26.set(self.ChannelSetup_7[25])
        self.V7_27.set(self.ChannelSetup_7[26]) ; self.V7_28.set(self.ChannelSetup_7[27])
        self.V7_29.set(self.ChannelSetup_7[28]) ; self.V7_30.set(self.ChannelSetup_7[29])
        self.V7_31.set(self.ChannelSetup_7[30]) ; self.V7_32.set(self.ChannelSetup_7[31])
        self.V7_A1.set(self.ChannelSetup_7A[0]) ; self.V7_A2.set(self.ChannelSetup_7A[1])
        self.V7_A3.set(self.ChannelSetup_7A[2])
        # 8
        self.V8_01.set(self.ChannelSetup_8[0]) ; self.V8_02.set(self.ChannelSetup_8[1])
        self.V8_03.set(self.ChannelSetup_8[2]) ; self.V8_04.set(self.ChannelSetup_8[3])
        self.V8_05.set(self.ChannelSetup_8[4]) ; self.V8_06.set(self.ChannelSetup_8[5])
        self.V8_07.set(self.ChannelSetup_8[6]) ; self.V8_08.set(self.ChannelSetup_8[7])
        self.V8_09.set(self.ChannelSetup_8[8]) ; self.V8_10.set(self.ChannelSetup_8[9])
        self.V8_11.set(self.ChannelSetup_8[10]) ; self.V8_12.set(self.ChannelSetup_8[11])
        self.V8_13.set(self.ChannelSetup_8[12]) ; self.V8_14.set(self.ChannelSetup_8[13])
        self.V8_15.set(self.ChannelSetup_8[14]) ; self.V8_16.set(self.ChannelSetup_8[15])
        self.V8_17.set(self.ChannelSetup_8[16]) ; self.V8_18.set(self.ChannelSetup_8[17])
        self.V8_19.set(self.ChannelSetup_8[18]) ; self.V8_20.set(self.ChannelSetup_8[19])
        self.V8_21.set(self.ChannelSetup_8[20]) ; self.V8_22.set(self.ChannelSetup_8[21])
        self.V8_23.set(self.ChannelSetup_8[22]) ; self.V8_24.set(self.ChannelSetup_8[23])
        self.V8_25.set(self.ChannelSetup_8[24]) ; self.V8_26.set(self.ChannelSetup_8[25])
        self.V8_27.set(self.ChannelSetup_8[26]) ; self.V8_28.set(self.ChannelSetup_8[27])
        self.V8_29.set(self.ChannelSetup_8[28]) ; self.V8_30.set(self.ChannelSetup_8[29])
        self.V8_31.set(self.ChannelSetup_8[30]) ; self.V8_32.set(self.ChannelSetup_8[31])
        self.V8_A1.set(self.ChannelSetup_8A[0]) ; self.V1_A2.set(self.ChannelSetup_8A[1])
        self.V8_A3.set(self.ChannelSetup_8A[2])
        # RHD
        self.V_RHD.set(self.RHDModel)

    def SetSingleChannel(self,C,V):
        if V.get() == 1:
            C.select()
        else:
            C.deselect()

    def SetChannelSet(self):
        # 1
        self.SetSingleChannel(self.C1_01,self.V1_01) ; self.SetSingleChannel(self.C1_02,self.V1_02)
        self.SetSingleChannel(self.C1_03,self.V1_03) ; self.SetSingleChannel(self.C1_04,self.V1_04)
        self.SetSingleChannel(self.C1_05,self.V1_05) ; self.SetSingleChannel(self.C1_06,self.V1_06)
        self.SetSingleChannel(self.C1_07,self.V1_07) ; self.SetSingleChannel(self.C1_08,self.V1_08)
        self.SetSingleChannel(self.C1_09,self.V1_09) ; self.SetSingleChannel(self.C1_10,self.V1_10)
        self.SetSingleChannel(self.C1_11,self.V1_11) ; self.SetSingleChannel(self.C1_12,self.V1_12)
        self.SetSingleChannel(self.C1_13,self.V1_13) ; self.SetSingleChannel(self.C1_14,self.V1_14)
        self.SetSingleChannel(self.C1_15,self.V1_15) ; self.SetSingleChannel(self.C1_16,self.V1_16)
        self.SetSingleChannel(self.C1_17,self.V1_17) ; self.SetSingleChannel(self.C1_18,self.V1_18)
        self.SetSingleChannel(self.C1_19,self.V1_19) ; self.SetSingleChannel(self.C1_20,self.V1_20)
        self.SetSingleChannel(self.C1_21,self.V1_21) ; self.SetSingleChannel(self.C1_22,self.V1_22)
        self.SetSingleChannel(self.C1_23,self.V1_23) ; self.SetSingleChannel(self.C1_24,self.V1_24)
        self.SetSingleChannel(self.C1_25,self.V1_25) ; self.SetSingleChannel(self.C1_26,self.V1_26)
        self.SetSingleChannel(self.C1_27,self.V1_27) ; self.SetSingleChannel(self.C1_28,self.V1_28)
        self.SetSingleChannel(self.C1_29,self.V1_29) ; self.SetSingleChannel(self.C1_30,self.V1_30)
        self.SetSingleChannel(self.C1_31,self.V1_31) ; self.SetSingleChannel(self.C1_32,self.V1_32)
        self.SetSingleChannel(self.C1_A1,self.V1_A1) ; self.SetSingleChannel(self.C1_A2,self.V1_A2)
        self.SetSingleChannel(self.C1_A3,self.V1_A3)
        # 2
        self.SetSingleChannel(self.C2_01,self.V2_01) ; self.SetSingleChannel(self.C2_02,self.V2_02)
        self.SetSingleChannel(self.C2_03,self.V2_03) ; self.SetSingleChannel(self.C2_04,self.V2_04)
        self.SetSingleChannel(self.C2_05,self.V2_05) ; self.SetSingleChannel(self.C2_06,self.V2_06)
        self.SetSingleChannel(self.C2_07,self.V2_07) ; self.SetSingleChannel(self.C2_08,self.V2_08)
        self.SetSingleChannel(self.C2_09,self.V2_09) ; self.SetSingleChannel(self.C2_10,self.V2_10)
        self.SetSingleChannel(self.C2_11,self.V2_11) ; self.SetSingleChannel(self.C2_12,self.V2_12)
        self.SetSingleChannel(self.C2_13,self.V2_13) ; self.SetSingleChannel(self.C2_14,self.V2_14)
        self.SetSingleChannel(self.C2_15,self.V2_15) ; self.SetSingleChannel(self.C2_16,self.V2_16)
        self.SetSingleChannel(self.C2_17,self.V2_17) ; self.SetSingleChannel(self.C2_18,self.V2_18)
        self.SetSingleChannel(self.C2_19,self.V2_19) ; self.SetSingleChannel(self.C2_20,self.V2_20)
        self.SetSingleChannel(self.C2_21,self.V2_21) ; self.SetSingleChannel(self.C2_22,self.V2_22)
        self.SetSingleChannel(self.C2_23,self.V2_23) ; self.SetSingleChannel(self.C2_24,self.V2_24)
        self.SetSingleChannel(self.C2_25,self.V2_25) ; self.SetSingleChannel(self.C2_26,self.V2_26)
        self.SetSingleChannel(self.C2_27,self.V2_27) ; self.SetSingleChannel(self.C2_28,self.V2_28)
        self.SetSingleChannel(self.C2_29,self.V2_29) ; self.SetSingleChannel(self.C2_30,self.V2_30)
        self.SetSingleChannel(self.C2_31,self.V2_31) ; self.SetSingleChannel(self.C2_32,self.V2_32)
        self.SetSingleChannel(self.C2_A1,self.V2_A1) ; self.SetSingleChannel(self.C2_A2,self.V2_A2)
        self.SetSingleChannel(self.C2_A3,self.V2_A3)
        # 3
        self.SetSingleChannel(self.C3_01,self.V3_01) ; self.SetSingleChannel(self.C3_02,self.V3_02)
        self.SetSingleChannel(self.C3_03,self.V3_03) ; self.SetSingleChannel(self.C3_04,self.V3_04)
        self.SetSingleChannel(self.C3_05,self.V3_05) ; self.SetSingleChannel(self.C3_06,self.V3_06)
        self.SetSingleChannel(self.C3_07,self.V3_07) ; self.SetSingleChannel(self.C3_08,self.V3_08)
        self.SetSingleChannel(self.C3_09,self.V3_09) ; self.SetSingleChannel(self.C3_10,self.V3_10)
        self.SetSingleChannel(self.C3_11,self.V3_11) ; self.SetSingleChannel(self.C3_12,self.V3_12)
        self.SetSingleChannel(self.C3_13,self.V3_13) ; self.SetSingleChannel(self.C3_14,self.V3_14)
        self.SetSingleChannel(self.C3_15,self.V3_15) ; self.SetSingleChannel(self.C3_16,self.V3_16)
        self.SetSingleChannel(self.C3_17,self.V3_17) ; self.SetSingleChannel(self.C3_18,self.V3_18)
        self.SetSingleChannel(self.C3_19,self.V3_19) ; self.SetSingleChannel(self.C3_20,self.V3_20)
        self.SetSingleChannel(self.C3_21,self.V3_21) ; self.SetSingleChannel(self.C3_22,self.V3_22)
        self.SetSingleChannel(self.C3_23,self.V3_23) ; self.SetSingleChannel(self.C3_24,self.V3_24)
        self.SetSingleChannel(self.C3_25,self.V3_25) ; self.SetSingleChannel(self.C3_26,self.V3_26)
        self.SetSingleChannel(self.C3_27,self.V3_27) ; self.SetSingleChannel(self.C3_28,self.V3_28)
        self.SetSingleChannel(self.C3_29,self.V3_29) ; self.SetSingleChannel(self.C3_30,self.V3_30)
        self.SetSingleChannel(self.C3_31,self.V3_31) ; self.SetSingleChannel(self.C3_32,self.V3_32)
        self.SetSingleChannel(self.C3_A1,self.V3_A1) ; self.SetSingleChannel(self.C3_A2,self.V3_A2)
        self.SetSingleChannel(self.C3_A3,self.V3_A3)
        # 4
        self.SetSingleChannel(self.C4_01,self.V4_01) ; self.SetSingleChannel(self.C4_02,self.V4_02)
        self.SetSingleChannel(self.C4_03,self.V4_03) ; self.SetSingleChannel(self.C4_04,self.V4_04)
        self.SetSingleChannel(self.C4_05,self.V4_05) ; self.SetSingleChannel(self.C4_06,self.V4_06)
        self.SetSingleChannel(self.C4_07,self.V4_07) ; self.SetSingleChannel(self.C4_08,self.V4_08)
        self.SetSingleChannel(self.C4_09,self.V4_09) ; self.SetSingleChannel(self.C4_10,self.V4_10)
        self.SetSingleChannel(self.C4_11,self.V4_11) ; self.SetSingleChannel(self.C4_12,self.V4_12)
        self.SetSingleChannel(self.C4_13,self.V4_13) ; self.SetSingleChannel(self.C4_14,self.V4_14)
        self.SetSingleChannel(self.C4_15,self.V4_15) ; self.SetSingleChannel(self.C4_16,self.V4_16)
        self.SetSingleChannel(self.C4_17,self.V4_17) ; self.SetSingleChannel(self.C4_18,self.V4_18)
        self.SetSingleChannel(self.C4_19,self.V4_19) ; self.SetSingleChannel(self.C4_20,self.V4_20)
        self.SetSingleChannel(self.C4_21,self.V4_21) ; self.SetSingleChannel(self.C4_22,self.V4_22)
        self.SetSingleChannel(self.C4_23,self.V4_23) ; self.SetSingleChannel(self.C4_24,self.V4_24)
        self.SetSingleChannel(self.C4_25,self.V4_25) ; self.SetSingleChannel(self.C4_26,self.V4_26)
        self.SetSingleChannel(self.C4_27,self.V4_27) ; self.SetSingleChannel(self.C4_28,self.V4_28)
        self.SetSingleChannel(self.C4_29,self.V4_29) ; self.SetSingleChannel(self.C4_30,self.V4_30)
        self.SetSingleChannel(self.C4_31,self.V4_31) ; self.SetSingleChannel(self.C4_32,self.V4_32)
        self.SetSingleChannel(self.C4_A1,self.V4_A1) ; self.SetSingleChannel(self.C4_A2,self.V4_A2)
        self.SetSingleChannel(self.C4_A3,self.V4_A3)
        # 5
        self.SetSingleChannel(self.C5_01,self.V5_01) ; self.SetSingleChannel(self.C5_02,self.V5_02)
        self.SetSingleChannel(self.C5_03,self.V5_03) ; self.SetSingleChannel(self.C5_04,self.V5_04)
        self.SetSingleChannel(self.C5_05,self.V5_05) ; self.SetSingleChannel(self.C5_06,self.V5_06)
        self.SetSingleChannel(self.C5_07,self.V5_07) ; self.SetSingleChannel(self.C5_08,self.V5_08)
        self.SetSingleChannel(self.C5_09,self.V5_09) ; self.SetSingleChannel(self.C5_10,self.V5_10)
        self.SetSingleChannel(self.C5_11,self.V5_11) ; self.SetSingleChannel(self.C5_12,self.V5_12)
        self.SetSingleChannel(self.C5_13,self.V5_13) ; self.SetSingleChannel(self.C5_14,self.V5_14)
        self.SetSingleChannel(self.C5_15,self.V5_15) ; self.SetSingleChannel(self.C5_16,self.V5_16)
        self.SetSingleChannel(self.C5_17,self.V5_17) ; self.SetSingleChannel(self.C5_18,self.V5_18)
        self.SetSingleChannel(self.C5_19,self.V5_19) ; self.SetSingleChannel(self.C5_20,self.V5_20)
        self.SetSingleChannel(self.C5_21,self.V5_21) ; self.SetSingleChannel(self.C5_22,self.V5_22)
        self.SetSingleChannel(self.C5_23,self.V5_23) ; self.SetSingleChannel(self.C5_24,self.V5_24)
        self.SetSingleChannel(self.C5_25,self.V5_25) ; self.SetSingleChannel(self.C5_26,self.V5_26)
        self.SetSingleChannel(self.C5_27,self.V5_27) ; self.SetSingleChannel(self.C5_28,self.V5_28)
        self.SetSingleChannel(self.C5_29,self.V5_29) ; self.SetSingleChannel(self.C5_30,self.V5_30)
        self.SetSingleChannel(self.C5_31,self.V5_31) ; self.SetSingleChannel(self.C5_32,self.V5_32)
        self.SetSingleChannel(self.C5_A1,self.V5_A1) ; self.SetSingleChannel(self.C5_A2,self.V5_A2)
        self.SetSingleChannel(self.C5_A3,self.V5_A3)
        # 6
        self.SetSingleChannel(self.C6_01,self.V6_01) ; self.SetSingleChannel(self.C6_02,self.V6_02)
        self.SetSingleChannel(self.C6_03,self.V6_03) ; self.SetSingleChannel(self.C6_04,self.V6_04)
        self.SetSingleChannel(self.C6_05,self.V6_05) ; self.SetSingleChannel(self.C6_06,self.V6_06)
        self.SetSingleChannel(self.C6_07,self.V6_07) ; self.SetSingleChannel(self.C6_08,self.V6_08)
        self.SetSingleChannel(self.C6_09,self.V6_09) ; self.SetSingleChannel(self.C6_10,self.V6_10)
        self.SetSingleChannel(self.C6_11,self.V6_11) ; self.SetSingleChannel(self.C6_12,self.V6_12)
        self.SetSingleChannel(self.C6_13,self.V6_13) ; self.SetSingleChannel(self.C6_14,self.V6_14)
        self.SetSingleChannel(self.C6_15,self.V6_15) ; self.SetSingleChannel(self.C6_16,self.V6_16)
        self.SetSingleChannel(self.C6_17,self.V6_17) ; self.SetSingleChannel(self.C6_18,self.V6_18)
        self.SetSingleChannel(self.C6_19,self.V6_19) ; self.SetSingleChannel(self.C6_20,self.V6_20)
        self.SetSingleChannel(self.C6_21,self.V6_21) ; self.SetSingleChannel(self.C6_22,self.V6_22)
        self.SetSingleChannel(self.C6_23,self.V6_23) ; self.SetSingleChannel(self.C6_24,self.V6_24)
        self.SetSingleChannel(self.C6_25,self.V6_25) ; self.SetSingleChannel(self.C6_26,self.V6_26)
        self.SetSingleChannel(self.C6_27,self.V6_27) ; self.SetSingleChannel(self.C6_28,self.V6_28)
        self.SetSingleChannel(self.C6_29,self.V6_29) ; self.SetSingleChannel(self.C6_30,self.V6_30)
        self.SetSingleChannel(self.C6_31,self.V6_31) ; self.SetSingleChannel(self.C6_32,self.V6_32)
        self.SetSingleChannel(self.C6_A1,self.V6_A1) ; self.SetSingleChannel(self.C6_A2,self.V6_A2)
        self.SetSingleChannel(self.C6_A3,self.V6_A3)
        # 7
        self.SetSingleChannel(self.C7_01,self.V7_01) ; self.SetSingleChannel(self.C7_02,self.V7_02)
        self.SetSingleChannel(self.C7_03,self.V7_03) ; self.SetSingleChannel(self.C7_04,self.V7_04)
        self.SetSingleChannel(self.C7_05,self.V7_05) ; self.SetSingleChannel(self.C7_06,self.V7_06)
        self.SetSingleChannel(self.C7_07,self.V7_07) ; self.SetSingleChannel(self.C7_08,self.V7_08)
        self.SetSingleChannel(self.C7_09,self.V7_09) ; self.SetSingleChannel(self.C7_10,self.V7_10)
        self.SetSingleChannel(self.C7_11,self.V7_11) ; self.SetSingleChannel(self.C7_12,self.V7_12)
        self.SetSingleChannel(self.C7_13,self.V7_13) ; self.SetSingleChannel(self.C7_14,self.V7_14)
        self.SetSingleChannel(self.C7_15,self.V7_15) ; self.SetSingleChannel(self.C7_16,self.V7_16)
        self.SetSingleChannel(self.C7_17,self.V7_17) ; self.SetSingleChannel(self.C7_18,self.V7_18)
        self.SetSingleChannel(self.C7_19,self.V7_19) ; self.SetSingleChannel(self.C7_20,self.V7_20)
        self.SetSingleChannel(self.C7_21,self.V7_21) ; self.SetSingleChannel(self.C7_22,self.V7_22)
        self.SetSingleChannel(self.C7_23,self.V7_23) ; self.SetSingleChannel(self.C7_24,self.V7_24)
        self.SetSingleChannel(self.C7_25,self.V7_25) ; self.SetSingleChannel(self.C7_26,self.V7_26)
        self.SetSingleChannel(self.C7_27,self.V7_27) ; self.SetSingleChannel(self.C7_28,self.V7_28)
        self.SetSingleChannel(self.C7_29,self.V7_29) ; self.SetSingleChannel(self.C7_30,self.V7_30)
        self.SetSingleChannel(self.C7_31,self.V7_31) ; self.SetSingleChannel(self.C7_32,self.V7_32)
        self.SetSingleChannel(self.C7_A1,self.V7_A1) ; self.SetSingleChannel(self.C7_A2,self.V7_A2)
        self.SetSingleChannel(self.C7_A3,self.V7_A3)
        # 8
        self.SetSingleChannel(self.C8_01,self.V8_01) ; self.SetSingleChannel(self.C8_02,self.V8_02)
        self.SetSingleChannel(self.C8_03,self.V8_03) ; self.SetSingleChannel(self.C8_04,self.V8_04)
        self.SetSingleChannel(self.C8_05,self.V8_05) ; self.SetSingleChannel(self.C8_06,self.V8_06)
        self.SetSingleChannel(self.C8_07,self.V8_07) ; self.SetSingleChannel(self.C8_08,self.V8_08)
        self.SetSingleChannel(self.C8_09,self.V8_09) ; self.SetSingleChannel(self.C8_10,self.V8_10)
        self.SetSingleChannel(self.C8_11,self.V8_11) ; self.SetSingleChannel(self.C8_12,self.V8_12)
        self.SetSingleChannel(self.C8_13,self.V8_13) ; self.SetSingleChannel(self.C8_14,self.V8_14)
        self.SetSingleChannel(self.C8_15,self.V8_15) ; self.SetSingleChannel(self.C8_16,self.V8_16)
        self.SetSingleChannel(self.C8_17,self.V8_17) ; self.SetSingleChannel(self.C8_18,self.V8_18)
        self.SetSingleChannel(self.C8_19,self.V8_19) ; self.SetSingleChannel(self.C8_20,self.V8_20)
        self.SetSingleChannel(self.C8_21,self.V8_21) ; self.SetSingleChannel(self.C8_22,self.V8_22)
        self.SetSingleChannel(self.C8_23,self.V8_23) ; self.SetSingleChannel(self.C8_24,self.V8_24)
        self.SetSingleChannel(self.C8_25,self.V8_25) ; self.SetSingleChannel(self.C8_26,self.V8_26)
        self.SetSingleChannel(self.C8_27,self.V8_27) ; self.SetSingleChannel(self.C8_28,self.V8_28)
        self.SetSingleChannel(self.C8_29,self.V8_29) ; self.SetSingleChannel(self.C8_30,self.V8_30)
        self.SetSingleChannel(self.C8_31,self.V8_31) ; self.SetSingleChannel(self.C8_32,self.V8_32)
        self.SetSingleChannel(self.C8_A1,self.V8_A1) ; self.SetSingleChannel(self.C8_A2,self.V8_A2)
        self.SetSingleChannel(self.C8_A3,self.V8_A3)
        #RHD
        self.SetSingleChannel(self.C_RHD,self.V_RHD)

    def SetViewRHAMode(self):
        # 1
        if self.RHDModel == 0:
            self.C1_17.config(state="disable"); self.C1_18.config(state="disable")
            self.C1_19.config(state="disable"); self.C1_20.config(state="disable")
            self.C1_21.config(state="disable"); self.C1_22.config(state="disable")
            self.C1_23.config(state="disable"); self.C1_24.config(state="disable")
            self.C1_25.config(state="disable"); self.C1_26.config(state="disable")
            self.C1_27.config(state="disable"); self.C1_28.config(state="disable")
            self.C1_29.config(state="disable"); self.C1_30.config(state="disable")
            self.C1_31.config(state="disable"); self.C1_32.config(state="disable")
            self.C1_A1.config(state="disable"); self.C1_A2.config(state="disable")
            self.C1_A3.config(state="disable");
        else:
            self.C1_17.config(state="normal"); self.C1_18.config(state="normal")
            self.C1_19.config(state="normal"); self.C1_20.config(state="normal")
            self.C1_21.config(state="normal"); self.C1_22.config(state="normal")
            self.C1_23.config(state="normal"); self.C1_24.config(state="normal")
            self.C1_25.config(state="normal"); self.C1_26.config(state="normal")
            self.C1_27.config(state="normal"); self.C1_28.config(state="normal")
            self.C1_29.config(state="normal"); self.C1_30.config(state="normal")
            self.C1_31.config(state="normal"); self.C1_32.config(state="normal")
            self.C1_A1.config(state="normal"); self.C1_A2.config(state="normal")
            self.C1_A3.config(state="normal");
        # 2
        if self.RHDModel == 0:
            self.C2_17.config(state="disable"); self.C2_18.config(state="disable")
            self.C2_19.config(state="disable"); self.C2_20.config(state="disable")
            self.C2_21.config(state="disable"); self.C2_22.config(state="disable")
            self.C2_23.config(state="disable"); self.C2_24.config(state="disable")
            self.C2_25.config(state="disable"); self.C2_26.config(state="disable")
            self.C2_27.config(state="disable"); self.C2_28.config(state="disable")
            self.C2_29.config(state="disable"); self.C2_30.config(state="disable")
            self.C2_31.config(state="disable"); self.C2_32.config(state="disable")
            self.C2_A1.config(state="disable"); self.C2_A2.config(state="disable")
            self.C2_A3.config(state="disable");
        else:
            self.C2_17.config(state="normal"); self.C2_18.config(state="normal")
            self.C2_19.config(state="normal"); self.C2_20.config(state="normal")
            self.C2_21.config(state="normal"); self.C2_22.config(state="normal")
            self.C2_23.config(state="normal"); self.C2_24.config(state="normal")
            self.C2_25.config(state="normal"); self.C2_26.config(state="normal")
            self.C2_27.config(state="normal"); self.C2_28.config(state="normal")
            self.C2_29.config(state="normal"); self.C2_30.config(state="normal")
            self.C2_31.config(state="normal"); self.C2_32.config(state="normal")
            self.C2_A1.config(state="normal"); self.C2_A2.config(state="normal")
            self.C2_A3.config(state="normal");
        # 3
        if self.RHDModel == 0:
            self.C3_17.config(state="disable"); self.C3_18.config(state="disable")
            self.C3_19.config(state="disable"); self.C3_20.config(state="disable")
            self.C3_21.config(state="disable"); self.C3_22.config(state="disable")
            self.C3_23.config(state="disable"); self.C3_24.config(state="disable")
            self.C3_25.config(state="disable"); self.C3_26.config(state="disable")
            self.C3_27.config(state="disable"); self.C3_28.config(state="disable")
            self.C3_29.config(state="disable"); self.C3_30.config(state="disable")
            self.C3_31.config(state="disable"); self.C3_32.config(state="disable")
            self.C3_A1.config(state="disable"); self.C3_A2.config(state="disable")
            self.C3_A3.config(state="disable");
        else:
            self.C3_17.config(state="normal"); self.C3_18.config(state="normal")
            self.C3_19.config(state="normal"); self.C3_20.config(state="normal")
            self.C3_21.config(state="normal"); self.C3_22.config(state="normal")
            self.C3_23.config(state="normal"); self.C3_24.config(state="normal")
            self.C3_25.config(state="normal"); self.C3_26.config(state="normal")
            self.C3_27.config(state="normal"); self.C3_28.config(state="normal")
            self.C3_29.config(state="normal"); self.C3_30.config(state="normal")
            self.C3_31.config(state="normal"); self.C3_32.config(state="normal")
            self.C3_A1.config(state="normal"); self.C3_A2.config(state="normal")
            self.C3_A3.config(state="normal");
        # 4
        if self.RHDModel == 0:
            self.C4_17.config(state="disable"); self.C4_18.config(state="disable")
            self.C4_19.config(state="disable"); self.C4_20.config(state="disable")
            self.C4_21.config(state="disable"); self.C4_22.config(state="disable")
            self.C4_23.config(state="disable"); self.C4_24.config(state="disable")
            self.C4_25.config(state="disable"); self.C4_26.config(state="disable")
            self.C4_27.config(state="disable"); self.C4_28.config(state="disable")
            self.C4_29.config(state="disable"); self.C4_30.config(state="disable")
            self.C4_31.config(state="disable"); self.C4_32.config(state="disable")
            self.C4_A1.config(state="disable"); self.C4_A2.config(state="disable")
            self.C4_A3.config(state="disable");
        else:
            self.C4_17.config(state="normal"); self.C4_18.config(state="normal")
            self.C4_19.config(state="normal"); self.C4_20.config(state="normal")
            self.C4_21.config(state="normal"); self.C4_22.config(state="normal")
            self.C4_23.config(state="normal"); self.C4_24.config(state="normal")
            self.C4_25.config(state="normal"); self.C4_26.config(state="normal")
            self.C4_27.config(state="normal"); self.C4_28.config(state="normal")
            self.C4_29.config(state="normal"); self.C4_30.config(state="normal")
            self.C4_31.config(state="normal"); self.C4_32.config(state="normal")
            self.C4_A1.config(state="normal"); self.C4_A2.config(state="normal")
            self.C4_A3.config(state="normal");
        # 5
        if self.RHDModel == 0:
            self.C5_17.config(state="disable"); self.C5_18.config(state="disable")
            self.C5_19.config(state="disable"); self.C5_20.config(state="disable")
            self.C5_21.config(state="disable"); self.C5_22.config(state="disable")
            self.C5_23.config(state="disable"); self.C5_24.config(state="disable")
            self.C5_25.config(state="disable"); self.C5_26.config(state="disable")
            self.C5_27.config(state="disable"); self.C5_28.config(state="disable")
            self.C5_29.config(state="disable"); self.C5_30.config(state="disable")
            self.C5_31.config(state="disable"); self.C5_32.config(state="disable")
            self.C5_A1.config(state="disable"); self.C5_A2.config(state="disable")
            self.C5_A3.config(state="disable");
        else:
            self.C5_17.config(state="normal"); self.C5_18.config(state="normal")
            self.C5_19.config(state="normal"); self.C5_20.config(state="normal")
            self.C5_21.config(state="normal"); self.C5_22.config(state="normal")
            self.C5_23.config(state="normal"); self.C5_24.config(state="normal")
            self.C5_25.config(state="normal"); self.C5_26.config(state="normal")
            self.C5_27.config(state="normal"); self.C5_28.config(state="normal")
            self.C5_29.config(state="normal"); self.C5_30.config(state="normal")
            self.C5_31.config(state="normal"); self.C5_32.config(state="normal")
            self.C5_A1.config(state="normal"); self.C5_A2.config(state="normal")
            self.C5_A3.config(state="normal");
        # 6
        if self.RHDModel == 0:
            self.C6_17.config(state="disable"); self.C6_18.config(state="disable")
            self.C6_19.config(state="disable"); self.C6_20.config(state="disable")
            self.C6_21.config(state="disable"); self.C6_22.config(state="disable")
            self.C6_23.config(state="disable"); self.C6_24.config(state="disable")
            self.C6_25.config(state="disable"); self.C6_26.config(state="disable")
            self.C6_27.config(state="disable"); self.C6_28.config(state="disable")
            self.C6_29.config(state="disable"); self.C6_30.config(state="disable")
            self.C6_31.config(state="disable"); self.C6_32.config(state="disable")
            self.C6_A1.config(state="disable"); self.C6_A2.config(state="disable")
            self.C6_A3.config(state="disable");
        else:
            self.C6_17.config(state="normal"); self.C6_18.config(state="normal")
            self.C6_19.config(state="normal"); self.C6_20.config(state="normal")
            self.C6_21.config(state="normal"); self.C6_22.config(state="normal")
            self.C6_23.config(state="normal"); self.C6_24.config(state="normal")
            self.C6_25.config(state="normal"); self.C6_26.config(state="normal")
            self.C6_27.config(state="normal"); self.C6_28.config(state="normal")
            self.C6_29.config(state="normal"); self.C6_30.config(state="normal")
            self.C6_31.config(state="normal"); self.C6_32.config(state="normal")
            self.C6_A1.config(state="normal"); self.C6_A2.config(state="normal")
            self.C6_A3.config(state="normal");
        # 7
        if self.RHDModel == 0:
            self.C7_17.config(state="disable"); self.C7_18.config(state="disable")
            self.C7_19.config(state="disable"); self.C7_20.config(state="disable")
            self.C7_21.config(state="disable"); self.C7_22.config(state="disable")
            self.C7_23.config(state="disable"); self.C7_24.config(state="disable")
            self.C7_25.config(state="disable"); self.C7_26.config(state="disable")
            self.C7_27.config(state="disable"); self.C7_28.config(state="disable")
            self.C7_29.config(state="disable"); self.C7_30.config(state="disable")
            self.C7_31.config(state="disable"); self.C7_32.config(state="disable")
            self.C7_A1.config(state="disable"); self.C7_A2.config(state="disable")
            self.C7_A3.config(state="disable");
        else:
            self.C7_17.config(state="normal"); self.C7_18.config(state="normal")
            self.C7_19.config(state="normal"); self.C7_20.config(state="normal")
            self.C7_21.config(state="normal"); self.C7_22.config(state="normal")
            self.C7_23.config(state="normal"); self.C7_24.config(state="normal")
            self.C7_25.config(state="normal"); self.C7_26.config(state="normal")
            self.C7_27.config(state="normal"); self.C7_28.config(state="normal")
            self.C7_29.config(state="normal"); self.C7_30.config(state="normal")
            self.C7_31.config(state="normal"); self.C7_32.config(state="normal")
            self.C7_A1.config(state="normal"); self.C7_A2.config(state="normal")
            self.C7_A3.config(state="normal");
        # 8
        if self.RHDModel == 0:
            self.C8_17.config(state="disable"); self.C8_18.config(state="disable")
            self.C8_19.config(state="disable"); self.C8_20.config(state="disable")
            self.C8_21.config(state="disable"); self.C8_22.config(state="disable")
            self.C8_23.config(state="disable"); self.C8_24.config(state="disable")
            self.C8_25.config(state="disable"); self.C8_26.config(state="disable")
            self.C8_27.config(state="disable"); self.C8_28.config(state="disable")
            self.C8_29.config(state="disable"); self.C8_30.config(state="disable")
            self.C8_31.config(state="disable"); self.C8_32.config(state="disable")
            self.C8_A1.config(state="disable"); self.C8_A2.config(state="disable")
            self.C8_A3.config(state="disable");
        else:
            self.C8_17.config(state="normal"); self.C8_18.config(state="normal")
            self.C8_19.config(state="normal"); self.C8_20.config(state="normal")
            self.C8_21.config(state="normal"); self.C8_22.config(state="normal")
            self.C8_23.config(state="normal"); self.C8_24.config(state="normal")
            self.C8_25.config(state="normal"); self.C8_26.config(state="normal")
            self.C8_27.config(state="normal"); self.C8_28.config(state="normal")
            self.C8_29.config(state="normal"); self.C8_30.config(state="normal")
            self.C8_31.config(state="normal"); self.C8_32.config(state="normal")
            self.C8_A1.config(state="normal"); self.C8_A2.config(state="normal")
            self.C8_A3.config(state="normal");

    def createWidgets(self, master):
        # Setting up the menu

        # The master menu
        self.TheMenu = Tkinter.Menu(master)
        master.config(menu=self.TheMenu)

        # Add the submenu file
        self.SubMenuFile = Tkinter.Menu(self.TheMenu)
        self.TheMenu.add_cascade(label="File", menu=self.SubMenuFile)
        # File -> Configuration files
        self.SubMenuFile.add_command(label="Load settings", command=self.LoadFile)
        self.SubMenuFile.add_command(label="Save settings", command=self.SaveFile)
        # file -> ----
        self.SubMenuFile.add_separator()
        # file -> Quit
        self.SubMenuFile.add_command(label="Quit", command=self.quit)

        # IC1
        Row = 0
        self.C_RHD = Tkinter.Checkbutton(master,text="RHD?",variable=self.V_RHD,command=self.RHD_CHANGE); self.C_RHD.grid(row=Row, column=0)
        Row = Row + 1
        Tkinter.Label(master,text="Channel Selection ").grid(row=Row,column=0)
        Row = Row + 1
        Tkinter.Label(master,text="IC 1:").grid(row=Row,column=0)
        Row = Row + 1
        self.C1_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V1_01); self.C1_01.grid(row=Row, column=0)
        self.C1_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V1_02); self.C1_02.grid(row=Row, column=1)
        self.C1_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V1_03); self.C1_03.grid(row=Row, column=2)
        self.C1_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V1_04); self.C1_04.grid(row=Row, column=3)
        self.C1_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V1_05); self.C1_05.grid(row=Row, column=4)
        self.C1_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V1_06); self.C1_06.grid(row=Row, column=5)
        self.C1_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V1_07); self.C1_07.grid(row=Row, column=6)
        self.C1_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V1_08); self.C1_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C1_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V1_09); self.C1_09.grid(row=Row, column=0)
        self.C1_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V1_10); self.C1_10.grid(row=Row, column=1)
        self.C1_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V1_11); self.C1_11.grid(row=Row, column=2)
        self.C1_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V1_12); self.C1_12.grid(row=Row, column=3)
        self.C1_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V1_13); self.C1_13.grid(row=Row, column=4)
        self.C1_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V1_14); self.C1_14.grid(row=Row, column=5)
        self.C1_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V1_15); self.C1_15.grid(row=Row, column=6)
        self.C1_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V1_16); self.C1_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C1_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V1_17); self.C1_17.grid(row=Row, column=0)
        self.C1_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V1_18); self.C1_18.grid(row=Row, column=1)
        self.C1_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V1_19); self.C1_19.grid(row=Row, column=2)
        self.C1_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V1_20); self.C1_20.grid(row=Row, column=3)
        self.C1_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V1_21); self.C1_21.grid(row=Row, column=4)
        self.C1_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V1_22); self.C1_22.grid(row=Row, column=5)
        self.C1_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V1_23); self.C1_23.grid(row=Row, column=6)
        self.C1_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V1_24); self.C1_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C1_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V1_25); self.C1_25.grid(row=Row, column=0)
        self.C1_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V1_26); self.C1_26.grid(row=Row, column=1)
        self.C1_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V1_27); self.C1_27.grid(row=Row, column=2)
        self.C1_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V1_28); self.C1_28.grid(row=Row, column=3)
        self.C1_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V1_29); self.C1_29.grid(row=Row, column=4)
        self.C1_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V1_30); self.C1_30.grid(row=Row, column=5)
        self.C1_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V1_31); self.C1_31.grid(row=Row, column=6)
        self.C1_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V1_32); self.C1_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C1_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V1_A1); self.C1_A1.grid(row=Row, column=0)
        self.C1_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V1_A2); self.C1_A2.grid(row=Row, column=1)
        self.C1_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V1_A3); self.C1_A3.grid(row=Row, column=2)
        # IC 2
        Row = Row + 1
        Tkinter.Label(master,text="IC 2:").grid(row=Row,column=0)
        Row = Row + 1
        self.C2_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V2_01); self.C2_01.grid(row=Row, column=0)
        self.C2_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V2_02); self.C2_02.grid(row=Row, column=1)
        self.C2_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V2_03); self.C2_03.grid(row=Row, column=2)
        self.C2_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V2_04); self.C2_04.grid(row=Row, column=3)
        self.C2_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V2_05); self.C2_05.grid(row=Row, column=4)
        self.C2_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V2_06); self.C2_06.grid(row=Row, column=5)
        self.C2_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V2_07); self.C2_07.grid(row=Row, column=6)
        self.C2_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V2_08); self.C2_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C2_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V2_09); self.C2_09.grid(row=Row, column=0)
        self.C2_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V2_10); self.C2_10.grid(row=Row, column=1)
        self.C2_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V2_11); self.C2_11.grid(row=Row, column=2)
        self.C2_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V2_12); self.C2_12.grid(row=Row, column=3)
        self.C2_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V2_13); self.C2_13.grid(row=Row, column=4)
        self.C2_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V2_14); self.C2_14.grid(row=Row, column=5)
        self.C2_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V2_15); self.C2_15.grid(row=Row, column=6)
        self.C2_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V2_16); self.C2_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C2_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V2_17); self.C2_17.grid(row=Row, column=0)
        self.C2_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V2_18); self.C2_18.grid(row=Row, column=1)
        self.C2_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V2_19); self.C2_19.grid(row=Row, column=2)
        self.C2_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V2_20); self.C2_20.grid(row=Row, column=3)
        self.C2_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V2_21); self.C2_21.grid(row=Row, column=4)
        self.C2_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V2_22); self.C2_22.grid(row=Row, column=5)
        self.C2_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V2_23); self.C2_23.grid(row=Row, column=6)
        self.C2_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V2_24); self.C2_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C2_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V2_25); self.C2_25.grid(row=Row, column=0)
        self.C2_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V2_26); self.C2_26.grid(row=Row, column=1)
        self.C2_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V2_27); self.C2_27.grid(row=Row, column=2)
        self.C2_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V2_28); self.C2_28.grid(row=Row, column=3)
        self.C2_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V2_29); self.C2_29.grid(row=Row, column=4)
        self.C2_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V2_30); self.C2_30.grid(row=Row, column=5)
        self.C2_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V2_31); self.C2_31.grid(row=Row, column=6)
        self.C2_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V2_32); self.C2_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C2_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V2_A1); self.C2_A1.grid(row=Row, column=0)
        self.C2_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V2_A2); self.C2_A2.grid(row=Row, column=1)
        self.C2_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V2_A3); self.C2_A3.grid(row=Row, column=2)
        # IC 3
        Row = Row + 1
        Tkinter.Label(master,text="IC 3:").grid(row=Row,column=0)
        Row = Row + 1
        self.C3_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V3_01); self.C3_01.grid(row=Row, column=0)
        self.C3_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V3_02); self.C3_02.grid(row=Row, column=1)
        self.C3_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V3_03); self.C3_03.grid(row=Row, column=2)
        self.C3_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V3_04); self.C3_04.grid(row=Row, column=3)
        self.C3_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V3_05); self.C3_05.grid(row=Row, column=4)
        self.C3_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V3_06); self.C3_06.grid(row=Row, column=5)
        self.C3_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V3_07); self.C3_07.grid(row=Row, column=6)
        self.C3_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V3_08); self.C3_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C3_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V3_09); self.C3_09.grid(row=Row, column=0)
        self.C3_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V3_10); self.C3_10.grid(row=Row, column=1)
        self.C3_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V3_11); self.C3_11.grid(row=Row, column=2)
        self.C3_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V3_12); self.C3_12.grid(row=Row, column=3)
        self.C3_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V3_13); self.C3_13.grid(row=Row, column=4)
        self.C3_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V3_14); self.C3_14.grid(row=Row, column=5)
        self.C3_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V3_15); self.C3_15.grid(row=Row, column=6)
        self.C3_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V3_16); self.C3_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C3_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V3_17); self.C3_17.grid(row=Row, column=0)
        self.C3_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V3_18); self.C3_18.grid(row=Row, column=1)
        self.C3_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V3_19); self.C3_19.grid(row=Row, column=2)
        self.C3_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V3_20); self.C3_20.grid(row=Row, column=3)
        self.C3_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V3_21); self.C3_21.grid(row=Row, column=4)
        self.C3_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V3_22); self.C3_22.grid(row=Row, column=5)
        self.C3_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V3_23); self.C3_23.grid(row=Row, column=6)
        self.C3_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V3_24); self.C3_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C3_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V3_25); self.C3_25.grid(row=Row, column=0)
        self.C3_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V3_26); self.C3_26.grid(row=Row, column=1)
        self.C3_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V3_27); self.C3_27.grid(row=Row, column=2)
        self.C3_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V3_28); self.C3_28.grid(row=Row, column=3)
        self.C3_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V3_29); self.C3_29.grid(row=Row, column=4)
        self.C3_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V3_30); self.C3_30.grid(row=Row, column=5)
        self.C3_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V3_31); self.C3_31.grid(row=Row, column=6)
        self.C3_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V3_32); self.C3_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C3_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V3_A1); self.C3_A1.grid(row=Row, column=0)
        self.C3_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V3_A2); self.C3_A2.grid(row=Row, column=1)
        self.C3_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V3_A3); self.C3_A3.grid(row=Row, column=2)
        # IC 4
        Row = Row + 1
        Tkinter.Label(master,text="IC 4:").grid(row=Row,column=0)
        Row = Row + 1
        self.C4_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V4_01); self.C4_01.grid(row=Row, column=0)
        self.C4_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V4_02); self.C4_02.grid(row=Row, column=1)
        self.C4_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V4_03); self.C4_03.grid(row=Row, column=2)
        self.C4_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V4_04); self.C4_04.grid(row=Row, column=3)
        self.C4_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V4_05); self.C4_05.grid(row=Row, column=4)
        self.C4_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V4_06); self.C4_06.grid(row=Row, column=5)
        self.C4_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V4_07); self.C4_07.grid(row=Row, column=6)
        self.C4_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V4_08); self.C4_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C4_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V4_09); self.C4_09.grid(row=Row, column=0)
        self.C4_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V4_10); self.C4_10.grid(row=Row, column=1)
        self.C4_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V4_11); self.C4_11.grid(row=Row, column=2)
        self.C4_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V4_12); self.C4_12.grid(row=Row, column=3)
        self.C4_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V4_13); self.C4_13.grid(row=Row, column=4)
        self.C4_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V4_14); self.C4_14.grid(row=Row, column=5)
        self.C4_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V4_15); self.C4_15.grid(row=Row, column=6)
        self.C4_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V4_16); self.C4_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C4_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V4_17); self.C4_17.grid(row=Row, column=0)
        self.C4_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V4_18); self.C4_18.grid(row=Row, column=1)
        self.C4_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V4_19); self.C4_19.grid(row=Row, column=2)
        self.C4_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V4_20); self.C4_20.grid(row=Row, column=3)
        self.C4_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V4_21); self.C4_21.grid(row=Row, column=4)
        self.C4_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V4_22); self.C4_22.grid(row=Row, column=5)
        self.C4_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V4_23); self.C4_23.grid(row=Row, column=6)
        self.C4_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V4_24); self.C4_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C4_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V4_25); self.C4_25.grid(row=Row, column=0)
        self.C4_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V4_26); self.C4_26.grid(row=Row, column=1)
        self.C4_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V4_27); self.C4_27.grid(row=Row, column=2)
        self.C4_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V4_28); self.C4_28.grid(row=Row, column=3)
        self.C4_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V4_29); self.C4_29.grid(row=Row, column=4)
        self.C4_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V4_30); self.C4_30.grid(row=Row, column=5)
        self.C4_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V4_31); self.C4_31.grid(row=Row, column=6)
        self.C4_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V4_32); self.C4_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C4_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V4_A1); self.C4_A1.grid(row=Row, column=0)
        self.C4_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V4_A2); self.C4_A2.grid(row=Row, column=1)
        self.C4_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V4_A3); self.C4_A3.grid(row=Row, column=2)
        # IC 5
        Row = Row + 1
        Tkinter.Label(master,text="IC 5:").grid(row=Row,column=0)
        Row = Row + 1
        self.C5_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V5_01); self.C5_01.grid(row=Row, column=0)
        self.C5_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V5_02); self.C5_02.grid(row=Row, column=1)
        self.C5_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V5_03); self.C5_03.grid(row=Row, column=2)
        self.C5_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V5_04); self.C5_04.grid(row=Row, column=3)
        self.C5_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V5_05); self.C5_05.grid(row=Row, column=4)
        self.C5_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V5_06); self.C5_06.grid(row=Row, column=5)
        self.C5_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V5_07); self.C5_07.grid(row=Row, column=6)
        self.C5_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V5_08); self.C5_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C5_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V5_09); self.C5_09.grid(row=Row, column=0)
        self.C5_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V5_10); self.C5_10.grid(row=Row, column=1)
        self.C5_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V5_11); self.C5_11.grid(row=Row, column=2)
        self.C5_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V5_12); self.C5_12.grid(row=Row, column=3)
        self.C5_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V5_13); self.C5_13.grid(row=Row, column=4)
        self.C5_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V5_14); self.C5_14.grid(row=Row, column=5)
        self.C5_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V5_15); self.C5_15.grid(row=Row, column=6)
        self.C5_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V5_16); self.C5_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C5_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V5_17); self.C5_17.grid(row=Row, column=0)
        self.C5_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V5_18); self.C5_18.grid(row=Row, column=1)
        self.C5_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V5_19); self.C5_19.grid(row=Row, column=2)
        self.C5_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V5_20); self.C5_20.grid(row=Row, column=3)
        self.C5_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V5_21); self.C5_21.grid(row=Row, column=4)
        self.C5_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V5_22); self.C5_22.grid(row=Row, column=5)
        self.C5_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V5_23); self.C5_23.grid(row=Row, column=6)
        self.C5_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V5_24); self.C5_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C5_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V5_25); self.C5_25.grid(row=Row, column=0)
        self.C5_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V5_26); self.C5_26.grid(row=Row, column=1)
        self.C5_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V5_27); self.C5_27.grid(row=Row, column=2)
        self.C5_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V5_28); self.C5_28.grid(row=Row, column=3)
        self.C5_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V5_29); self.C5_29.grid(row=Row, column=4)
        self.C5_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V5_30); self.C5_30.grid(row=Row, column=5)
        self.C5_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V5_31); self.C5_31.grid(row=Row, column=6)
        self.C5_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V5_32); self.C5_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C5_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V5_A1); self.C5_A1.grid(row=Row, column=0)
        self.C5_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V5_A2); self.C5_A2.grid(row=Row, column=1)
        self.C5_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V5_A3); self.C5_A3.grid(row=Row, column=2)
        # IC 6
        Row = Row + 1
        Tkinter.Label(master,text="IC 6:").grid(row=Row,column=0)
        Row = Row + 1
        self.C6_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V6_01); self.C6_01.grid(row=Row, column=0)
        self.C6_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V6_02); self.C6_02.grid(row=Row, column=1)
        self.C6_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V6_03); self.C6_03.grid(row=Row, column=2)
        self.C6_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V6_04); self.C6_04.grid(row=Row, column=3)
        self.C6_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V6_05); self.C6_05.grid(row=Row, column=4)
        self.C6_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V6_06); self.C6_06.grid(row=Row, column=5)
        self.C6_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V6_07); self.C6_07.grid(row=Row, column=6)
        self.C6_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V6_08); self.C6_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C6_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V6_09); self.C6_09.grid(row=Row, column=0)
        self.C6_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V6_10); self.C6_10.grid(row=Row, column=1)
        self.C6_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V6_11); self.C6_11.grid(row=Row, column=2)
        self.C6_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V6_12); self.C6_12.grid(row=Row, column=3)
        self.C6_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V6_13); self.C6_13.grid(row=Row, column=4)
        self.C6_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V6_14); self.C6_14.grid(row=Row, column=5)
        self.C6_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V6_15); self.C6_15.grid(row=Row, column=6)
        self.C6_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V6_16); self.C6_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C6_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V6_17); self.C6_17.grid(row=Row, column=0)
        self.C6_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V6_18); self.C6_18.grid(row=Row, column=1)
        self.C6_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V6_19); self.C6_19.grid(row=Row, column=2)
        self.C6_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V6_20); self.C6_20.grid(row=Row, column=3)
        self.C6_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V6_21); self.C6_21.grid(row=Row, column=4)
        self.C6_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V6_22); self.C6_22.grid(row=Row, column=5)
        self.C6_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V6_23); self.C6_23.grid(row=Row, column=6)
        self.C6_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V6_24); self.C6_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C6_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V6_25); self.C6_25.grid(row=Row, column=0)
        self.C6_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V6_26); self.C6_26.grid(row=Row, column=1)
        self.C6_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V6_27); self.C6_27.grid(row=Row, column=2)
        self.C6_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V6_28); self.C6_28.grid(row=Row, column=3)
        self.C6_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V6_29); self.C6_29.grid(row=Row, column=4)
        self.C6_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V6_30); self.C6_30.grid(row=Row, column=5)
        self.C6_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V6_31); self.C6_31.grid(row=Row, column=6)
        self.C6_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V6_32); self.C6_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C6_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V6_A1); self.C6_A1.grid(row=Row, column=0)
        self.C6_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V6_A2); self.C6_A2.grid(row=Row, column=1)
        self.C6_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V6_A3); self.C6_A3.grid(row=Row, column=2)
        # IC 7
        Row = Row + 1
        Tkinter.Label(master,text="IC 7:").grid(row=Row,column=0)
        Row = Row + 1
        self.C7_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V7_01); self.C7_01.grid(row=Row, column=0)
        self.C7_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V7_02); self.C7_02.grid(row=Row, column=1)
        self.C7_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V7_03); self.C7_03.grid(row=Row, column=2)
        self.C7_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V7_04); self.C7_04.grid(row=Row, column=3)
        self.C7_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V7_05); self.C7_05.grid(row=Row, column=4)
        self.C7_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V7_06); self.C7_06.grid(row=Row, column=5)
        self.C7_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V7_07); self.C7_07.grid(row=Row, column=6)
        self.C7_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V7_08); self.C7_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C7_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V7_09); self.C7_09.grid(row=Row, column=0)
        self.C7_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V7_10); self.C7_10.grid(row=Row, column=1)
        self.C7_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V7_11); self.C7_11.grid(row=Row, column=2)
        self.C7_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V7_12); self.C7_12.grid(row=Row, column=3)
        self.C7_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V7_13); self.C7_13.grid(row=Row, column=4)
        self.C7_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V7_14); self.C7_14.grid(row=Row, column=5)
        self.C7_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V7_15); self.C7_15.grid(row=Row, column=6)
        self.C7_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V7_16); self.C7_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C7_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V7_17); self.C7_17.grid(row=Row, column=0)
        self.C7_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V7_18); self.C7_18.grid(row=Row, column=1)
        self.C7_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V7_19); self.C7_19.grid(row=Row, column=2)
        self.C7_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V7_20); self.C7_20.grid(row=Row, column=3)
        self.C7_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V7_21); self.C7_21.grid(row=Row, column=4)
        self.C7_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V7_22); self.C7_22.grid(row=Row, column=5)
        self.C7_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V7_23); self.C7_23.grid(row=Row, column=6)
        self.C7_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V7_24); self.C7_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C7_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V7_25); self.C7_25.grid(row=Row, column=0)
        self.C7_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V7_26); self.C7_26.grid(row=Row, column=1)
        self.C7_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V7_27); self.C7_27.grid(row=Row, column=2)
        self.C7_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V7_28); self.C7_28.grid(row=Row, column=3)
        self.C7_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V7_29); self.C7_29.grid(row=Row, column=4)
        self.C7_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V7_30); self.C7_30.grid(row=Row, column=5)
        self.C7_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V7_31); self.C7_31.grid(row=Row, column=6)
        self.C7_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V7_32); self.C7_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C7_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V7_A1); self.C7_A1.grid(row=Row, column=0)
        self.C7_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V7_A2); self.C7_A2.grid(row=Row, column=1)
        self.C7_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V7_A3); self.C7_A3.grid(row=Row, column=2)
        # IC 8
        Row = Row + 1
        Tkinter.Label(master,text="IC 8:").grid(row=Row,column=0)
        Row = Row + 1
        self.C8_01 = Tkinter.Checkbutton(master,text="Channel 01",variable=self.V8_01); self.C8_01.grid(row=Row, column=0)
        self.C8_02 = Tkinter.Checkbutton(master,text="Channel 02",variable=self.V8_02); self.C8_02.grid(row=Row, column=1)
        self.C8_03 = Tkinter.Checkbutton(master,text="Channel 03",variable=self.V8_03); self.C8_03.grid(row=Row, column=2)
        self.C8_04 = Tkinter.Checkbutton(master,text="Channel 04",variable=self.V8_04); self.C8_04.grid(row=Row, column=3)
        self.C8_05 = Tkinter.Checkbutton(master,text="Channel 05",variable=self.V8_05); self.C8_05.grid(row=Row, column=4)
        self.C8_06 = Tkinter.Checkbutton(master,text="Channel 06",variable=self.V8_06); self.C8_06.grid(row=Row, column=5)
        self.C8_07 = Tkinter.Checkbutton(master,text="Channel 07",variable=self.V8_07); self.C8_07.grid(row=Row, column=6)
        self.C8_08 = Tkinter.Checkbutton(master,text="Channel 08",variable=self.V8_08); self.C8_08.grid(row=Row, column=7)
        Row = Row + 1
        self.C8_09 = Tkinter.Checkbutton(master,text="Channel 09",variable=self.V8_09); self.C8_09.grid(row=Row, column=0)
        self.C8_10 = Tkinter.Checkbutton(master,text="Channel 10",variable=self.V8_10); self.C8_10.grid(row=Row, column=1)
        self.C8_11 = Tkinter.Checkbutton(master,text="Channel 11",variable=self.V8_11); self.C8_11.grid(row=Row, column=2)
        self.C8_12 = Tkinter.Checkbutton(master,text="Channel 12",variable=self.V8_12); self.C8_12.grid(row=Row, column=3)
        self.C8_13 = Tkinter.Checkbutton(master,text="Channel 13",variable=self.V8_13); self.C8_13.grid(row=Row, column=4)
        self.C8_14 = Tkinter.Checkbutton(master,text="Channel 14",variable=self.V8_14); self.C8_14.grid(row=Row, column=5)
        self.C8_15 = Tkinter.Checkbutton(master,text="Channel 15",variable=self.V8_15); self.C8_15.grid(row=Row, column=6)
        self.C8_16 = Tkinter.Checkbutton(master,text="Channel 16",variable=self.V8_16); self.C8_16.grid(row=Row, column=7)
        Row = Row + 1
        self.C8_17 = Tkinter.Checkbutton(master,text="Channel 17",variable=self.V8_17); self.C8_17.grid(row=Row, column=0)
        self.C8_18 = Tkinter.Checkbutton(master,text="Channel 18",variable=self.V8_18); self.C8_18.grid(row=Row, column=1)
        self.C8_19 = Tkinter.Checkbutton(master,text="Channel 19",variable=self.V8_19); self.C8_19.grid(row=Row, column=2)
        self.C8_20 = Tkinter.Checkbutton(master,text="Channel 20",variable=self.V8_20); self.C8_20.grid(row=Row, column=3)
        self.C8_21 = Tkinter.Checkbutton(master,text="Channel 21",variable=self.V8_21); self.C8_21.grid(row=Row, column=4)
        self.C8_22 = Tkinter.Checkbutton(master,text="Channel 22",variable=self.V8_22); self.C8_22.grid(row=Row, column=5)
        self.C8_23 = Tkinter.Checkbutton(master,text="Channel 23",variable=self.V8_23); self.C8_23.grid(row=Row, column=6)
        self.C8_24 = Tkinter.Checkbutton(master,text="Channel 24",variable=self.V8_24); self.C8_24.grid(row=Row, column=7)
        Row = Row + 1
        self.C8_25 = Tkinter.Checkbutton(master,text="Channel 25",variable=self.V8_25); self.C8_25.grid(row=Row, column=0)
        self.C8_26 = Tkinter.Checkbutton(master,text="Channel 26",variable=self.V8_26); self.C8_26.grid(row=Row, column=1)
        self.C8_27 = Tkinter.Checkbutton(master,text="Channel 27",variable=self.V8_27); self.C8_27.grid(row=Row, column=2)
        self.C8_28 = Tkinter.Checkbutton(master,text="Channel 28",variable=self.V8_28); self.C8_28.grid(row=Row, column=3)
        self.C8_29 = Tkinter.Checkbutton(master,text="Channel 29",variable=self.V8_29); self.C8_29.grid(row=Row, column=4)
        self.C8_30 = Tkinter.Checkbutton(master,text="Channel 30",variable=self.V8_30); self.C8_30.grid(row=Row, column=5)
        self.C8_31 = Tkinter.Checkbutton(master,text="Channel 31",variable=self.V8_31); self.C8_31.grid(row=Row, column=6)
        self.C8_32 = Tkinter.Checkbutton(master,text="Channel 32",variable=self.V8_32); self.C8_32.grid(row=Row, column=7)
        Row = Row + 1
        self.C8_A1 = Tkinter.Checkbutton(master,text="AUX A",variable=self.V8_A1); self.C8_A1.grid(row=Row, column=0)
        self.C8_A2 = Tkinter.Checkbutton(master,text="AUX B",variable=self.V8_A2); self.C8_A2.grid(row=Row, column=1)
        self.C8_A3 = Tkinter.Checkbutton(master,text="AUX C",variable=self.V8_A3); self.C8_A3.grid(row=Row, column=2)
        self.V_RHD.set(self.RHDModel)
        self.SetSingleChannel(self.C_RHD,self.V_RHD)
        self.SetViewRHAMode()

    def RHD_CHANGE(self):
        self.GetChannelSetup()
        self.SetViewRHAMode()

    def SaveFile(self):
        Filename = tkFileDialog.asksaveasfilename(**self.file_opt)
        if Filename != "":
            self.GetChannelSetup()
            FileHandel = open(Filename,'w')
            Temp = [self.ChannelSetup_1, self.ChannelSetup_2, \
                self.ChannelSetup_3, self.ChannelSetup_4, self.ChannelSetup_5, \
                self.ChannelSetup_6, self.ChannelSetup_7, self.ChannelSetup_8, \
                self.ChannelSetup_1A, self.ChannelSetup_2A, self.ChannelSetup_3A, \
                self.ChannelSetup_4A, self.ChannelSetup_5A, self.ChannelSetup_6A, \
                self.ChannelSetup_7A, self.ChannelSetup_8A, self.RHDModel]
            json.dump(Temp, FileHandel)
            FileHandel.close()

    def LoadFile(self):
        Filename = tkFileDialog.askopenfilename(**self.file_opt)
        if Filename != "":
            FileHandel = open(Filename,'r')
            self.ChannelSetup_1, self.ChannelSetup_2, \
                self.ChannelSetup_3, self.ChannelSetup_4, self.ChannelSetup_5, \
                self.ChannelSetup_6, self.ChannelSetup_7, self.ChannelSetup_8, \
                self.ChannelSetup_1A, self.ChannelSetup_2A, self.ChannelSetup_3A, \
                self.ChannelSetup_4A, self.ChannelSetup_5A, self.ChannelSetup_6A, \
                self.ChannelSetup_7A, self.ChannelSetup_8A, self.RHDModel = json.load(FileHandel)
            self.RestoreChannelSetup()
            self.SetChannelSet()
            self.SetViewRHAMode()
            FileHandel.close()
