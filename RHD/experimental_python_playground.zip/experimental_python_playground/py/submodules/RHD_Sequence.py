import submodules.FirmwareCommands as FirmwareCommands
import submodules.RHDBandpass as RHDBandpass
import numpy

def RHD_Sequence(NumberOfChannels,DesiredSampleRateInHz,ConfigureTestMode,ChannelMask,\
  ChannelMaskAUX,InstalledRHDBitMASK,HP_ID,LP_ID):
    # ##### Constants
    SampleBitMask = 65535 # 1111111111111111
    SampleBitMask_Lower = (SampleBitMask&255)
    SampleBitMask_Higher = SampleBitMask>>8
    NumberOfInstalledRHDsPlus1 = 9
    IMPLANT_CORE_SPEED = float(12*10**6) # 12 MHz
    NUMBER_OF_CHANNELS_PER_RHD = float(36) # I forgot why it is not 35 (32 analog + 3 aux)
    NUMBER_OF_MINIMAL_CYCLES_PER_SAMPLE = float(27)
    # Handling the Sampling Rate
    DesiredSampleRateInN = round(IMPLANT_CORE_SPEED / (float(DesiredSampleRateInHz) * \
        NUMBER_OF_CHANNELS_PER_RHD) - NUMBER_OF_MINIMAL_CYCLES_PER_SAMPLE)
    RealizedSampleRateInHz = IMPLANT_CORE_SPEED / (NUMBER_OF_CHANNELS_PER_RHD \
        * (DesiredSampleRateInN + NUMBER_OF_MINIMAL_CYCLES_PER_SAMPLE))
    print "Desired Sample-Rate [Hz]:", DesiredSampleRateInHz
    print "Realized Sample-Rate [Hz]:", RealizedSampleRateInHz
    print "Calculated-Value:", DesiredSampleRateInN
    CommandSet = FirmwareCommands.FirmwareCommands()

    # Creating the commands:
    Command_List = []
    Command_Responses = []
    Command_Name = []

    # Init the RF connection
    Command = CommandSet.Command_InitRF()
    Command_List.append(Command)
    Command_Responses.append((258))
    Command_Name.append("Init the RF connection")

    # Check the RF connecton
    RegisterNumber = numpy.zeros((1,1),dtype=numpy.uint16)
    RegisterNumber.flat[0] = 50
    Command = CommandSet.Command_ZarlinkRegisterRead(RegisterNumber)
    Command_List.append(Command)
    Command_Responses.append((1024))
    Command_Name.append("Check the RF connection")

    # Set the RHD Decoding Parameters
    Input = numpy.zeros((3,1),dtype=numpy.uint16)
    Input.flat[0] = SampleBitMask
    Input.flat[1] = NumberOfChannels
    Input.flat[2] = NumberOfInstalledRHDsPlus1
    Command = CommandSet.Command_SetRHDDecodingParameter(Input)
    Command_List.append(Command)
    Command_Responses.append((2001))
    Command_Name.append("Set RHD Decoding Parameters")
    Value_0 = 48
    Value_1 = 105
    Value_2 = 53
    Value_3 = 234
    Temp = numpy.array([DesiredSampleRateInN],dtype=numpy.uint64)
    Value_7 = (Temp&255) # std_logic_vector( 7 downto  0)
    Temp = (Temp>>8)
    Value_6 = (Temp&255) # std_logic_vector(15 downto  8)
    Temp = (Temp>>8)
    Value_5 = (Temp&255) # std_logic_vector(31 downto 24)
    Temp = (Temp>>8)
    Value_4 = (Temp&255) # std_logic_vector(23 downto 16)
    Value_8 = 0
    Value_9 = 0
    Value_10 = 0
    Value_11 = 0
    Value_12 = 0
    Value_13 = 0
    ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
    ValueString.flat[0] = Value_0  + 256 * Value_1
    ValueString.flat[1] = Value_2  + 256 * Value_3
    ValueString.flat[2] = Value_4  + 256 * Value_5
    ValueString.flat[3] = Value_6  + 256 * Value_7
    ValueString.flat[4] = Value_8  + 256 * Value_9
    ValueString.flat[5] = Value_10 + 256 * Value_11
    ValueString.flat[6] = Value_12 + 256 * Value_13
    Command = CommandSet.Command_ZarlinkBlockWrite(ValueString)
    Command_List.append(Command)
    Command_Responses.append((1028))
    Command_Name.append("Set Sampling Rate")

    # TEST MODE?
    Value_0 = 48
    Value_1 = 105
    Value_2 = 53
    Value_3 = 174
    Value_4 = ConfigureTestMode
    Value_5 = 0
    Value_6 = 0
    Value_7 = 0
    Value_8 = 0
    Value_9 = 0
    Value_10 = 0
    Value_11 = 0
    Value_12 = 0
    Value_13 = 0
    ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
    ValueString.flat[0] = Value_0  + 256 * Value_1
    ValueString.flat[1] = Value_2  + 256 * Value_3
    ValueString.flat[2] = Value_4  + 256 * Value_5
    ValueString.flat[3] = Value_6  + 256 * Value_7
    ValueString.flat[4] = Value_8  + 256 * Value_9
    ValueString.flat[5] = Value_10 + 256 * Value_11
    ValueString.flat[6] = Value_12 + 256 * Value_13
    Command = CommandSet.Command_ZarlinkBlockWrite(ValueString)
    Command_List.append(Command)
    Command_Responses.append((1028))
    Command_Name.append("Set Test Mode (or not)")

    # Set Channel MASK of RHD 0
    for i in xrange(0,8):
        if len(ChannelMask) >= ((i+1)*4):
            Value_0 = 48
            Value_1 = 105
            Value_2 = 53
            Value_3 = 171
            Value_4 = int(i)
            Value_5 = int(ChannelMask[i*4+0])
            Value_6 = int(ChannelMask[i*4+1])
            Value_7 = int(ChannelMask[i*4+2])
            Value_8 = int(ChannelMask[i*4+3])
            Value_9 = 0
            Value_10 = 0
            Value_11 = 0
            Value_12 = 0
            Value_13 = 0
            ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
            ValueString.flat[0] = Value_0  + 256 * Value_1
            ValueString.flat[1] = Value_2  + 256 * Value_3
            ValueString.flat[2] = Value_4  + 256 * Value_5
            ValueString.flat[3] = Value_6  + 256 * Value_7
            ValueString.flat[4] = Value_8  + 256 * Value_9
            ValueString.flat[5] = Value_10 + 256 * Value_11
            ValueString.flat[6] = Value_12 + 256 * Value_13
            Command = CommandSet.Command_ZarlinkBlockWrite(ValueString)
            Command_List.append(Command)
            Command_Responses.append((1028))
            Command_Name.append("Program channel mask")

    # Set Channel AUX MASK of RHD 0
    for i in xrange(0,8):
        if len(ChannelMaskAUX) >= (i+1):
            Value_0 = 48
            Value_1 = 105
            Value_2 = 53
            Value_3 = 138
            Value_4 = int(i)
            Value_5 = int(ChannelMaskAUX[i])
            Value_6 = 0
            Value_7 = 0
            Value_8 = 0
            Value_9 = 0
            Value_10 = 0
            Value_11 = 0
            Value_12 = 0
            Value_13 = 0
            ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
            ValueString.flat[0] = Value_0  + 256 * Value_1
            ValueString.flat[1] = Value_2  + 256 * Value_3
            ValueString.flat[2] = Value_4  + 256 * Value_5
            ValueString.flat[3] = Value_6  + 256 * Value_7
            ValueString.flat[4] = Value_8  + 256 * Value_9
            ValueString.flat[5] = Value_10 + 256 * Value_11
            ValueString.flat[6] = Value_12 + 256 * Value_13
            Command = CommandSet.Command_ZarlinkBlockWrite(ValueString)
            Command_List.append(Command)
            Command_Responses.append((1028))
            Command_Name.append("Program channel mask AUX")

    # Set the internal RHD registers
    if ConfigureTestMode == 0:
        MYBP = RHDBandpass.RHDBandpass()
        MYBP.AddRHDCommand_RegALL(InstalledRHDBitMASK,HP_ID,LP_ID)
        if len(MYBP.RHDCommands) != len(MYBP.RHDCommands_Responses) \
          or len(MYBP.RHDCommands) != len(MYBP.RHDCommands_Name):
            print "ERROR: Somthing is very wrong with the RHD command list"
        else :
            for i in xrange(0,len(MYBP.RHDCommands)):
                Command_List.append(MYBP.RHDCommands[i])
                Command_Responses.append(MYBP.RHDCommands_Responses[i])
                Command_Name.append(MYBP.RHDCommands_Name[i])

    # The the sample bitmask on the implant
    Value_0 = 48
    Value_1 = 105
    Value_2 = 53
    Value_3 = 42
    Value_4 = SampleBitMask_Higher
    Value_5 = SampleBitMask_Lower
    Value_6 = 0
    Value_7 = 0
    Value_8 = 0
    Value_9 = 0
    Value_10 = 0
    Value_11 = 0
    Value_12 = 0
    Value_13 = 0
    ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
    ValueString.flat[0] = Value_0  + 256 * Value_1
    ValueString.flat[1] = Value_2  + 256 * Value_3
    ValueString.flat[2] = Value_4  + 256 * Value_5
    ValueString.flat[3] = Value_6  + 256 * Value_7
    ValueString.flat[4] = Value_8  + 256 * Value_9
    ValueString.flat[5] = Value_10 + 256 * Value_11
    ValueString.flat[6] = Value_12 + 256 * Value_13
    Command = CommandSet.Command_ZarlinkBlockWrite(ValueString)
    Command_List.append(Command)
    Command_Responses.append((1028))
    Command_Name.append("Set bit mask on the implant")

    # Activate the recoding process
    Value_0 = 48
    Value_1 = 105
    Value_2 = 53
    Value_3 = 186
    Value_4 = 1
    Value_5 = 0
    Value_6 = 0
    Value_7 = 0
    Value_8 = 0
    Value_9 = 0
    Value_10 = 0
    Value_11 = 0
    Value_12 = 0
    Value_13 = 0
    ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
    ValueString.flat[0] = Value_0  + 256 * Value_1
    ValueString.flat[1] = Value_2  + 256 * Value_3
    ValueString.flat[2] = Value_4  + 256 * Value_5
    ValueString.flat[3] = Value_6  + 256 * Value_7
    ValueString.flat[4] = Value_8  + 256 * Value_9
    ValueString.flat[5] = Value_10 + 256 * Value_11
    ValueString.flat[6] = Value_12 + 256 * Value_13
    Command = CommandSet.Command_ZarlinkBlockWrite(ValueString)
    Command_List.append(Command)
    Command_Responses.append((1028))
    Command_Name.append("Activate the recording process")

    # That's it
    return(Command_List,Command_Responses,Command_Name)
