import numpy

class FirmwareCommands:
    def CalcCRC(self,data,CRCValue):
        Result = numpy.zeros((1,1),dtype=numpy.uint16)
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint8) == False:
            return -2
        # Is "CRCValue" really a numpy element?
        if type(CRCValue).__module__ != numpy.__name__:
            return -3
        if numpy.issubdtype(CRCValue.dtype,numpy.uint8) == False:
            return -4
        # Is it a scalar?
        if CRCValue.size != 1:
            return -5
        data = data.flatten()
        # Calculate the CRC values
        for i in range(0, data.size):
            if ((data.flat[i] >> 0) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
            if ((data.flat[i] >> 2) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
            if ((data.flat[i] >> 4) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
            if ((data.flat[i] >> 6) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
        return Result

    def BuildPackage(self,CommandID,data):
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        # Is "CommandID" really a numpy element?
        if type(CommandID).__module__ != numpy.__name__:
            return -3
        if numpy.issubdtype(CommandID.dtype,numpy.uint16) == False:
            return -4
        # Is it a scalar?
        if CommandID.size != 1:
            return -5
        # 2x Packet ID, 2x Length of Packet, 2x Command ID, 8x CRC and 2 * Number of Values
        LengthOfThePackage = numpy.zeros((1,1),dtype=numpy.uint16)
        LengthOfThePackage.flat[0] = 2+2+2+8+2*data.size
        PackageData = numpy.zeros(((LengthOfThePackage>>1),1),dtype=numpy.uint16)
        PackageData.flat[0] = 0x55AA
        PackageData.flat[1] = LengthOfThePackage
        PackageData.flat[2] = CommandID
        if data.size > 0:
            PackageData.flat[3:3+data.size] = data
        # First CRC value
        CRCValue = numpy.zeros((1,1),dtype=numpy.uint8)
        CRCValue.flat[0] = 0
        Temp = self.CalcCRC(PackageData.flat[0:3+data.size].view(dtype=numpy.uint8),CRCValue)
        if Temp < 0:
            return -1
        PackageData.flat[3+data.size] = Temp
        # Second CRC value
        CRCValue.flat[0] = 1
        Temp = self.CalcCRC(PackageData.flat[0:3+data.size].view(dtype=numpy.uint8),CRCValue)
        if Temp < 0:
            return -2
        PackageData.flat[3+data.size+1] = Temp
        # Third CRC value
        CRCValue.flat[0] = 2
        Temp = self.CalcCRC(PackageData.flat[0:3+data.size].view(dtype=numpy.uint8),CRCValue)
        if Temp < 0:
            return -3
        PackageData.flat[3+data.size+2] = Temp
        # Last CRC value
        CRCValue.flat[0] = 3
        Temp = self.CalcCRC(PackageData.flat[0:3+data.size].view(dtype=numpy.uint8),CRCValue)
        if Temp < 0:
            return -4
        PackageData.flat[3+data.size+3] = Temp
        return PackageData

    def Command_InitRF(self):
        # Init the RF connection
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0102
        data = numpy.zeros((2,1),dtype=numpy.uint16)
        data.flat[0] = 0xAAAA
        data.flat[1] = 0xAAAA
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_CloseRF(self):
        # Close the RF connection
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0103
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_GetInfo(self):
        # Get Firmware Information
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0101
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_GetTrigger(self):
        # Get the states of the trigger signals
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0503
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_SetTrigger(self,data):
        # Set trigger channels of the basestation
        # 2x 16 bit parameters
        # 1.) first 16 trigger channels
        # 2.) second 16 trigger channels
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0500
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 2:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_SetRHDDecodingParameter(self,data):
        # Parameter for the basestation, required for decoding the RHD
        # 3x 16 bit parameters
        # 1.) Number of Bits per sample (16bit Bitmask)
        # 2.) Number of active Channels incl. Aux
        # 3.) Number of RHDs + 1 (9)
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 2001
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 3:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_RHASetASICFilterConstant(self,data):
        # Set filter constant of the ITEM ASIC
        # 1x 16 bit parameters
        # 1.) Filter value
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0266
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 1:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ZarlinkBlockRead(self):
        # Read 14 bytes from the Zarlink buffer
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0405
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ZarlinkBlockWrite(self,data):
        # Write 14 bytes into the Zarlink buffer
        # 7x 16 bit parameters
        # 1.) Byte[00] + 256 * Byte[01]
        # 2.) Byte[02] + 256 * Byte[03]
        # 3.) Byte[04] + 256 * Byte[05]
        # 4.) Byte[06] + 256 * Byte[07]
        # 5.) Byte[08] + 256 * Byte[09]
        # 6.) Byte[10] + 256 * Byte[11]
        # 7.) Byte[12] + 256 * Byte[13]
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0404
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 7:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ZarlinkRegisterRead(self,data):
        # Read from a Zarlink register page 0
        # 1x 16 bit parameters
        # 1.) Zarlink register 0-127
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0400
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 1:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ZarlinkRegisterReadP1(self,data):
        # Read from a Zarlink register page 1
        # 1x 16 bit parameters
        # 1.) Zarlink register 0-127
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0401
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 1:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ZarlinkRegisterWrite(self,data):
        # Write to a Zarlink register page 0
        # 1x 16 bit parameters
        # 1.) Value_A + 256*Value_B
        # where Value_A = Register number 0-127
        # and Value_B = Value for the register 0-255
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0402
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 1:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ZarlinkRegisterWriteP1(self,data):
        # Write to a Zarlink register page 1
        # 1x 16 bit parameters
        # 1.) Value_A + 256*Value_B
        # where Value_A = Register number 0-127
        # and Value_B = Value for the register 0-255
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0403
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 1:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_BasestationDebugParameters(self,data):
        # Set debug constants in the basestation
        # 4x 16 bit parameters
        # 1.) Number of the debug constant
        # 2.) Value for debug constant Value_B
        # 3.) Value for debug constant (Value_B>>16)
        # 4.) Value for debug constant (Value_B>>32)
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x00FF
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 4:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_RHAStartASICRecording(self):
        # Start the ASIC recording
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0301
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_RHAStopASICRecording(self):
        # Stop the ASIC recording
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0302
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ExternalADCStart(self):
        # Start the external ADC
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0303
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ExternalADCStop(self):
        # Stop the external ADC
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0304
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ExternalADCAmpSetting(self,data):
        # Set the amplification value for the adc's
        # 2x 16 bit parameters
        # 1.) Number of the amplifier e.g. 0
        # 2.) Value for the amplification. 0-255
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0279
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 2:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_ExternalADCChannelMask(self,data):
        # Set the amplification value for the adc's
        # 2x 16 bit parameters
        # 1.) first 16 ADCs
        # 2.) second 16 ADCs
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x027A
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 2:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_RHASetChannelMask(self,data):
        # Set the RHA channel mask
        # 8x 16 bit parameters
        # ChannelMaskXX = 8 bit Bitmask
        # 1.) ChannelMask01 + 256 * ChannelMask02
        # 2.) ChannelMask03 + 256 * ChannelMask04
        # 3.) ChannelMask05 + 256 * ChannelMask06
        # 4.) ChannelMask07 + 256 * ChannelMask08
        # 5.) ChannelMask09 + 256 * ChannelMask10
        # 6.) ChannelMask11 + 256 * ChannelMask12
        # 7.) ChannelMask13 + 256 * ChannelMask14
        # 8.) ChannelMask15 + 256 * ChannelMask16
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0263
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 8:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_RHAGetChannelMaskInfo(self):
        # Get information about the ASIC channel setting
        # No parameters
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0502
        data = numpy.zeros((0,0),dtype=numpy.uint16)
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_RHASetSampleResolution(self,data):
        # Set the RHA sample resolution
        # 1x 16 bit parameters
        # ChannelMaskXX = 8 bit Bitmask
        # 1.) n+1 Bit resolution 0-15
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0272
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 1:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp

    def Command_RHASetSampleRate(self,data):
        # Set the RHA sample rate
        # 1x 16 bit parameters
        # ChannelMaskXX = 8 bit Bitmask
        # 1.) Samplerate
        CommandID = numpy.zeros((1,1),dtype=numpy.uint16)
        CommandID.flat[0] = 0x0273
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        data = data.flatten()
        if data.size != 1:
            return -3
        Temp = self.BuildPackage(CommandID,data)
        return Temp
