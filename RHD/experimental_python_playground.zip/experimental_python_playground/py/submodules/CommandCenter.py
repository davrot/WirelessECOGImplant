import multiprocessing
import numpy
import time
import ChannelMaskFile

class CommandCenter (multiprocessing.Process):
    def __init__(self,name=None,PipeIn=None,PipeOut=None,PipeControl=None,FilenameChannelMask=None):
        multiprocessing.Process.__init__(self,name=name,group=None,target=None)
        # Allows us to kill the infinite loop from the outside
        self.IAmAlive = True
        # Storing the pipes
        self.PipeIn = PipeIn
        self.PipeOut = PipeOut
        self.PipeControl= PipeControl
        # Load the channel mask
        MyChannelMask = None
        if FilenameChannelMask == None:
            self.IAmAlive = False
        else:
            MyChannelMask = MyChannelMask.MyChannelMask()
            MyChannelMask.LoadFromFile(FilenameChannelMask)



    def run(self):
        # Are all pipes ready?
        if (self.PipeIn == None) or (self.PipeOut == None) or (self.PipeControl == None):
            self.IAmAlive = False
        # Have the pipes the correct attributes?
        if (self.PipeIn.readable == False) or (self.PipeOut.writable == False) or \
                (self.PipeControl.readable == False):
            self.IAmAlive = False
        while self.IAmAlive:
            DidSomething = False
