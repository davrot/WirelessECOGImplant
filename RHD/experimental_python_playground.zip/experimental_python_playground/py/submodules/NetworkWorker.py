import multiprocessing
import numpy
import time
import MyNetwork

class NetworkWorker (multiprocessing.Process):
    def __init__(self,name=None,PipeIn=None,PipeOut=None,PipeControl=None, \
            host=None, port=0x5002, RecvBufferSize = 40960, TimeOutCounterMax = 100, BigEndian = True):
        multiprocessing.Process.__init__(self,name=name,group=None,target=None)
        # Allows us to kill the infinite loop from the outside
        self.IAmAlive = True
        # Storing the pipes
        self.PipeIn = PipeIn
        self.PipeOut = PipeOut
        self.PipeControl= PipeControl
        # Open the network connection
        self.NetworkStack = MyNetwork.MyNetwork(host=host, port=port, RecvBufferSize = RecvBufferSize, \
            TimeOutCounterMax = TimeOutCounterMax, BigEndian = BigEndian)
        # Create receiver buffer
        self.RecvBuffer = None
        if RecvBufferSize > 0:
            self.RecvBuffer = numpy.zeros((RecvBufferSize,1),dtype=numpy.uint16)
            # Check if there is really a buffer with size larger 0
            if self.RecvBuffer.size<= 0:
                self.RecvBuffer = None
                self.IAmAlive = False
        else:
            self.IAmAlive = False

    def run(self):
        # Are all pipes ready?
        if (self.PipeIn == None) or (self.PipeOut == None) or (self.PipeControl == None):
            self.IAmAlive = False
        # Have the pipes the correct attributes?
        if (self.PipeIn.readable == False) or (self.PipeOut.writable == False) or \
                (self.PipeControl.readable == False):
            self.IAmAlive = False
        while self.IAmAlive:
            DidSomething = False
            # Check it there is still a network stack
            if self.NetworkStack.MySocket != None:
                # The outside tells us to stop this infinite loop
                if (self.PipeControl.poll() == True):
                    self.IAmAlive = False
                # Is there something in the network buffer?
                Buffer = self.NetworkStack.receiving()
                if type(Buffer).__module__ == numpy.__name__:
                    self.PipeOut.send_bytes(Buffer)
                    DidSomething = True
                # What data did we got for sending to the network?
                if (self.PipeIn.poll() == True):
                    CollectedByte = self.PipeIn.recv_bytes_into(self.RecvBuffer)
                    if CollectedByte > 0:
                        CollectedUInt16 = CollectedByte>>1
                        Buffer = self.RecvBuffer.flat[0:CollectedUInt16]
                        NumberOfBytesSend = self.NetworkStack.sending(Buffer)
                        DidSomething = True
                        if CollectedByte != NumberOfBytesSend:
                            print "Error: What comes in, must go out..."
                            self.IAmAlive = False
                #if DidSomething == False:
                #    time.sleep(0.01)
            else:
                #No network stack? Let's go home
                self.IAmAlive = False
        # The end of it all
        self.NetworkStack.close()
