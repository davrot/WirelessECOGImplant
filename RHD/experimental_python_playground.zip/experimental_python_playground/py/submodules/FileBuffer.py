import numpy

class FileBuffer:

    def __init__(self,MaxBufferSize_Trials=10240,MaxBufferSize_Channels=256,Filename=None):
        self.MaxBufferSize_Trials = MaxBufferSize_Trials
        self.MaxBufferSize_Channels = MaxBufferSize_Channels+4+1+1
        self.MaxUsedChannelNumbers = numpy.array([0],dtype=numpy.uint16)
        self.ActualPosition = 0
        self.Buffer = None
        if (self.MaxBufferSize_Trials != None) and (self.MaxBufferSize_Channels != None):
            self.Buffer = numpy.zeros((self.MaxBufferSize_Trials,self.MaxBufferSize_Channels),dtype=numpy.uint16)
        self.HeaderWritten = 0
        self.Filename = Filename

    def CleanToFile(self):
        if type(self.Buffer).__module__ != numpy.__name__:
            return -1
        if self.MaxUsedChannelNumbers == 0:
            return -2
        if self.Filename == None:
            return -3
        if self.ActualPosition > 0:
            FileID = open(self.Filename,'ab')
            FileID.write(self.Buffer[0:self.ActualPosition,0:self.MaxUsedChannelNumbers].tobytes())
            FileID.close()
        self.ActualPosition = 0
        return 0

    def AddTrials(self, data):
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        if type(self.Buffer).__module__ != numpy.__name__:
            return -3
        if self.MaxUsedChannelNumbers == 0:
            self.MaxUsedChannelNumbers.flat[0] = data.size
        if self.MaxUsedChannelNumbers != data.size:
            return -4
        if self.Filename == None:
            return -5
        # We need to write the header
        if self.HeaderWritten == 0:
            FileID = open(self.Filename,'w+b')
            FileID.write(self.MaxUsedChannelNumbers.tobytes())
            FileID.close()
            self.HeaderWritten = 1
        # Buffer is full!!!!
        if self.ActualPosition == self.MaxBufferSize_Trials:
            # We need to save the stuff somehow
            self.CleanToFile()
        self.Buffer[self.ActualPosition,0:self.MaxUsedChannelNumbers] = data.flatten()
        self.ActualPosition = self.ActualPosition + 1
