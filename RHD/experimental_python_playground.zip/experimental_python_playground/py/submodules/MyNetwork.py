import socket
import sys
import numpy
import select

class MyNetwork:

    # Constructor
    def __init__(self, host=None, port=0x5002, RecvBufferSize = 40960, TimeOutCounterMax = 100, BigEndian = True):
        # Endian-ness of the data transfer
        self.BigEndian = BigEndian
        # Max number of retries for sending data in the case no data can be transmitted
        self.TimeOutCounterMax = TimeOutCounterMax;
        # Create receiver buffer
        self.RecvBuffer = None
        if RecvBufferSize > 0:
            self.RecvBuffer = numpy.zeros((RecvBufferSize,1),dtype=numpy.uint16)
        # Check if there is really a buffer with size larger 0
        if self.RecvBuffer.size<= 0:
            self.RecvBuffer = None
        # The socket part:
        self.MySocket = None
        # Prepare the socket
        if (host != None) and (port != None):
            for Result in socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM):
                af, socktype, proto, canonname, sa = Result
                try:
                    self.MySocket = socket.socket(af, socktype, proto)
                except socket.error as msg:
                    self.MySocket = None
                    continue
                # Create the corresponding connection
                try:
                    self.MySocket.connect(sa)
                except socket.error as msg:
                    self.MySocket.close()
                    self.MySocket = None
                    continue
                break
            # Set connection to non-blocking
            if self.MySocket != None:
                self.MySocket.setblocking(0)

    # Close the connection
    def close(self):
        if self.MySocket != None:
            self.MySocket.close()
        self.MySocket = None

    # It is all about sending a message!
    def sending(self, data):
        TimeOutCounter = 0
        BytesSendInTotal = 0
        # Is there a network socket ready?
        if self.MySocket == None:
            return -1
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -2
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -3
        # How many bytes should we send
        data = data.flatten()
        BytesToSend = data.size
        # Modify endianess if neccessary
        if self.BigEndian == True:
            data = data.byteswap()
        data = data.view(dtype=numpy.uint8)
        # If the number is zero then we are done
        if BytesToSend == 0:
            return 0
        # From here on we can assume that the data is of the correct type
        while BytesSendInTotal < BytesToSend:
            # Socket transaction
            SelectRead, SelectWrite, SelectError = select.select([],[self.MySocket],[], 0.01)
            BytesSend = 0
            if len(SelectWrite) > 0:
                BytesSend = self.MySocket.send(data[BytesSendInTotal:])
                BytesSendInTotal = BytesSendInTotal + BytesSend
            if BytesSend == 0:
                TimeOutCounter = TimeOutCounter + 1
            else:
                TimeOutCounter = 0
            if TimeOutCounter >= self.TimeOutCounterMax:
                return BytesSendInTotal
        return BytesSendInTotal

    def receiving(self):
        CollectedByte = 0;
        # Is there a network socket ready?
        if self.MySocket == None:
            return -1
        # Is there a receiver buffer?
        if type(self.RecvBuffer).__module__ != numpy.__name__:
            return -2
        # Collect the data
        SelectRead, SelectWrite, SelectError = select.select([self.MySocket],[],[], 0.01)
        if len(SelectRead) > 0:
            CollectedByte = self.MySocket.recv_into(self.RecvBuffer)
            if CollectedByte > 0:
                # Return value is in byte and not in uint16 units
                CollectedByte = CollectedByte >> 1
                # Modify endianess if neccessary
                if self.BigEndian == True:
                    self.RecvBuffer = self.RecvBuffer.byteswap()
                Buffer = self.RecvBuffer.flat[0:CollectedByte]
                # FileID = open("Network-Dump.1",'ab')
                # FileID.write(Buffer.tobytes())
                # FileID.close()
                # print "NB:" , Buffer
                # print "LB:", len(Buffer)
                return Buffer
            else:
                return 0
        else:
            return -99
