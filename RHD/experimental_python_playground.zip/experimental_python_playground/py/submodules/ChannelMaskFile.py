import json
import FirmwareCommands
import numpy

class ChannelMaskFile:

    def __init__(self):
          self.ChannelSetup_1 = []
          self.ChannelSetup_2 = []
          self.ChannelSetup_3 = []
          self.ChannelSetup_4 = []
          self.ChannelSetup_5 = []
          self.ChannelSetup_6 = []
          self.ChannelSetup_7 = []
          self.ChannelSetup_8 = []
          self.ChannelSetup_1A = []
          self.ChannelSetup_2A = []
          self.ChannelSetup_3A = []
          self.ChannelSetup_4A = []
          self.ChannelSetup_5A = []
          self.ChannelSetup_6A = []
          self.ChannelSetup_7A = []
          self.ChannelSetup_8A = []
          self.RHDModel = 1
          self.SumChannelSetup_1 = []
          self.SumChannelSetup_2 = []
          self.SumChannelSetup_3 = []
          self.SumChannelSetup_4 = []
          self.SumChannelSetup_5 = []
          self.SumChannelSetup_6 = []
          self.SumChannelSetup_7 = []
          self.SumChannelSetup_8 = []
          self.SumChannelSetup_1A = []
          self.SumChannelSetup_2A = []
          self.SumChannelSetup_3A = []
          self.SumChannelSetup_4A = []
          self.SumChannelSetup_5A = []
          self.SumChannelSetup_6A = []
          self.SumChannelSetup_7A = []
          self.SumChannelSetup_8A = []
          self.SumChannels = []
          self.SumChannels_A = []
          self.SumSum = []
          self.SumSum_A = []
          self.Total = []
          self.RHDCommands = None

    # RHD Normale Channels
    def ChannelRecode(self,ChannelSetup):
        # Value A
        ValueA = ChannelSetup[7]
        ValueA = ChannelSetup[6] + (ValueA<<1)
        ValueA = ChannelSetup[5] + (ValueA<<1)
        ValueA = ChannelSetup[4] + (ValueA<<1)
        ValueA = ChannelSetup[3] + (ValueA<<1)
        ValueA = ChannelSetup[2] + (ValueA<<1)
        ValueA = ChannelSetup[1] + (ValueA<<1)
        ValueA = ChannelSetup[0] + (ValueA<<1)
        # Value B
        ValueB = ChannelSetup[15]
        ValueB = ChannelSetup[14] + (ValueB<<1)
        ValueB = ChannelSetup[13] + (ValueB<<1)
        ValueB = ChannelSetup[12] + (ValueB<<1)
        ValueB = ChannelSetup[11] + (ValueB<<1)
        ValueB = ChannelSetup[10] + (ValueB<<1)
        ValueB = ChannelSetup[ 9] + (ValueB<<1)
        ValueB = ChannelSetup[ 8] + (ValueB<<1)
        # Value C
        ValueC = ChannelSetup[23]
        ValueC = ChannelSetup[22] + (ValueC<<1)
        ValueC = ChannelSetup[21] + (ValueC<<1)
        ValueC = ChannelSetup[20] + (ValueC<<1)
        ValueC = ChannelSetup[19] + (ValueC<<1)
        ValueC = ChannelSetup[18] + (ValueC<<1)
        ValueC = ChannelSetup[17] + (ValueC<<1)
        ValueC = ChannelSetup[16] + (ValueC<<1)
        # Value D
        ValueD = ChannelSetup[31]
        ValueD = ChannelSetup[30] + (ValueD<<1)
        ValueD = ChannelSetup[29] + (ValueD<<1)
        ValueD = ChannelSetup[28] + (ValueD<<1)
        ValueD = ChannelSetup[27] + (ValueD<<1)
        ValueD = ChannelSetup[26] + (ValueD<<1)
        ValueD = ChannelSetup[25] + (ValueD<<1)
        ValueD = ChannelSetup[24] + (ValueD<<1)
        # Returning the result
        return (ValueA,ValueB,ValueC,ValueD)

    # RHD Auxilery Channels
    def ChannelRecode_A(self,ChannelSetup):
        # Value A
        ValueA = ChannelSetup[0]
        ValueA = ChannelSetup[1] + (ValueA<<1)
        ValueA = ChannelSetup[2] + (ValueA<<1)
        return ValueA

    def AddRHDCommand(self,ChannelSetup,ChannelID):
        #-- Channel Mask Setting sequence:
        #-- ------------------------------------
        #--	constant HeaderByte_1	: std_logic_vector(7 downto 0) := "00110000"; -- 48
        #--	constant HeaderByte_2	: std_logic_vector(7 downto 0) := "01101001"; -- 105
        #--	constant Implant_ID     : std_logic_vector(7 downto 0) := "00110101"; -- Implant ID 53
        #-- constant Command_Channel: std_logic_vector(7 downto 0) := "10101011";
        #-- 1. Byte Which RHD ? 0 -7
        #-- 2. Byte Channel Mask 31 downto 24
        #-- 3. Byte Channel Mask 23 downto 16
        #-- 4. Byte Channel Mask 15 downto  8
        #-- 5. Byte Channel Mask  7 downto  0
        Value_0 = 48
        Value_1 = 105
        Value_2 = 53
        Value_3 = 171
        Value_4 = ChannelID
        Value_8, Value_7, Value_6, Value_5 = self.ChannelRecode(ChannelSetup)
        Value_9 = 0
        Value_10 = 0
        Value_11 = 0
        Value_12 = 0
        Value_13 = 0
        ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
        ValueString.flat[0] = Value_0  + 256 * Value_1
        ValueString.flat[1] = Value_2  + 256 * Value_3
        ValueString.flat[2] = Value_4  + 256 * Value_5
        ValueString.flat[3] = Value_6  + 256 * Value_7
        ValueString.flat[4] = Value_8  + 256 * Value_9
        ValueString.flat[5] = Value_10 + 256 * Value_11
        ValueString.flat[6] = Value_12 + 256 * Value_13
        TM = FirmwareCommands.FirmwareCommands()
        Temp = TM.Command_ZarlinkBlockWrite(ValueString)
        self.RHDCommands.append(Temp)

    def AddRHDCommand_A(self,ChannelSetup,ChannelID):
        #-- Aux Mask Setting sequence:
        #-- ------------------------------------
        #--	constant HeaderByte_1	: std_logic_vector(7 downto 0) := "00110000"; -- 48
        #--	constant HeaderByte_2	: std_logic_vector(7 downto 0) := "01101001"; -- 105
        #--	constant Implant_ID     : std_logic_vector(7 downto 0) := "00110101"; -- Implant ID 53
        #-- constant Command_Aux: std_logic_vector(7 downto 0) := "10001010";
        #-- First Byte:
        #-- Which RHD ? 0 -7
        #-- Second Byte:
        #--	3 Bit Mask which Aux Channel should be active
        Value_0 = 48
        Value_1 = 105
        Value_2 = 53
        Value_3 = 138
        Value_4 = ChannelID
        Value_5 = self.ChannelRecode_A(ChannelSetup)
        Value_6 = 0
        Value_7 = 0
        Value_8 = 0
        Value_9 = 0
        Value_10 = 0
        Value_11 = 0
        Value_12 = 0
        Value_13 = 0
        ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
        ValueString.flat[0] = Value_0  + 256 * Value_1
        ValueString.flat[1] = Value_2  + 256 * Value_3
        ValueString.flat[2] = Value_4  + 256 * Value_5
        ValueString.flat[3] = Value_6  + 256 * Value_7
        ValueString.flat[4] = Value_8  + 256 * Value_9
        ValueString.flat[5] = Value_10 + 256 * Value_11
        ValueString.flat[6] = Value_12 + 256 * Value_13
        TM = FirmwareCommands.FirmwareCommands()
        Temp = TM.Command_ZarlinkBlockWrite(ValueString)
        self.RHDCommands.append(Temp)

    def LoadFromFile(self,Filename):
        if (Filename != "") and (Filename != "None"):
            FileHandel = open(Filename,'r')
            self.ChannelSetup_1, self.ChannelSetup_2, \
                self.ChannelSetup_3, self.ChannelSetup_4, self.ChannelSetup_5, \
                self.ChannelSetup_6, self.ChannelSetup_7, self.ChannelSetup_8, \
                self.ChannelSetup_1A, self.ChannelSetup_2A, self.ChannelSetup_3A, \
                self.ChannelSetup_4A, self.ChannelSetup_5A, self.ChannelSetup_6A, \
                self.ChannelSetup_7A, self.ChannelSetup_8A, self.RHDModel = json.load(FileHandel)
            FileHandel.close()
            self.SumChannelSetup_1 = sum(self.ChannelSetup_1)
            self.SumChannelSetup_2 = sum(self.ChannelSetup_2)
            self.SumChannelSetup_3 = sum(self.ChannelSetup_3)
            self.SumChannelSetup_4 = sum(self.ChannelSetup_4)
            self.SumChannelSetup_5 = sum(self.ChannelSetup_5)
            self.SumChannelSetup_6 = sum(self.ChannelSetup_6)
            self.SumChannelSetup_7 = sum(self.ChannelSetup_7)
            self.SumChannelSetup_8 = sum(self.ChannelSetup_8)
            self.SumChannelSetup_1A = sum(self.ChannelSetup_1A)
            self.SumChannelSetup_2A = sum(self.ChannelSetup_2A)
            self.SumChannelSetup_3A = sum(self.ChannelSetup_3A)
            self.SumChannelSetup_4A = sum(self.ChannelSetup_4A)
            self.SumChannelSetup_5A = sum(self.ChannelSetup_5A)
            self.SumChannelSetup_6A = sum(self.ChannelSetup_6A)
            self.SumChannelSetup_7A = sum(self.ChannelSetup_7A)
            self.SumChannelSetup_8A = sum(self.ChannelSetup_8A)
            self.SumChannels = [self.SumChannelSetup_1, self.SumChannelSetup_2, self.SumChannelSetup_3, \
                self.SumChannelSetup_4, self.SumChannelSetup_5, self.SumChannelSetup_6, \
                self.SumChannelSetup_7, self.SumChannelSetup_8]
            self.SumSum = sum(self.SumChannels)
            self.SumChannels_A = [self.SumChannelSetup_1A, self.SumChannelSetup_2A, self.SumChannelSetup_3A, \
                self.SumChannelSetup_4A, self.SumChannelSetup_5A, self.SumChannelSetup_6A, \
                self.SumChannelSetup_7A, self.SumChannelSetup_8A]
            self.SumSum_A = sum(self.SumChannels_A)
            self.Total = self.SumSum + self.SumSum_A
            if self.RHDModel == 1:
                self.RHDCommands = []
                self.AddRHDCommand(self.ChannelSetup_1,0)
                self.AddRHDCommand(self.ChannelSetup_2,1)
                self.AddRHDCommand(self.ChannelSetup_3,2)
                self.AddRHDCommand(self.ChannelSetup_4,3)
                self.AddRHDCommand(self.ChannelSetup_5,4)
                self.AddRHDCommand(self.ChannelSetup_6,5)
                self.AddRHDCommand(self.ChannelSetup_7,6)
                self.AddRHDCommand(self.ChannelSetup_8,7)
                self.AddRHDCommand_A(self.ChannelSetup_1A,0)
                self.AddRHDCommand_A(self.ChannelSetup_2A,1)
                self.AddRHDCommand_A(self.ChannelSetup_3A,2)
                self.AddRHDCommand_A(self.ChannelSetup_4A,3)
                self.AddRHDCommand_A(self.ChannelSetup_5A,4)
                self.AddRHDCommand_A(self.ChannelSetup_6A,5)
                self.AddRHDCommand_A(self.ChannelSetup_7A,6)
                self.AddRHDCommand_A(self.ChannelSetup_8A,7)
            # The stuff for the RHA is different
            # else:
