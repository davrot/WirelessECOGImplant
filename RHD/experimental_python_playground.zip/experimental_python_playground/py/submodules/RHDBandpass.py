import FirmwareCommands
import numpy

class RHDBandpass:

    def __init__(self):
        # Low Pass
        self.LP_Database = []
        self.LP_Database.append((500,13,0,0))
        self.LP_Database.append((300,15,0,0))
        self.LP_Database.append((250,17,0,0))
        self.LP_Database.append((200,18,0,0))
        self.LP_Database.append((150,21,0,0))
        self.LP_Database.append((100,25,0,0))
        self.LP_Database.append((75,28,0,0))
        self.LP_Database.append((50,34,0,0))
        self.LP_Database.append((30,44,0,0))
        self.LP_Database.append((25,48,0,0))
        self.LP_Database.append((20,54,0,0))
        self.LP_Database.append((15,62,0,0))
        self.LP_Database.append((10,5,1,0))
        self.LP_Database.append((7.5,18,1,0))
        self.LP_Database.append((5.0,40,1,0))
        self.LP_Database.append((3.0,20,2,0))
        self.LP_Database.append((2.5,42,2,0))
        self.LP_Database.append((2.0,8,3,0))
        self.LP_Database.append((1.5,9,4,0))
        self.LP_Database.append((1.0,44,6,0))
        self.LP_Database.append((0.75,49,9,0))
        self.LP_Database.append((0.50,35,17,0))
        self.LP_Database.append((0.30,1,40,0))
        self.LP_Database.append((0.25,56,54,0))
        self.LP_Database.append((0.10,16,60,1))
        # High Pass
        self.HP_Database = []
        self.HP_Database.append((20000,8,0,4,0))
        self.HP_Database.append((15000,11,0,8,0))
        self.HP_Database.append((10000,17,0,16,0))
        self.HP_Database.append((7500,22,0,23,0))
        self.HP_Database.append((5000,33,0,37,0))
        self.HP_Database.append((3000,3,1,13,1))
        self.HP_Database.append((2500,13,1,25,1))
        self.HP_Database.append((2000,27,1,44,1))
        self.HP_Database.append((1500,1,2,23,2))
        self.HP_Database.append((1000,46,2,30,3))
        self.HP_Database.append((750,41,3,36,4))
        self.HP_Database.append((500,30,5,43,6))
        self.HP_Database.append((300,6,9,2,11))
        self.HP_Database.append((250,42,10,5,13))
        self.HP_Database.append((200,24,13,7,16))
        self.HP_Database.append((150,44,17,8,21))
        self.HP_Database.append((100,38,26,5,31))
        # The commands for the RHD
        self.RHDCommands = []
        self.RHDCommands_Responses = []
        self.RHDCommands_Name = []

    def AddRHDCommand_Internal(self,RHA_MASK,RHA_Command_Low,RHA_Command_High):
        #-- RHD Register Setting sequence:
        #-- A direct connection to the RHA via SPI
        #-- (stops the data acquisition)
        #-- ------------------------------------
        #-- constant HeaderByte_1 : std_logic_vector(7 downto 0) := "00110000"; -- 48
        #-- constant HeaderByte_2 : std_logic_vector(7 downto 0) := "01101001"; -- 105
        #-- constant Implant_ID     : std_logic_vector(7 downto 0) := "00110101"; -- Implant ID 53
        #-- constant Command_RHD_COMMAND : std_logic_vector(7 downto 0) := "10101010";
        #-- First Byte:
        #-- Bit MASK which of the RHD are meant
        #-- Second Byte:
        #-- RHD_COMMAND_DATA(15 downto 8)
        #-- Third Byte
        #-- RHD_COMMAND_DATA(7 downto 0)
        Value_0 = 48
        Value_1 = 105
        Value_2 = 53
        Value_3 = 170
        Value_4 = RHA_MASK
        Value_5 = RHA_Command_High
        Value_6 = RHA_Command_Low
        Value_7 = 0
        Value_8 = 0
        Value_9 = 0
        Value_10 = 0
        Value_11 = 0
        Value_12 = 0
        Value_13 = 0
        ValueString = numpy.zeros((7,1),dtype=numpy.uint16)
        ValueString.flat[0] = Value_0  + 256 * Value_1
        ValueString.flat[1] = Value_2  + 256 * Value_3
        ValueString.flat[2] = Value_4  + 256 * Value_5
        ValueString.flat[3] = Value_6  + 256 * Value_7
        ValueString.flat[4] = Value_8  + 256 * Value_9
        ValueString.flat[5] = Value_10 + 256 * Value_11
        ValueString.flat[6] = Value_12 + 256 * Value_13
        TM = FirmwareCommands.FirmwareCommands()
        Temp = TM.Command_ZarlinkBlockWrite(ValueString)
        self.RHDCommands.append(Temp)


### Global RHD Stuff
    def AddRHDCommand_Register0(self,RHA_MASK):
        # 10 dec2bin(0,6)
        RHA_Command_High = 128
        RHA_Command_Low = 222 # "11011110" (don't touch this...)
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register1(self,RHA_MASK):
        # 10 dec2bin(1,6)
        RHA_Command_High = 129
        RHA_Command_Low = 2 # "00000010" > 700kSamples / sec (don't touch this)
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register2(self,RHA_MASK):
        # 10 dec2bin(2,6)
        RHA_Command_High = 130
        RHA_Command_Low = 4 # 00000100 > 700kSamples / sec (don't touch this)
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register3(self,RHA_MASK):
        # 10 dec2bin(3,6)
        RHA_Command_High = 131
        RHA_Command_Low = 0 # "00000000" No temp, no digout
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register4(self,RHA_MASK):
        # 10 dec2bin(4,6)
        RHA_Command_High = 132
        RHA_Command_Low = 128 # "10000000" Output:Non-signed values, No DSP
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register5(self,RHA_MASK):
        # 10 dec2bin(5,6)
        RHA_Command_High = 133
        RHA_Command_Low = 0 # "00000000" No DAC, No impedance test
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register6(self,RHA_MASK):
        # 10 dec2bin(6,6)
        RHA_Command_High = 134
        RHA_Command_Low = 0 # "00000000" No DAC, No impedance test
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register7(self,RHA_MASK):
        # 10 dec2bin(7,6)
        RHA_Command_High = 135
        RHA_Command_Low = 0 # "00000000" No DAC, No impedance test
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

### Bandpass parameters:
    def AddRHDCommand_Register8(self,RHA_MASK,HP_ID):
        # 10 dec2bin(8,6)
        RHA_Command_High = 136
        Freq, RH1_DAC1, RH1_DAC2, RH2_DAC1, RH2_DAC2 = self.HP_Database[HP_ID]
        RHA_Command_Low = RH1_DAC1
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register9(self,RHA_MASK,HP_ID):
        # 10 dec2bin(9,6)
        RHA_Command_High = 137
        Freq, RH1_DAC1, RH1_DAC2, RH2_DAC1, RH2_DAC2 = self.HP_Database[HP_ID]
        RHA_Command_Low = RH1_DAC2 + 128
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register10(self,RHA_MASK,HP_ID):
        # 10 dec2bin(10,6)
        RHA_Command_High = 138
        Freq, RH1_DAC1, RH1_DAC2, RH2_DAC1, RH2_DAC2 = self.HP_Database[HP_ID]
        RHA_Command_Low = RH2_DAC1
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register11(self,RHA_MASK,HP_ID):
        # 10 dec2bin(11,6)
        RHA_Command_High = 139
        Freq, RH1_DAC1, RH1_DAC2, RH2_DAC1, RH2_DAC2 = self.HP_Database[HP_ID]
        RHA_Command_Low = RH2_DAC2 + 128
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register12(self,RHA_MASK,LP_ID):
        # 10 dec2bin(12,6)
        RHA_Command_High = 140
        Freq, RL_DAC1, RL_DAC2, RL_DAC3 = self.LP_Database[LP_ID]
        RHA_Command_Low = RL_DAC1
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register13(self,RHA_MASK,LP_ID):
        # 10 dec2bin(13,6)
        RHA_Command_High = 141
        Freq, RL_DAC1, RL_DAC2, RL_DAC3 = self.LP_Database[LP_ID]
        RHA_Command_Low = RL_DAC2 + 64 * RL_DAC3 + 128
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

### Let's power the RHAs up
    def AddRHDCommand_Register14(self,RHA_MASK):
        # 10 dec2bin(14,6)
        RHA_Command_High = 142
        RHA_Command_Low = 255 # "11111111" ALL ON
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register15(self,RHA_MASK):
        # 10 dec2bin(15,6)
        RHA_Command_High = 143
        RHA_Command_Low = 255 # "11111111" ALL ON
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register16(self,RHA_MASK):
        # 10 dec2bin(16,6)
        RHA_Command_High = 144
        RHA_Command_Low = 255 # "11111111" ALL ON
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Register17(self,RHA_MASK):
        # 10 dec2bin(17,6)
        RHA_Command_High = 128
        RHA_Command_Low = 255 # "11111111" ALL ON
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)

    def AddRHDCommand_Calibrate(self,RHA_MASK):
        RHA_Command_High = 85
        RHA_Command_Low = 0
        self.AddRHDCommand_Internal(RHA_MASK,RHA_Command_Low,RHA_Command_High)


    def AddRHDCommand_RegALL(self,RHA_MASK,HP_ID,LP_ID):
        self.AddRHDCommand_Register0(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg00: ADC Configuration and Amplifier Fast Settle")
        self.AddRHDCommand_Register1(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg01: Supply Sensor and ADC Buffer Bias Current")
        self.AddRHDCommand_Register2(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg02: MUX Bias Current")
        self.AddRHDCommand_Register3(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg03: MUX Load, Temp Sensor, Aux Out")
        self.AddRHDCommand_Register4(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg04: ADC Out Format (non-signed), DSP Offset Removal")
        self.AddRHDCommand_Register5(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg05: Impendance Check Control")
        self.AddRHDCommand_Register6(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg06: Impedance Check DAC")
        self.AddRHDCommand_Register7(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg07: Impedance Check Amplifier Select")
        self.AddRHDCommand_Register8(RHA_MASK,HP_ID)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg08: On-Chip Amplifier Bandwidth Select A")
        self.AddRHDCommand_Register9(RHA_MASK,HP_ID)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg09: On-Chip Amplifier Bandwidth Select B")
        self.AddRHDCommand_Register10(RHA_MASK,HP_ID)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg10: On-Chip Amplifier Bandwidth Select C")
        self.AddRHDCommand_Register11(RHA_MASK,HP_ID)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg11: On-Chip Amplifier Bandwidth Select D")
        self.AddRHDCommand_Register12(RHA_MASK,LP_ID)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg12: On-Chip Amplifier Bandwidth Select E")
        self.AddRHDCommand_Register13(RHA_MASK,LP_ID)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg13: On-Chip Amplifier Bandwidth Select F")
        self.AddRHDCommand_Register14(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg14: Individual Amplifier Power 0 - 7")
        self.AddRHDCommand_Register15(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg15: Individual Amplifier Power 15 - 8")
        self.AddRHDCommand_Register16(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg16: Individual Amplifier Power 23 - 16")
        self.AddRHDCommand_Register17(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD Reg17: Individual Amplifier Power 31 - 17")
        self.AddRHDCommand_Calibrate(RHA_MASK)
        self.RHDCommands_Responses.append((1028))
        self.RHDCommands_Name.append("RHD calibrate")
