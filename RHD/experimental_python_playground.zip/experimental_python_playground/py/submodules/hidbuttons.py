import Tkinter

class hidbuttons(Tkinter.Frame):
    def __init__(self, master):
        Tkinter.Frame.__init__(self,master)
        self.grid()
        self.createWidgets(master)

    def createWidgets(self, master):
        # Setting up the menu

        # The master menu
        self.TheMenu = Tkinter.Menu(master)
        master.config(menu=self.TheMenu)

        # Add the submenu file
        self.SubMenuFile = Tkinter.Menu(self.TheMenu)
        self.TheMenu.add_cascade(label="File", menu=self.SubMenuFile)
        # File -> Configuration files
        self.SubMenuFile.add_command(label="Settings...", command=self.quit)
        self.SubMenuFile.add_command(label="Load settings", command=self.quit)
        self.SubMenuFile.add_command(label="Save settings", command=self.quit)
        # file -> ----
        self.SubMenuFile.add_separator()
        # file -> Quit
        self.SubMenuFile.add_command(label="Quit", command=self.quit)

        self.quitButton = Tkinter.Button(self, text='Quit', command=self.quit)
        self.quitButton.grid()
