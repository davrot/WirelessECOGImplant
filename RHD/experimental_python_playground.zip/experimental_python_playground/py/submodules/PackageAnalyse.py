import numpy

class PackageAnalyse:
    def __init__(self):
        # BasestationData,RHXData,ZarlinkData,ExternalADCData,TriggerData
        self.AllowedPackages = [0x8000,0x8001,0x8002,0x8003,0x8004,0x6542]
        self.HeaderID = 21930
        self.Error = 0
        self.Module = 0
        self.FoundData = 0
        self.PackageType = 0
        self.Timestamp_Implant = numpy.array([0],dtype=numpy.uint16)
        self.Timestamp_Basestation = numpy.array([0,0,0,0],dtype=numpy.uint64)
        self.Triggerchannel = numpy.array([0,0],dtype=numpy.uint32)
        self.Status = numpy.array([0],dtype=numpy.uint16)

    def CalcCRC(self,data,CRCValue):
        Result = numpy.zeros((1,1),dtype=numpy.uint16)
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint8) == False:
            return -2
        # Is "CRCValue" really a numpy element?
        if type(CRCValue).__module__ != numpy.__name__:
            return -3
        if numpy.issubdtype(CRCValue.dtype,numpy.uint8) == False:
            return -4
        # Is it a scalar?
        if CRCValue.size != 1:
            return -5
        data = data.flatten()
        # Calculate the CRC values
        for i in range(0, data.size):
            if ((data.flat[i] >> 0) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
            if ((data.flat[i] >> 2) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
            if ((data.flat[i] >> 4) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
            if ((data.flat[i] >> 6) & 3) == CRCValue.flat[0]:
                Result.flat[0] = Result.flat[0] + 1
        return Result

    def CheckPackage(self,data):
        # Is "data" really a numpy element?
        if type(data).__module__ != numpy.__name__:
            return -1
        if numpy.issubdtype(data.dtype,numpy.uint16) == False:
            return -2
        # First CRC value
        CRCValue = numpy.zeros((1,1),dtype=numpy.uint8)
        CRCValue.flat[0] = 0
        Temp = self.CalcCRC(data.flat[0:-4].view(dtype=numpy.uint8),CRCValue)
        if data.flat[-4] != Temp:
            return -3
        # Second CRC value
        CRCValue.flat[0] = 1
        Temp = self.CalcCRC(data.flat[0:-4].view(dtype=numpy.uint8),CRCValue)
        if data.flat[-3] != Temp:
            return -4
        # Third CRC value
        CRCValue.flat[0] = 2
        Temp = self.CalcCRC(data.flat[0:-4].view(dtype=numpy.uint8),CRCValue)
        if data.flat[-2] != Temp:
            return -5
        # Last CRC value
        CRCValue.flat[0] = 3
        Temp = self.CalcCRC(data.flat[0:-4].view(dtype=numpy.uint8),CRCValue)
        if data.flat[-1] != Temp:
            return -6
        # Check Header
        if data.flat[0] != self.HeaderID:
            return -7
        # Check Length
        if data.flat[1] != (data.size<<1):
            return -8
        # Check Package Types
        PackageKnown = 0
        for i in xrange(0, len(self.AllowedPackages)):
            if data.flat[2] == self.AllowedPackages[i]:
                PackageKnown = 1
        if PackageKnown == 0:
            return -9
        # No error found
        return 0

    def Depack(self,data):
        self.Error = 0
        self.Module = 0
        self.FoundData = 0
        self.PackageType = 0
        self.data = data
        # Check if the package is structurally okay
        PackageCorrect = self.CheckPackage(data)
        if PackageCorrect != 0:
            self.Error = PackageCorrect
        else:
            self.PackageType = data.flat[2]
            # Datapackages of the type 0x8000 and 0x8002
            if (data.flat[2] == 0x8000) or (data.flat[2] == 0x8002):
                self.Module = data.flat[3]
                self.Error = data.flat[4]
                self.FoundData = data.flat[5:-4]
            # Datapackages of the type 0x8001
            elif (data.flat[2] == 0x8001) or (data.flat[2] == 0x8003) or (data.flat[2] == 0x6542):
                self.FoundData = data.flat[3:-4]
            elif (data.flat[2] == 0x8004):
                self.Timestamp_Implant.flat[0] = data.flat[3]
                self.Timestamp_Basestation.flat[0] = (data.flat[4]<<48) + (data.flat[5]<<32) \
                  + (data.flat[6]<<16) + data.flat[7]
                self.Triggerchannel.flat[0] = (data.flat[8]<<16) + data.flat[9]
            # I don't to know what to do with this package type
            else:
                self.FoundData = data.flat[3:-4]
