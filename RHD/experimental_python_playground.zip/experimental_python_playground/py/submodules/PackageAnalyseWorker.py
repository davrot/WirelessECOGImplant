import multiprocessing
import numpy
import time
import MyNetwork
import PackageAnalyse

class PackageAnalyseWorker (multiprocessing.Process):
    def __init__(self,name=None,PipeIn=None,PipeOut=None,PipeControl=None, RecvBufferSize = 90000):
        multiprocessing.Process.__init__(self,name=name,group=None,target=None)
        # Allows us to kill the infinite loop from the outside
        self.IAmAlive = True
        # Storing the pipes
        self.PipeIn = PipeIn
        self.PipeOut = PipeOut
        self.PipeControl= PipeControl
        # Create receiver buffer
        self.RecvBuffer = None
        self.AnalyzingBuffer = None
        self.RecvBufferSize = RecvBufferSize
        if RecvBufferSize > 0:
            self.RecvBuffer = numpy.zeros((RecvBufferSize,1),dtype=numpy.uint16)
            self.AnalyzingBuffer = numpy.zeros((RecvBufferSize*3,1),dtype=numpy.uint16)
            # Check if there is really a buffer with size larger 0
            if self.RecvBuffer.size<= 0:
                self.RecvBuffer = None
                self.IAmAlive = False
            if self.AnalyzingBuffer.size<= 0:
                self.AnalyzingBuffer = None
                self.IAmAlive = False
        self.AnalyzingBuffer_Position = 0;
        self.AnalyzingBuffer_End = 0;
        # And the tool for analyzing the package
        self.PAnalyzer = PackageAnalyse.PackageAnalyse()
        # We need to find the begining of the next package
        # For this task we need some parameters
        # BasestationData,RHXData,ZarlinkData,ExternalADCData,TriggerData
        self.AllowedPackages = self.PAnalyzer.AllowedPackages
        self.HeaderID = self.PAnalyzer.HeaderID
        self.PackageLength = -1
        self.PackageStartFound = -1
        self.PutativePackage = 0


    def run(self):
        # Are all pipes ready?
        if (self.PipeIn == None) or (self.PipeOut == None) or (self.PipeControl == None):
            self.IAmAlive = False
        # Have the pipes the correct attributes?
        if (self.PipeIn.readable == False) or (self.PipeOut.writable == False) or \
                (self.PipeControl.readable == False):
            self.IAmAlive = False
        while self.IAmAlive:
            DidSomething = False
            # The outside tells us to stop this infinite loop
            if (self.PipeControl.poll() == True):
                self.IAmAlive = False
            # If the buffer is more than half used then we need to clean it
            if (self.AnalyzingBuffer_Position > self.RecvBufferSize) and (self.PackageStartFound < 0):
                RemainingElements = self.AnalyzingBuffer_End - self.AnalyzingBuffer_Position
                # print "Clean Buffer...", self.AnalyzingBuffer_Position, self.AnalyzingBuffer_End,
                if RemainingElements > 0:
                    self.AnalyzingBuffer.flat[0:RemainingElements] = \
                        self.AnalyzingBuffer.flat[self.AnalyzingBuffer_Position:self.AnalyzingBuffer_End]
                    self.AnalyzingBuffer_End = RemainingElements
                else:
                    self.AnalyzingBuffer_End = 0
                self.AnalyzingBuffer_Position = 0
                # print self.AnalyzingBuffer_Position, self.AnalyzingBuffer_End
            # What data did we got for processing?
            Buffer = []
            if (self.PipeIn.poll() == True) and (self.AnalyzingBuffer_End < self.RecvBufferSize*2):
                CollectedByte = self.PipeIn.recv_bytes_into(self.RecvBuffer)
                if CollectedByte > 0:
                    CollectedUInt16 = CollectedByte>>1
                    Buffer = self.RecvBuffer.flat[0:CollectedUInt16]
                    #FileID = open("Network-Dump.2",'ab')
                    #FileID.write(Buffer.tobytes())
                    #FileID.close()
                    DidSomething = True
            # Add the new chunk of data to the AnalyzingBuffer
            if type(Buffer).__module__ == numpy.__name__:
                self.AnalyzingBuffer.flat[self.AnalyzingBuffer_End:self.AnalyzingBuffer_End+Buffer.size] = Buffer
                self.AnalyzingBuffer_End = self.AnalyzingBuffer_End+Buffer.size
                Buffer = []
            # Find the begin of the next package (if required)
            if (self.AnalyzingBuffer_End > self.AnalyzingBuffer_Position) and (self.PackageStartFound < 0):
                for i in xrange(self.AnalyzingBuffer_Position,self.AnalyzingBuffer_End):
                    # Did we found a new header?
                    if self.AnalyzingBuffer.flat[i] == self.HeaderID:
                        self.AnalyzingBuffer_Position = i
                        self.PackageStartFound = i
                        break
                # We found nothing... And we don't want to check this part again.
                if self.PackageStartFound < 0:
                    self.AnalyzingBuffer_Position = self.AnalyzingBuffer_Position
            # Okay, we somehow found a putative new header:
            # Minimum is: Header, Length, Type, CRC A, CRC B, CRC C and CRC D = 7
            if (self.PackageStartFound >= 0) and (self.PutativePackage == 0) \
              and (self.AnalyzingBuffer_End >= self.AnalyzingBuffer_Position + 7):
                # Check Package Types
                self.PutativePackage = 0
                self.PackageLength = 0
                for i in xrange(0, len(self.AllowedPackages)):
                    if self.AnalyzingBuffer.flat[self.PackageStartFound+2] == self.AllowedPackages[i]:
                        self.PutativePackage = 1
                if self.AnalyzingBuffer.flat[self.PackageStartFound+1] > 4096:
                    self.PutativePackage = 0
                    self.PackageLength = -1
                else:
                    self.PackageLength = (self.AnalyzingBuffer.flat[self.PackageStartFound+1]) >> 1
                # Okay, this was not even close to a correct package
                if self.PutativePackage == 0:
                    self.PackageStartFound = -1
                    self.AnalyzingBuffer_Position = self.AnalyzingBuffer_Position + 1
            # Is there a putative package? If so, do we have all the necessary parts for it?
            if (self.PackageStartFound >= 0) and (self.PackageLength > 0) and (self.PutativePackage == 1) and \
              (self.AnalyzingBuffer_End >= (self.PackageLength + self.AnalyzingBuffer_Position)):
                Buffer = self.AnalyzingBuffer.flat[self.AnalyzingBuffer_Position: \
                  self.AnalyzingBuffer_Position+self.PackageLength]
                self.AnalyzingBuffer_Position = self.AnalyzingBuffer_Position + self.PackageLength
                self.PackageLength = -1
                self.PackageStartFound = -1
                self.PutativePackage = 0
                self.PAnalyzer.Depack(Buffer)
                self.PipeOut.send(self.PAnalyzer)
                Buffer = []
            # Wait...
            #if DidSomething == False:
            #    time.sleep(0.01)
