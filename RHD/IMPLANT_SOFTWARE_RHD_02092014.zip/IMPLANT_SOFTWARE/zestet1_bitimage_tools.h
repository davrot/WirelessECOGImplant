// -------------------------
// ITP - Uni Bremen
// 29.07.2011 
// David Rotermund 
// -------------------------

// Note: This files takes the Orange Tree Files and changes a lot... :-) 
#ifndef include_zarlink_bitimage_tools_h                                                                                     
#define include_zarlink_bitimage_tools_h   

#include "zestet1_network.h"
#include "bitfile_tools.h"

class ZestET1_BitImage_Tools
{
    public: 

	int ConfigureFPGA(char * Servername, int PortNumber , char * Filename);

	int EraseFlash(char * Servername, int PortNumber);

	int WriteFlash(char * Servername, int PortNumber , char * Filename);

    private:
	int Reverse32BitWord(unsigned char * In, unsigned char * Out);
	int DisassembleLong4Byte(unsigned long In , unsigned char * Out, bool Reversed);
	int EraseFlashSector(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading, unsigned long Address);    

	int SPIReadWrite(SOCKET * SocketHandle,fd_set * FD_Writing, long TimeOutInSec_Write, long TimeOutInUSec_Write , 
	    fd_set * FD_Reading, long TimeOutInSec_Read, long TimeOutInUSec_Read, unsigned char Device, 
	    unsigned char WordLen, unsigned char * WriteData, unsigned char * ReadData, long Length , unsigned char ReleaseCS);

	int SPIReadWrite_Blocking(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading, unsigned char Device, 
	    unsigned char WordLen, unsigned char * WriteData, unsigned char * ReadData, long Length , unsigned char ReleaseCS);

	int ConfigureFPGA(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading,BitFile * MyBitFile);
	int EraseFlash(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading);
	int WriteFlash(SOCKET * SocketHandle,fd_set * FD_Writing, fd_set * FD_Reading, void * Buffer, unsigned long Length);

};	

#endif
