#include <stdlib.h>                                                                                                 
#include <iostream>                                                                                                 
#include <stdio.h>                                                                                                  

#include "zestet1_network.h"
#include "adc_tools.h"

int main(int argc, char *argv[])
{
    long long Value_A = 0;
    long long Value_B = 0;

    unsigned long Temp = 0;    
    
    SOCKET SocketHandle;
    fd_set FD_Reading;
    fd_set FD_Writing;
    
    long Counter = 0;

    unsigned char * Output = NULL;
    unsigned long LengthOfCommand = 0;
    unsigned long CommandID = 0;
    unsigned long * Values = NULL;
    long NumberOfValues = 0;

    if (argc != 4)
    {
        std::cout << "Set the debug constants\n";
        std::cout << "1. IP e.g. 192.168.1.100\n";
        std::cout << "2. Number of the debug constant\n";
        std::cout << "3. Value for debug constant\n";
        std::cout << "\n";
        std::cout << "Available Debug Constants:\n";
        std::cout << "1.)  [1Bit]      Zarlink Debug Mode -- The ZestET1 copies the whole communication with the Zarlink into special network packages, which can be found in Zarlink.dat.  Default is 0 = off.\n";
        std::cout << "2.)  [28Bit]     Zarlink Blocktransfer Timeout -- In the case when a block read/write operation was requested it is checked beforehand if the rx or tx buffer state allows that. If this is not the case then the FPGA rechecks until this timeout was reached. Default is 96000000. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "3.)  [48Bit]     Zarlink Connection Timeout -- Length of time until the initialisation of a RF connection between two Zarlinks is aborted. Default is 28800000000. (measured in cycles of a 95.8333MHz clock; Default 5 min.) \n";
        std::cout << "4.)  [28Bit]     Wait for Zarlink Reset -- Length of time after reseting the Zarlink where the state machine does not communicate with the Zarlink and waits. Default is 48000000. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "5.)  [8Bit]      Implant Device ID -- Is used during the communication between the FPGA and the ASIC. Default is 53.\n";
        std::cout << "6.)  [32Bit]     Zarlink Check RX Buffer -- Length of time between two checks if data arrived from the ASIC. Default is 84000. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "7.)  [19Bit]     Zarlink Clean Up Counter -- Length of time between sending a stop signal to the ASIC and cleaning the rx buffer of the basestation Zarlink. Default is 250000. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "8.)  [1Bit]      ASIC Test Packet Generator -- Enables the ZestET1 to produce Test-Packets in the style of the ASIC.  Default is 0 = off.\n";
        std::cout << "9.)  [1Bit]      ASIC Test Packet Zarlink Export -- Redirects the generated test packtes to the Zarlink RF connection.  Default is 0 = off.\n";
        std::cout << "10.) [1Bit]      Zarlink Implant Mode -- Configures the basestation for connecting as a implant.  Default is 0 = Basestation. \n";
        std::cout << "11.) [19Bit]     Zarlink Retry Buffer Check timing for normal block transfers -- Time between re-checking the rx/tx buffer usage for normal block transfers to / from the Zarlink.. Default is 22000. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "12.) [8Bit]      Zarlink SPI cooldown time -- Enforces that for this time there can be no new SPI Zarlink  operation. Default is 30. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "13.) [1Bit]      ASIC data dump mode -- instead of processing the data from the ASIC it is directly dumped on the network plus some extra information about the actual basestation setting. Default is 0 = off.\n";
        std::cout << "14.) [4Bit]      Zarlink FSK Mode setting for the connection -- Setting for the reg_mac_moduser operations.(Default is 4fsk tx/rx = bin1111)\n";
        std::cout << "15.) [1Bit]      Zarlink Link Quality check -- If enabled and the Zarlink Debug mode is enabled too, then everytime the status of the rx/tx buffer is checked also a set of link quality parameters are read out. Default is 0 = off.\n";
        std::cout << "16.) [32Bit]     ASIC Test Packet Generator Zarlink Export timing -- If the tx buffer is full then this time is waited until the tx buffer status is re-checked. Default is 300000. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "17.) [30Bit]     ASIC Test Packet Generator timing-- sets how long 1/10 ms is. Default is 9583. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "18.) [8Bit]      Number of packages which can be written into the tx buffer until the tx buffer usage state is checked again. Default is 60.\n";
        std::cout << "19.) [17Bit]     Length of Trigger Out Clock --  Length of one bit transmitted to the d-flip flops on the extra card. Default is n=100 ~ 500KHz (95.833MHz/((n+1)*2))\n";
        std::cout << "20.) [17Bit]     Length of time between to samples of the trigger-in channels are taken -- Default is 200. (measured in cycles of a 95.8333MHz clock)\n";
        std::cout << "21.) [8Bit]      Length of Zarlink SPI Clock --95.833MHz/((n+3)*2) 10 ~ 3.8MHz, 30 = 1.49MHz Default is 1.49MHz.\n";
        std::cout << "22.) [2Bit]      Zarlink SPI Speed register setting -- 0 = 1 MHz, 1 = 2MHz and 3 = 4MHz. Default is 1.\n";
	return 0;
    }
                                                        
    Value_A = atol(argv[2]);	
    Value_B = atol(argv[3]);	
    Output = NULL;

        
	CommandID = 0x00FF;
	Values = NULL;
	Values = new unsigned long[20];
	Values[0] = Value_A; 
	Values[1] = Value_B;
	Values[2] = (Value_B>>16);
	Values[3] = (Value_B>>32);
	NumberOfValues	= 4;

	// 2x Packet ID, 2x Length of Packet, 2x Command ID, 8x CRC and 2 * Number of Values 
	LengthOfCommand = 2+2+2+8+(2*NumberOfValues);

	Output = NULL;
        Output = new unsigned char [LengthOfCommand];
        if (Output == NULL)
        {
	    std::cout << "Couldn't calculate command output array.\n";	    
	    return 0;
        }
        
	if (Firmware_Command(Output, LengthOfCommand,  CommandID, Values, NumberOfValues) == -1)
	{
	    std::cout << "Couldn't calculate command packet.\n";	    
	    return 0;
	}

        if( MakeNetworkConnection(&SocketHandle, (char*) argv[1], 0x5002, &FD_Reading , &FD_Writing) == -1)
        {
    	    std::cout << "Network connection couldn't be established.\n";
    	    return 0;
        }

	Firmware_SendCommand(&SocketHandle, Output, LengthOfCommand , &FD_Writing, 0, 0);
	//usleep(2000*1000);
	Firmware_ReadData(&SocketHandle, &FD_Reading, 1, 0, false,CommandID);


	if (CloseNetworkConnection(&SocketHandle) == -1)
	{
    	    std::cout << "Network connection couldn't be closed.\n";
    	    return 0;
	}

	if (Output != NULL)
	{
	    delete Output;
	}
	Output = NULL;

	if (Values != NULL)
	{
	    delete Values;
	}
	Values = NULL;
	
    
    std::cout << "-==- Done -==-\n";
           

//----------------------    
    return 0;
};
