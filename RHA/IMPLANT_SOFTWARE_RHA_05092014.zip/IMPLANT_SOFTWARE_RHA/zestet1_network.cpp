// -------------------------
// ITP - Uni Bremen
// 29.07.2011 
// David Rotermund 
// -------------------------

#ifdef __unix__  
#include <stdlib.h>
#include <sys/types.h>  
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/select.h>
#include <stdio.h>
#include <iostream>
#include <string.h>
#endif

#ifdef _WIN32
#pragma comment(lib, "wsock32.lib")

#include <stdio.h>
#include <iostream>
#include <string.h>
#include <tchar.h>  
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h> 
#endif

#include "zestet1_network.h"
//#include "console_tools.h"

#ifdef __unix__    
int MakeNetworkConnection (int * SocketHandle, char * Servername, int PortNumber , fd_set * FD_Reading , fd_set * FD_Writing)
{
    // Server Info
    struct hostent * server_info;
    struct sockaddr_in server_address;

    // Flags of the Socket Handle
    long SocketHandleFlag = 0;

    // Check server name for NULL
    if (Servername == NULL)
    {
        std::cout << "MakeNetworkConnection_Linux - Servername array is NULL...\n";
        return -1;
    }

    // Check SocketHandle for NULL
    if (SocketHandle == NULL)
    {
        std::cout << "MakeNetworkConnection_Linux - SocketHandle is NULL...\n";
        return -1;
    }

    // Create a socket     
    *SocketHandle = socket(AF_INET, SOCK_STREAM, 0);

    // Check the socket     
    if (*SocketHandle < 0) 
    {
        std::cout << "MakeNetworkConnection_Linux - Can not create socket...\n";
        return -1;
    }
    
    // Get the server IP info
    server_info = gethostbyname(Servername);

    if (server_info == NULL)
    {
        std::cout << "MakeNetworkConnection_Linux - Can not process the server name and get the IP adress.\n";
        return -1;
    }

    // Make a clean address structure
    bzero((char *) &server_address, sizeof(server_address));
    // The the values in the address structure 
    server_address.sin_family = AF_INET;
    bcopy((char *)server_info->h_addr,(char *)&server_address.sin_addr.s_addr,server_info->h_length);
    server_address.sin_port = htons(PortNumber);
            
    // Make the connection 
    if (connect(*SocketHandle,(struct sockaddr*)&server_address,sizeof(server_address)) < 0)
    {
        std::cout << "MakeNetworkConnection_Linux - Can not connect to the server.\n";
        return -1;
    }

    // Prepare polling
    if (FD_Reading != NULL)
    {
	FD_ZERO(FD_Reading);       
	FD_SET(*SocketHandle,FD_Reading);       	
     }

    if (FD_Writing != NULL)
    {
	FD_ZERO(FD_Writing);       
	FD_SET(*SocketHandle,FD_Writing);       	
     }

    return 0;
};

int CloseNetworkConnection(int * SocketHandle)
{

    // Check SocketHandle for NULL
    if (SocketHandle == NULL)
    {
        std::cout << "CloseNetworkConnection_Linux - SocketHandle is NULL...\n";
        return -1;
    }

    // Clean the network
    shutdown(*SocketHandle,2);

    return 0;
};

#elif defined _WIN32

int MakeNetworkConnection(SOCKET * SocketHandle, char * Servername, int PortNumber, fd_set * FD_Reading , fd_set * FD_Writing)
{

    // Server Info
    struct hostent * server_info;
    struct sockaddr_in server_address;
    
    // Flags of the Socket Handle
    long SocketHandleFlag = 0;
    
    // For the Winsocket Windows Network Stack Initialization
    WSADATA wsaData = {0};
    int wsaResult = 0;
    
    // Check server name for NULL
    if (Servername == NULL)
    {
        std::cout << "MakeNetworkConnection_Windows - Servername array is NULL...\n";
        return -1;
    }

    // Check SocketHandle for NULL
    if (SocketHandle == NULL)
    {
        std::cout << "MakeNetworkConnection_Windows - SocketHandle is NULL...\n";
        return -1;
    }

    // Init WinSocket 
    wsaResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (wsaResult != 0)
    {
        std::cout << "MakeNetworkConnection_Windows - WinSocket couldn't be created...\n";
        return -1;
    }

    // Create a socket     
    *SocketHandle = INVALID_SOCKET;
    *SocketHandle = socket(AF_INET, SOCK_STREAM, 0);

    // Check the socket     
    if (*SocketHandle == INVALID_SOCKET) 
    {
        std::cout << "MakeNetworkConnection_Windows - Can not create socket...\n";
        WSACleanup();
        return -1;
    }
    
    // Get the server IP info
    server_info = gethostbyname(Servername);

    if (server_info == NULL)
    {
        std::cout << "MakeNetworkConnection_Windows - Can not process the server name and get the IP adress.\n";
        WSACleanup();
        return -1;
    }

    // Make a clean address structure
    memset((char *) &server_address, 0 ,sizeof(server_address));

    // The the values in the address structure 
    server_address.sin_family = AF_INET;

    memcpy((char *)&server_address.sin_addr.s_addr,(char *)server_info->h_addr,server_info->h_length);
    server_address.sin_port = htons(PortNumber);
            
    // Make the connection 
    if (connect(*SocketHandle,(struct sockaddr*)&server_address,sizeof(server_address)) == SOCKET_ERROR)
    {
        std::cout << "MakeNetworkConnection_Windows - Can not connect to the server.\n";
        closesocket(*SocketHandle);
        WSACleanup();
        return -1;
    }

    // Prepare polling
    if (FD_Reading != NULL)
    {
	FD_ZERO(FD_Reading);       
	FD_SET(*SocketHandle,FD_Reading);       	
     }

    if (FD_Writing != NULL)
    {
	FD_ZERO(FD_Writing);       
	FD_SET(*SocketHandle,FD_Writing);       	
     }

    return 0;
};

int CloseNetworkConnection(SOCKET * SocketHandle)
{

    // Check SocketHandle for NULL
    if (SocketHandle == NULL)
    {
        std::cout << "CloseNetworkConnection_Windows - SocketHandle is NULL...\n";
        return -1;
    }

    // Clean the network stack
    shutdown(*SocketHandle,2);
    closesocket(*SocketHandle);
    WSACleanup();

    return 0;
};

#endif

#ifdef __unix__    
int ZestET1_CleanNetworkBuffer (int * SocketHandle, fd_set * FD_Reading )
#endif

#ifdef _WIN32
int ZestET1_CleanNetworkBuffer (SOCKET * SocketHandle, fd_set * FD_Reading )
#endif
{
    struct timeval TimeOut_Read;
    TimeOut_Read.tv_sec = 1;
    TimeOut_Read.tv_usec = 0;
    
    int ReturnValueForSelect = 0;
    
    long NumberOfReadByte = 0;
#ifdef _WIN32
	u_long NBMode = 0;
#endif
    char * Buffer = NULL;
    int ReadLength = 0;
    
    int SpecialKey = -1;
    
    unsigned long Count = 0;
    
    if (SocketHandle == NULL)
    {
	std::cout << "ZestET1_CleanNetworkBuffer - SocketHandle is NULL.\n";
	return -1;
    }
    
    if (FD_Reading == NULL)
    {
	std::cout << "ZestET1_CleanNetworkBuffer - FD_Reading is NULL.\n";
	return -1;
    }

    Buffer = new char[5000];
    if (Buffer == NULL)
    {	
	std::cout << "ZestET1_CleanNetworkBuffer -Can not create buffer.\n";
	return -1;
    }
    ReadLength = 5000;    
    
//    Console_Set_NonBlocking_KeyPressMode(true);
    
    // Loop of infinite everything...
    while(SpecialKey == -1)
    {
//	SpecialKey = Console_Get_NonBlocking_KeyPress();	
/*
	Console_Cursor_GotoXY(0,0);
	Console_Refresh();
	Console_Cursor_GotoXY(0,21);
	Console_Refresh();
	printf("Press any key to cancel");
	Console_Refresh();
	
	Console_Cursor_GotoXY(0,0);
	Console_Refresh();
	Console_Cursor_GotoXY(0,21);
	Console_Refresh();
	std::cout << "Cleaning network cache : " << Count << " bytes trashed...";
	Console_Refresh();
*/
#ifdef __unix__   
	NumberOfReadByte = recv(*SocketHandle,Buffer,ReadLength,MSG_DONTWAIT);
#endif

#ifdef _WIN32
	NBMode = 1;
	ioctlsocket(*SocketHandle,FIONBIO,&NBMode);
	NumberOfReadByte = recv(*SocketHandle,Buffer,ReadLength,0);
	NBMode = 0;
	ioctlsocket(*SocketHandle,FIONBIO,&NBMode);
#endif

	if (NumberOfReadByte == -1)
	{
	    if (Buffer != NULL)
	    {
	        delete Buffer;
	    }
	    Buffer = NULL;
	    //Console_Set_NonBlocking_KeyPressMode(false);
	    return 0;
    	}
    	else
    	{
    	    Count += NumberOfReadByte;
    	}
    }

    //Console_Set_NonBlocking_KeyPressMode(false);
    
    if (Buffer != NULL)
    {
	delete Buffer;
    }
    Buffer = NULL;
    
    return 0;
};
