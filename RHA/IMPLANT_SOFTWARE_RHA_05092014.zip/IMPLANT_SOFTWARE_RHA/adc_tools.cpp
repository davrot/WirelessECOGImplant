// -------------------------
// ITP - Uni Bremen
// 07.08.2011 
// David Rotermund 
// -------------------------

#ifdef __unix__  
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/select.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <sys/types.h>  
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>

#define SOCKET int
#endif

#ifdef _WIN32
#pragma comment(lib, "wsock32.lib")

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <tchar.h>  
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h> 
#endif

#include "zestet1_network.h"
#include "adc_tools.h"

#ifdef ProgramBeVerbose
#endif 


unsigned long Firmware_Command_CRC_Byte(unsigned char * Output, unsigned long LengthOfCommand, unsigned char CRC_Value)
{
    unsigned long Result = 0;
    
    unsigned long Counter = 0;
    
    unsigned char Temp = 0;

    
    if (Output == NULL)
    {
	std::cout << "Error - Firmware_Command_CRC_Byte - Output is NULL\n";
	return 0;
    }

    if (LengthOfCommand == 0)
    {
	std::cout << "Error - Firmware_Command_CRC_Byte - LengthOfCommand is 0\n";
	return 0;
    }


    if (CRC_Value > 3)
    {
	std::cout << "Error - Firmware_Command_CRC_Byte - CRC Value too large\n";
	return 0;
    }

    for (Counter = 0 ; Counter < LengthOfCommand; Counter ++)
    {
	Temp = Output[Counter];
	
	if (((Temp >> 0) & 3) == CRC_Value)
	{
	    Result ++;
	}

	if (((Temp >> 2) & 3) == CRC_Value)
	{
	    Result ++;
	}

	if (((Temp >> 4) & 3) == CRC_Value)
	{
	    Result ++;
	}

	if (((Temp >> 6) & 3) == CRC_Value)
	{
	    Result ++;
	}
    }    

    return Result;
}

int Firmware_Command (unsigned char * Output, unsigned long LengthOfCommand,  unsigned long CommandID, unsigned long * Values, long NumberOfValues)
{
    unsigned int * TempLong = NULL;
    unsigned char TempUC = 0;

    long Counter = 0;

    if (Output == NULL)
    {
	std::cout << "Error - Firmware_Command - Output is NULL\n";
	return -1;
    }

    if (LengthOfCommand < 12)
    {
	std::cout << "Error - Firmware_Command - LengthOfCommand is NULL\n";
	return -1;
    }

    if (Values == NULL)
    {
	std::cout << "Error - Firmware_Command - Values is NULL\n";
	return -1;
    }

    // 2x Packet ID, 2x Length of Packet, 2x Command ID, 8x CRC and 2 * Number of Values 

    TempLong = (unsigned int *) Output;
    TempLong[0] = 0x55AA;
    TempLong = (unsigned int *) (Output+2);    
    TempLong[0] = LengthOfCommand;
    TempLong = (unsigned int *) (Output+4);
    TempLong[0] = CommandID;

    for (Counter = 0; Counter < NumberOfValues; Counter ++ )
    {
        TempLong = (unsigned int *) (Output+6+Counter*2);    
	TempLong[0] = Values[Counter];
    }

    TempLong = (unsigned int *) (Output+2*(1+1+1+NumberOfValues+0));    
    TempLong[0] = Firmware_Command_CRC_Byte(Output, LengthOfCommand-8, 0);
    TempLong = (unsigned int *) (Output+2*(1+1+1+NumberOfValues+1));    
    TempLong[0] = Firmware_Command_CRC_Byte(Output, LengthOfCommand-8, 1);
    TempLong = (unsigned int *) (Output+2*(1+1+1+NumberOfValues+2));    
    TempLong[0] = Firmware_Command_CRC_Byte(Output, LengthOfCommand-8, 2);
    TempLong = (unsigned int *) (Output+2*(1+1+1+NumberOfValues+3));    
    TempLong[0] = Firmware_Command_CRC_Byte(Output, LengthOfCommand-8, 3);

    for (Counter = 0; Counter < LengthOfCommand; Counter += 2 )
    {
	TempUC = Output[Counter];
	Output[Counter] = Output[Counter+1];	
	Output[Counter+1] = TempUC;
    }
  
    return 0;
};

int Firmware_SendCommand(SOCKET * SocketHandle, unsigned char * CommandArray, unsigned long LengthOfCommand , fd_set * FD_Writing, long TimeOutInSec_Write, long TimeOutInUSec_Write)
{

    struct timeval TimeOut_Write;

    int ReturnValueForSelect = -1;

    if (LengthOfCommand == 0)
    {
	std::cout << "Firmware_SendCommand - Length of the Command is 0\n";   
	return -1;
    }

    if (CommandArray == NULL)
    {
	std::cout << "Firmware_SendCommand - Command Array is NULL\n";   
	return -1;
    }
    
    // Check the pointer for SocketHandle
    if (SocketHandle == NULL)
    {
	std::cout << "Firmware_SendCommand  - SocketHandle is NULL\n";   
	return -1;
    }
    
    // Check the pointer for FD_Writing    
    if (FD_Writing == NULL)
    {
	std::cout << "Firmware_SendCommand  - FD_Writing is NULL\n";   
	return -1;    
    }
    
    // Fill the structure for the time out
    if (TimeOutInSec_Write > 0)
    {
	TimeOut_Write.tv_sec = TimeOutInSec_Write;
    }
    else
    {
	TimeOut_Write.tv_sec = 0;
    }

    if (TimeOutInUSec_Write > 0)
    {
	TimeOut_Write.tv_usec = TimeOutInUSec_Write;
    }
    else
    {
	TimeOut_Write.tv_usec = 0;
    }
    

    // Wait until we can write and use a time out if demanded 
    if ((TimeOutInUSec_Write > 0) || (TimeOutInSec_Write > 0))
    {
	ReturnValueForSelect = select(*SocketHandle+1, NULL, FD_Writing, NULL, &TimeOut_Write);
    }
    else
    {
	ReturnValueForSelect = select(*SocketHandle+1, NULL, FD_Writing, NULL, NULL);    
    }
    
    if (ReturnValueForSelect == -1)
    {
	std::cout << "Firmware_SendCommand - Could not use select correctly\n ";
	return -1;
    } 

    if (send(*SocketHandle,(char *)CommandArray,LengthOfCommand,0) == -1)
    {
	std::cout << "Firmware_SendCommand - Could not use send correctly\n ";
	return -1;
    } 

    return 0;
};

  
int Firmware_ReadData(SOCKET * SocketHandle, fd_set * FD_Reading, long TimeOutInSec_Read, long TimeOutInUSec_Read, bool AppendIt, unsigned long PacketID, unsigned long long MaxNumberOfSamples )
{
    int ErrorValueForWriting = -1;
    int ReturnValueForSelect = -1;

    unsigned char * Buffer = 0;
    unsigned long BufferMax = 500000;
    
    long NumberOfReadByte = -1;
    long Counter = 0;
    unsigned long Temp_Reconstruct;
    unsigned char Temp_UC;
//    unsigned long long NumberOfCollectedSamples = 0;
    int LastValue = 0;
    
    long LastMode = 0;
    long PacketSize = 0;
    long ZeroPacketCounter = 0;

    unsigned long long NumberOfSamples = 0;
    
#ifdef _WIN32
    u_long NBMode = 0;
#endif
         
    struct timeval TimeOut_Read;
    FILE * OutputStream_Basisstation = NULL;
    FILE * OutputStream_ASICData = NULL;
    FILE * OutputStream_Zarlink = NULL;
    FILE * OutputStream_ADCData = NULL;
    
    bool DisableCounter = true;


    if (AppendIt == true)
    {
	OutputStream_Basisstation = fopen("Basisstation.dat","a");
	OutputStream_ASICData = fopen("ASICData.dat","a");
	OutputStream_Zarlink = fopen("Zarlink.dat","a");
	OutputStream_ADCData = fopen("ADCData.dat","a");
    }
    else
    {
	OutputStream_Basisstation = fopen("Basisstation.dat","w");    
	OutputStream_ASICData = fopen("ASICData.dat","w");    
	OutputStream_Zarlink = fopen("Zarlink.dat","w");
	OutputStream_ADCData = fopen("ADCData.dat","w");
    }
    
    
    if ((OutputStream_Basisstation == NULL) || (OutputStream_ASICData == NULL) || (OutputStream_Zarlink == NULL) || (OutputStream_ADCData == NULL))
    {
	std::cout << "Firmware_ReadData - OutputStream is NULL\n";   
	return -1;
    }
    
    // Check the pointer for the output value
    Buffer = new unsigned char [BufferMax];
    if (Buffer == NULL)
    {
	std::cout << "Firmware_ReadData - Buffer is NULL\n";   
	return -1;
    }
     // Check the pointer for SocketHandle
    if (SocketHandle == NULL)
    {
	std::cout << "Firmware_ReadData - SocketHandle is NULL\n";   
	return -1;
    }

    // Check the pointer for FD_Reading    
    if (FD_Reading == NULL)
    {
	std::cout << "Firmware_ReadData - FD_Reading is NULL\n";   
	return -1;    
    }

    // Fill the structure for the time out
    if (TimeOutInSec_Read > 0)
    {
	TimeOut_Read.tv_sec = TimeOutInSec_Read;
    }
    else
    {
	TimeOut_Read.tv_sec = 0;
    }

    if (TimeOutInUSec_Read > 0)
    {
	TimeOut_Read.tv_usec = TimeOutInUSec_Read;
    }
    else
    {
	TimeOut_Read.tv_usec = 0;
    }

    // Wait until we can read and use a time out if demanded 
    if ((TimeOutInUSec_Read > 0) || (TimeOutInSec_Read > 0))
    {
	ReturnValueForSelect = select(*SocketHandle+1, FD_Reading, NULL, NULL, &TimeOut_Read);
    }
    else
    {
	ReturnValueForSelect = select(*SocketHandle+1, FD_Reading, NULL, NULL, NULL);    
    }
    
    if (ReturnValueForSelect == -1)
    {
	std::cout << "Firmware_ReadData - Could not use select correctly\n ";
	return -1;
    }
         
    do 
    {

	// Read the data
#ifdef __unix__
	NumberOfReadByte = recv(*SocketHandle,(char *)Buffer,BufferMax,MSG_DONTWAIT);
#endif

#ifdef _WIN32
        NBMode = 1;
        ioctlsocket(*SocketHandle,FIONBIO,&NBMode);
        NumberOfReadByte = recv(*SocketHandle,(char *)Buffer,BufferMax,0);
        NBMode = 0;
        ioctlsocket(*SocketHandle,FIONBIO,&NBMode);
#endif

	if (NumberOfReadByte > 0)
	{
	    if( AnalysePacket((unsigned char *) Buffer, NumberOfReadByte, &LastMode, &PacketSize, 
		    OutputStream_Basisstation,OutputStream_ASICData,OutputStream_Zarlink,OutputStream_ADCData, PacketID, &LastValue, &NumberOfSamples ) < 0)
	    {
		std::cout << "Problem analysing data... \n ";	
	    }
        }

	if (NumberOfReadByte > 0)
	{
	    ZeroPacketCounter = 0;
	}
	else
	{	
	    ZeroPacketCounter++ ;

        
	    #ifdef __unix__
		usleep(1000);
	    #endif

	    #ifdef _WIN32
		Sleep(1);
	    #endif

	}	

    if ((NumberOfSamples >= MaxNumberOfSamples) && (MaxNumberOfSamples > 0))
    {
	ZeroPacketCounter = 1000000;
    }


    }while(ZeroPacketCounter < 500);

    fclose(OutputStream_Basisstation);
    fclose(OutputStream_ASICData);
    fclose(OutputStream_Zarlink);
    fclose(OutputStream_ADCData);
    	    
    if (Buffer != NULL)
    {
	delete Buffer;
    }
    Buffer = NULL;


//    std::cout << NumberOfSamples << " " <<  MaxNumberOfSamples << "\n";   
    
    return 0;
};

int AnalysePacket(unsigned char * DataArray, unsigned long Length, long * LastMode, long * PacketSize, 
		    FILE * OutputStream_Basestation, FILE * OutputStream_ASICData, FILE * OutputStream_Zarlink, FILE * OutputStream_ADCData, unsigned long PacketID,
		    int * LastValue, unsigned long long * NumberOfSamples )
{
    unsigned long Position = 0;
    bool DoSomething = true;
    unsigned char * LP = (unsigned char *)LastValue;
    
    // Nothing to do?     
    if (Length == 0)
    {
	return -3;
    }

    // Even number of bytes? 
    if ( ((unsigned long)(Length/2))*2 != Length)
    {
	return -1;
    }

    if (DataArray == NULL)
    {
	return -2;
    }
    
    if (LastMode == NULL)
    {
	return -4;
    }

    if (LastValue == NULL)
    {
	return -5;
    }

    if (NumberOfSamples == NULL)
    {
	return -6;
    }


    Position = 0;
    
    while (Position < Length)
    {
	
	if ((Position+2) > Length)
	{
	    return 0;
	}
	
	DoSomething = true;

    // std::cout << (unsigned int)DataArray[Position] << " " << (unsigned int)DataArray[Position+1] << "|";

	// New packet starts 
	if ( (DataArray[Position] == 85) && (DataArray[Position+1] == 170) && (*LastMode == 0) && (DoSomething == true))
	{
	    *LastMode = 1;
	    DoSomething = false;
	}

	if ( (*LastMode == 1) && (DoSomething == true))
	{
	    *LastMode = 2;
	    DoSomething = false;
	    *PacketSize = DataArray[Position] * 256 + DataArray[Position+1] - 4;
	}

	// 8000 Packets 
	if ( (DataArray[Position] == 128) && (DataArray[Position+1] == 0) && (*LastMode == 2) && (DoSomething == true))
	{
	    *LastMode = 300;
	    DoSomething = false;
	    *PacketSize -= 2;
	}


	
	// Cont. 8000 (Packet ID)
	if ( (*LastMode == 300) && (DoSomething == true))	
	{
	    if (PacketID == (DataArray[Position] * 256 + DataArray[Position+1]) )
	    {
		*LastMode = 301;
	    }
	    else
	    {
		*LastMode = 700;	    
	    }
	    DoSomething = false;
	    *PacketSize -= 2;
	}

	// Cont. 8000 (Error Flag)
	if ( (*LastMode == 301) && (DoSomething == true))	
	{
	    *PacketSize -= 2;
	    if ( ((DataArray[Position] * 256 + DataArray[Position+1]) == 0) && (*PacketSize >= 4) )
	    {    
		std::cout << "Command: okay " << "\n";	
		if (*PacketSize > 8)
		{
		    *LastMode = 302;		
		}
		else
		{
		    *LastMode = 700;		
		}
	    }
	    else
	    {
		std::cout << "Command: failed ( " << (DataArray[Position] * 256 + DataArray[Position+1]) <<  " )" << "\n";		    
		*LastMode = 700;
	    }
	    DoSomething = false;	    
	}

	// Cont. 8000 (DataArray)	
	if ( (*LastMode == 302) && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 8)
	    {
		//*LastMode = 302;			    
		fprintf(OutputStream_Basestation,"%lu ", (DataArray[Position] * 256 + DataArray[Position+1]));
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    if (*PacketSize == 10)
	    {
		fprintf(OutputStream_Basestation,"\n");	    
	    }

	    DoSomething = false;	    
	    *PacketSize -= 2;
	}

	// 8001 Packets 
	if ( (DataArray[Position] == 128) && (DataArray[Position+1] == 1) && (*LastMode == 2) && (DoSomething == true))
	{
	    *LastMode = 400;
	    DoSomething = false;
	    *PacketSize -= 2;
	    
	    //std::cout << "+\n";
	}

	// Cont. 8001 (Data)	
	if ( (*LastMode == 400) && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 8)
	    {
		//*LastMode = 400;			    
		fprintf(OutputStream_ASICData,"%lu ", (DataArray[Position] * 256 + DataArray[Position+1]));
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    if (*PacketSize == 10)
	    {
		fprintf(OutputStream_ASICData,"\n");
		*NumberOfSamples += 1;	    
	    }

	    DoSomething = false;	    
	    *PacketSize -= 2;
	}

	// 8002 Packets 
	if ( (DataArray[Position] == 128) && (DataArray[Position+1] == 2) && (*LastMode == 2) && (DoSomething == true))
	{
	    *LastMode = 500;
	    DoSomething = false;
	    *PacketSize -= 2;
	}

	// Cont. 8002 (Data)	
	if ( (*LastMode >= 500) && (*LastMode <= 503)  && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 8)
	    {
		*LastMode += 1;			    
		fprintf(OutputStream_Zarlink,"%lu ", DataArray[Position] * 256 +  DataArray[Position+1]);
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    if (*PacketSize == 10)
	    {
		fprintf(OutputStream_Zarlink,"\n");	    
	    }

	    DoSomething = false;	    
	    *PacketSize -= 2;
	}

	// Cont. 8002 (Data)	
	if ( (*LastMode == 504) && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 8)
	    {
		//*LastMode = 500;			    
		fprintf(OutputStream_Zarlink,"%lu %lu ", DataArray[Position] , DataArray[Position+1]);
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    if (*PacketSize == 10)
	    {
		fprintf(OutputStream_Zarlink,"\n");	    
	    }

	    DoSomething = false;	    
	    *PacketSize -= 2;
	}


	// 8003 Packets 
	if ( (DataArray[Position] == 128) && (DataArray[Position+1] == 3) && (*LastMode == 2) && (DoSomething == true))
	{
	    *LastMode = 600;
	    DoSomething = false;
	    *PacketSize -= 2;
	}

	// 8003 Packets (TimeStamp) 
	if ( (*LastMode == 600) && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 8)
	    {
		*LastMode = 601;			    
		fprintf(OutputStream_ADCData,"%lu ", (DataArray[Position] * 256 + DataArray[Position+1]));
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    if (*PacketSize == 10)
	    {
		fprintf(OutputStream_ADCData,"\n");	    
	    }

	    DoSomething = false;	    
	    *PacketSize -= 2;
	}

	// 8003 Packets (Trigger) 
	if ( (*LastMode == 601) && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 8)
	    {
		*LastMode = 602;			    
		fprintf(OutputStream_ADCData,"%lu ", (DataArray[Position] * 256 + DataArray[Position+1]));
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    if (*PacketSize == 10)
	    {
		fprintf(OutputStream_ADCData,"\n");	    
	    }

	    DoSomething = false;	    
	    *PacketSize -= 2;
	}


	// Cont. 8003 (Data)	
	if ( (*LastMode == 602) && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 10)
	    {
		*LastMode = 603;
		LP[3] = (unsigned char)DataArray[Position];
		LP[2] = (unsigned char)DataArray[Position+1];
		
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    DoSomething = false;	    
	    *PacketSize -= 2;
	}

	if ( (*LastMode == 603) && (DoSomething == true))	
	{
	    
	    if (*PacketSize > 10)
	    {
		*LastMode = 602;			    
		LP[1] = (unsigned char)DataArray[Position];
		LP[0] = (unsigned char)DataArray[Position+1];

		fprintf(OutputStream_ADCData,"%li ", (long)(*LastValue));
	    }
	    else
	    {
		*LastMode = 700;			    
	    }
	    
	    if (*PacketSize == 12)
	    {
		fprintf(OutputStream_ADCData,"\n");	    
		*NumberOfSamples += 1;
	    }

	    DoSomething = false;	    
	    *PacketSize -= 2;
	}


       	// Unkown Packet 
    	if ( (*LastMode == 2) && (DoSomething == true))
	{
	    *LastMode = 700;
	    DoSomething = false;
	    *PacketSize -= 2;
    	}

	// Cont. Unkown
	if ( (*LastMode == 700) && (DoSomething == true))	
	{
	    DoSomething = false;	    
	    *PacketSize -= 2;
            if (*PacketSize == 0)
            {
		*LastMode = 0;
            }
	}

	Position += 2;
    }

    return 0;
};




