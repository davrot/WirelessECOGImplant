#include <stdlib.h>                                                                                                 
#include <iostream>                                                                                                 
#include <stdio.h>                                                                                                  

#include "zestet1_network.h"
#include "adc_tools.h"

int main(int argc, char *argv[])
{
    long long Value_A = 0;
    long long Value_B = 0;

    unsigned long Temp = 0;    
    
    SOCKET SocketHandle;
    fd_set FD_Reading;
    fd_set FD_Writing;
    
    long Counter = 0;

    unsigned char * Output = NULL;
    unsigned long LengthOfCommand = 0;
    unsigned long CommandID = 0;
    unsigned long * Values = NULL;
    long NumberOfValues = 0;

    if (argc != 4)
    {
	std::cout << "Setting the amplification value for the adc's\n";
	std::cout << "1. IP e.g. 192.168.1.100\n";
	std::cout << "2. Number of the amplifier e.g. 0\n";
	std::cout << "3. Value for the amplification. 0-255 \n";
	return 0;
    }
    
    Value_A = atol(argv[2]);	
    Value_B = atol(argv[3]);	
    Output = NULL;

        
	CommandID = 0x279;
	Values = NULL;
	Values = new unsigned long[20];
	Values[0] = Value_A;
	Values[1] = Value_B;
	NumberOfValues	= 2;

	// 2x Packet ID, 2x Length of Packet, 2x Command ID, 8x CRC and 2 * Number of Values 
	LengthOfCommand = 2+2+2+8+(2*NumberOfValues);

	Output = NULL;
        Output = new unsigned char [LengthOfCommand];
        if (Output == NULL)
        {
	    std::cout << "Couldn't calculate command output array.\n";	    
	    return 0;
        }
        
	if (Firmware_Command(Output, LengthOfCommand,  CommandID, Values, NumberOfValues) == -1)
	{
	    std::cout << "Couldn't calculate command packet.\n";	    
	    return 0;
	}

        if( MakeNetworkConnection(&SocketHandle, (char*) argv[1], 0x5002, &FD_Reading , &FD_Writing) == -1)
        {
    	    std::cout << "Network connection couldn't be established.\n";
    	    return 0;
        }

	Firmware_SendCommand(&SocketHandle, Output, LengthOfCommand , &FD_Writing, 0, 0);
	//usleep(2000*1000);
	Firmware_ReadData(&SocketHandle, &FD_Reading, 1, 0, false,CommandID);


	if (CloseNetworkConnection(&SocketHandle) == -1)
	{
    	    std::cout << "Network connection couldn't be closed.\n";
    	    return 0;
	}

	if (Output != NULL)
	{
	    delete Output;
	}
	Output = NULL;

	if (Values != NULL)
	{
	    delete Values;
	}
	Values = NULL;
	
    
    std::cout << "-==- Done -==-\n";
           

//----------------------    
    return 0;
};
