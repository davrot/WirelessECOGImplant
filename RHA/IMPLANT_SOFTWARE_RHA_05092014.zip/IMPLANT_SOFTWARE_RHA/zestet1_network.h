// -------------------------
// ITP - Uni Bremen
// 29.07.2011 
// David Rotermund 
// -------------------------

#ifndef include_zestet1_network_h
#define include_zestet1_network_h

#ifdef __unix__  
#include <stdlib.h>
#include <sys/types.h>  
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/select.h>
#include <stdio.h>
#include <iostream>
#include <string.h>

#define SOCKET int

#endif

#ifdef _WIN32
//#pragma comment(lib, "wsock32.lib")

//#include <stdio.h>
//#include <iostream>
//#include <string.h>
//#include <tchar.h>  
//#include <winsock2.h>
//#include <ws2tcpip.h>
//#include <stdlib.h> 
#endif

#ifdef __unix__    

int MakeNetworkConnection (int * SocketHandle, char * Servername, int PortNumber , fd_set * FD_Reading , fd_set * FD_Writing);
int CloseNetworkConnection(int * SocketHandle);
int ZestET1_CleanNetworkBuffer (int * SocketHandle, fd_set * FD_Reading);

#elif defined _WIN32

#ifndef winsock2_def
#define winsock2_def
#include <winsock2.h>
#endif

int MakeNetworkConnection(SOCKET * SocketHandle, char * Servername, int PortNumber, fd_set * FD_Reading , fd_set * FD_Writing);
int CloseNetworkConnection(SOCKET * SocketHandle);
int ZestET1_CleanNetworkBuffer (SOCKET * SocketHandle, fd_set * FD_Reading);
#endif
#endif



