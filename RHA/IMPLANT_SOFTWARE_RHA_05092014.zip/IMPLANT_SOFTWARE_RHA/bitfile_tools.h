// -------------------------
// ITP - Uni Bremen
// 29.07.2011 
// David Rotermund 
// -------------------------

#include <iostream>
#include <fstream>
#ifndef include_bitfile_tools_h                                                                                                      
#define include_bitfile_tools_h   

class BitFile
{

    public:
	BitFile();
	~BitFile();
	
	int OpenFile(char * Filename);    
	int ShowFileInfo(void);
	
	bool IsImageOkay(void);
	int GetImage(unsigned char * Address);
	int GetImage_ZestET1Revered(unsigned char * Address);

	long GetImageLength(void);
	
    private:
	unsigned char * RAWImage;
	std::streamsize RAWImage_Length;

	// Information about the Segements 
	long Length_Header;
	long Length_DesignName;
	char * DesignName;
	long Length_PartName;
	char * PartName;
	long Length_Date;
	char * Date;			
	long Length_Time;
	char * Time;			
	long Length_BitImage;
        unsigned char * BitImage;
	
	bool KnownFPGAType;
	bool ImageIsOkay;
	char * TheFilename;
        
	long ConvertTwoByteIntoLong(std::streamsize StreamPosition);	
	long ConvertFourByteIntoLong(std::streamsize StreamPosition);		
	int AnalyseBitFile(void);	

};


#endif
