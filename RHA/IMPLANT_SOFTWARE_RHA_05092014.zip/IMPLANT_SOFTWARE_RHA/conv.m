function T = conv(z);
z = z(end-13:end);
T = '';
z = [z(13) z(14) z(11) z(12) z(9) z(10) z(7) z(8) z(5) z(6) z(3) z(4) z(1) z(2)];
for i = 1:1:length(z)
    T = [T dec2bin(z(i),8) ' | '];
end
