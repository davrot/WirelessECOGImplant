# Notes:
# 1.) This design wasn't tested with real RHAs. This still needs to be done. 
# 2.) As standard the FPGA runs in a test mode which emulates the RHAs. This has to be disabled in the VHDL source or via remote command. 
# 3.) There is a lot of buffering in the RHA test simulator. It may free a lot of space on the FPGA if this is removed. 

echo "Programm basestation"
./tool_programming 192.168.1.100 Basestation.bit
# We need this sleeps because the network stack is used strangely. Every tools need to "time out" its network connection before the next command is processed.
sleep 1s

echo "Reset Zarlink on basestation"
./tool_writereg 192.168.1.100 95 82
sleep 1s

echo "Activate the IMPLANT NOW !!!!!!!!!!! (10 sec)"
sleep 10s
 
echo "Create connection between basestation and implant"
./tool_init 192.168.1.100
sleep 1s

echo "Check if the basestation is connected to the implant (in many cases 45, which is okay)"
./tool_readreg 192.168.1.100 50 ; cat Basisstation.dat
sleep 1s

##############################################

echo "Set a filter (not used in the moment, but must be set to something)"
./tool_filter 192.168.1.100 15
sleep 1s

echo "Resultion for each sample (should be 15)"
./tool_resolution 192.168.1.100 15
sleep 1s

echo "Set the sample rate 15K Samples per second / value"
./tool_samplerate 192.168.1.100 50
sleep 1s

echo "Set the channel mask"
./tool_channelmask_asic 192.168.1.100 01 02 01 02 01 02 01 02 01 02 01 02 01 02 01 02
sleep 1s

####################

echo "Starte Datenaufnahme in der Basisstation"
./tool_start_asic 192.168.1.100 2000




